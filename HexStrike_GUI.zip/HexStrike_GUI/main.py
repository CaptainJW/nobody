#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HexStrike AI — 主入口（Linux/Kali 专用）
启动 Web 界面服务，浏览器访问 http://localhost:7777
"""

import sys
import os
import socket
import logging
import threading
import subprocess

# 确保 ~/.local/bin 在 PATH 中（GitHub 安装的工具路径）
_local_bin = os.path.expanduser('~/.local/bin')
if _local_bin not in os.environ.get('PATH', ''):
    os.environ['PATH'] = _local_bin + os.pathsep + os.environ.get('PATH', '')

# 确保日志目录存在
if not os.path.exists('logs'):
    os.makedirs('logs')

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/hexstrike.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


def check_port_available(port):
    """检查端口是否可用"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        result = s.connect_ex(('0.0.0.0', port))
        s.close()
        return result != 0  # 0 = 端口被占用, 非0 = 端口可用
    except Exception:
        return True


def check_firewall(port):
    """检查防火墙是否放行了指定端口"""
    try:
        # 检查 ufw
        result = subprocess.run(['ufw', 'status'], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            if 'inactive' in result.stdout.lower():
                return True, 'UFW 防火墙未启用（所有端口开放）'
            if str(port) in result.stdout:
                return True, f'UFW 已放行端口 {port}'
            return False, f'UFW 防火墙可能阻止了端口 {port}，请运行: sudo ufw allow {port}/tcp'
    except Exception:
        pass

    try:
        # 检查 iptables
        result = subprocess.run(['iptables', '-L', '-n'], capture_output=True, text=True, timeout=5)
        if result.returncode == 0 and 'DROP' in result.stdout and str(port) not in result.stdout:
            return None, f'iptables 可能阻止端口 {port}，如需开放: sudo iptables -A INPUT -p tcp --dport {port} -j ACCEPT'
    except Exception:
        pass

    return True, '防火墙检查完成'


def check_dependencies():
    """检查必要依赖"""
    missing = []
    try:
        import flask
    except ImportError:
        missing.append('flask')

    try:
        import requests
    except ImportError:
        missing.append('requests')

    if missing:
        print(f'❌ 缺少依赖: {", ".join(missing)}')
        print(f'💡 请运行: pip install {" ".join(missing)}')
        sys.exit(1)


def check_tools():
    """启动时快速检查工具可用状态"""
    try:
        from agents.tool_manager import get_tool_manager
        tm = get_tool_manager()
        available = sum(1 for t in tm.get_all_tools().values() if t.get('available'))
        total = len(tm.get_all_tools())
        if available < total:
            missing = [k for k, v in tm.get_all_tools().items() if not v.get('available')]
            print(f'  ⚠️  工具: {available}/{total} 可用 (缺失: {", ".join(missing)})')
            print(f'  💡 打开网页 → 🔧 工具管理 → 点击"一键安装"')
        else:
            print(f'  ✅ 工具: {available}/{total} 全部可用')
        print()
        return available, total
    except Exception as e:
        logger.debug(f'工具检查失败: {e}')
        print(f'  ⚠️  工具检查失败: {e}')
        print()
        return 0, 0


def get_local_ip():
    """获取本机局域网 IP 地址"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return '127.0.0.1'


def check_network_access(port, local_ip):
    """检查网络可访问性"""
    issues = []

    # 检查端口是否被占用
    if not check_port_available(port):
        issues.append(f'⚠️ 端口 {port} 已被占用，请使用 --port=其他端口')

    # 检查防火墙
    fw_ok, fw_msg = check_firewall(port)
    if fw_ok is False:
        issues.append(fw_msg)
    elif fw_ok is None:
        issues.append(fw_msg)

    # 检查是否能绑定
    try:
        test_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        test_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        test_sock.bind(('0.0.0.0', port))
        test_sock.close()
    except OSError as e:
        issues.append(f'❌ 无法绑定端口 {port}: {e}')

    return issues


def open_browser(host, port, delay=1.5):
    """延迟打开浏览器"""
    import time
    time.sleep(delay)
    url = f'http://{host}:{port}'
    try:
        import webbrowser
        webbrowser.open(url)
        logger.info(f'已在浏览器中打开: {url}')
    except Exception:
        logger.warning(f'无法自动打开浏览器，请手动访问: {url}')


def main():
    """主函数 — 启动 Web 服务器"""
    logger.info('HexStrike AI 启动中...')

    check_dependencies()

    host = '0.0.0.0'
    port = 7777

    # 解析命令行参数
    for arg in sys.argv[1:]:
        if arg.startswith('--port='):
            try:
                port = int(arg.split('=')[1])
            except ValueError:
                print(f'无效端口号: {arg}')
                sys.exit(1)
        elif arg.startswith('--host='):
            host = arg.split('=')[1]
        elif arg in ('-h', '--help'):
            print('用法: python3 main.py [选项]')
            print()
            print('选项:')
            print('  --host=HOST      监听地址 (默认: 0.0.0.0)')
            print('  --port=PORT      监听端口 (默认: 7777)')
            print('  -h, --help       显示帮助')
            sys.exit(0)

    local_ip = get_local_ip()

    print()
    print('=' * 60)
    print('  ⚔️  HexStrike AI — 智能渗透测试平台')
    print('=' * 60)
    print()

    # 网络诊断
    print('  🔍 网络诊断...')
    issues = check_network_access(port, local_ip)
    if issues:
        print()
        for issue in issues:
            print(f'    {issue}')
        print()
        # 尝试自动修复防火墙
        if any('ufw' in i.lower() for i in issues):
            print('  🔧 尝试自动开放防火墙...')
            try:
                subprocess.run(['sudo', 'ufw', 'allow', f'{port}/tcp'],
                               capture_output=True, timeout=10)
                print(f'  ✅ 已执行: sudo ufw allow {port}/tcp')
            except Exception:
                print(f'  ❌ 自动开放失败，请手动执行: sudo ufw allow {port}/tcp')
            print()
    else:
        print('  ✅ 网络检查通过')
    print()

    print(f'  🖥️  本机访问:  http://localhost:{port}')
    if host == '0.0.0.0' and local_ip != '127.0.0.1':
        print(f'  🌐 局域网访问: http://{local_ip}:{port}')
        print()
        print('  📌 从 Windows 浏览器访问上面的局域网地址即可')
    print()

    # 启动时检查工具可用性
    check_tools()

    print('  按 Ctrl+C 停止服务器')
    print('=' * 60)

    # 自动在浏览器中打开（仅Linux桌面环境）
    display_host = 'localhost' if host in ('0.0.0.0', '') else host
    if os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY'):
        threading.Thread(
            target=open_browser,
            args=(display_host, port),
            daemon=True
        ).start()

    # 导入并启动 Flask 服务器
    try:
        from web_server import app
        # 关键：使用 use_reloader=False 避免重复加载，threaded=True 支持并发
        app.run(
            host=host,
            port=port,
            debug=False,
            threaded=True,
            use_reloader=False,
        )
    except ImportError as e:
        logger.error(f'导入 web_server 失败: {e}')
        print(f'❌ 无法加载 Web 服务器: {e}')
        print()
        print('排查步骤:')
        print('  1. 确认在项目根目录运行: cd /path/to/HexStrike_GUI')
        print('  2. 安装依赖: pip install flask requests')
        print('  3. 检查 web_server.py 是否存在')
        sys.exit(1)
    except OSError as e:
        if 'Address already in use' in str(e):
            print(f'❌ 端口 {port} 已被占用')
            print(f'💡 解决方法:')
            print(f'   - 查看占用进程: sudo lsof -i :{port}')
            print(f'   - 杀掉占用进程: sudo kill $(sudo lsof -t -i :{port})')
            print(f'   - 或使用其他端口: python3 main.py --port=8080')
        else:
            print(f'❌ 启动失败: {e}')
        sys.exit(1)
    except KeyboardInterrupt:
        print()
        logger.info('服务器已停止')
        print('服务器已停止')
    except Exception as e:
        logger.error(f'服务器运行错误: {e}', exc_info=True)
        print(f'❌ 服务器运行错误: {e}')
        print('详细日志: logs/hexstrike.log')
        sys.exit(1)


if __name__ == '__main__':
    main()
