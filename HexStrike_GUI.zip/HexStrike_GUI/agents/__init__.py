"""
HexStrike Multi-Agent - 渗透测试Agent模块

两大Agent体系:
1. BaseAgent - 传统任务型Agent（兼容旧版）
2. SmartAgent - AI推理型Agent（推荐）

核心组件:
- SharedMemory - Agent间共享上下文
- KnowledgeGraph - 渗透测试知识图谱
- WorkflowOrchestrator - AI驱动动态工作流

所有导入使用 try/except 保护，确保单个模块加载失败不会影响整个包
"""

import logging

logger = logging.getLogger(__name__)

# ========== 安全导入：每个模块单独 try/except ==========

# 公共工具函数
try:
    from .utils import parse_json_response, sanitize_output, mask_api_key, validate_config_value
except Exception as e:
    logger.warning("utils 导入失败: %s", e)

# 工具管理器
try:
    from .tool_manager import ToolManager, get_tool_manager, is_tool_available, get_tool_command, find_wordlist
except Exception as e:
    logger.warning("tool_manager 导入失败: %s", e)

# 传统Agent体系（兼容旧版）
try:
    from .base_agent import BaseAgent, TaskResult
except Exception as e:
    logger.warning("base_agent 导入失败: %s", e)
    BaseAgent = None
    TaskResult = None

# 智能Agent体系（推荐）
try:
    from .base_agent import SmartAgent
except Exception as e:
    logger.warning("SmartAgent 导入失败: %s", e)
    SmartAgent = None

# 具体Agent实现
try:
    from .info_gathering_agent import SmartInfoGatheringAgent
except Exception as e:
    logger.warning("info_gathering_agent 导入失败: %s", e)
    SmartInfoGatheringAgent = None

try:
    from .vuln_scanner_agent import VulnScannerAgent, SmartVulnScannerAgent
except Exception as e:
    logger.warning("vuln_scanner_agent 导入失败: %s", e)
    VulnScannerAgent = None
    SmartVulnScannerAgent = None

try:
    from .web_pentest_agent import WebPentestAgent, SmartWebPentestAgent
except Exception as e:
    logger.warning("web_pentest_agent 导入失败: %s", e)
    WebPentestAgent = None
    SmartWebPentestAgent = None

try:
    from .report_agent import ReportAgent, SmartReportAgent
except Exception as e:
    logger.warning("report_agent 导入失败: %s", e)
    ReportAgent = None
    SmartReportAgent = None

# AI客户端
try:
    from .ai_client import BaseAIClient, OpenAIClient, ClaudeClient, SiliconFlowClient, MockAIClient
except Exception as e:
    logger.warning("ai_client 基础类导入失败: %s", e)
    BaseAIClient = None
    OpenAIClient = None
    ClaudeClient = None
    SiliconFlowClient = None
    MockAIClient = None

try:
    from .ai_client import AISession, AIAgentFactory
except Exception as e:
    logger.warning("ai_client 高级类导入失败: %s", e)
    AISession = None
    AIAgentFactory = None

# 工作流
try:
    from .workflow_orchestrator import WorkflowOrchestrator
except Exception as e:
    logger.warning("workflow_orchestrator 导入失败: %s", e)
    WorkflowOrchestrator = None

# 共享上下文
try:
    from .shared_memory import SharedMemory
except Exception as e:
    logger.warning("shared_memory 导入失败: %s", e)
    SharedMemory = None

# 知识图谱
try:
    from .knowledge_graph import PentestKnowledgeGraph
except Exception as e:
    logger.warning("knowledge_graph 导入失败: %s", e)
    PentestKnowledgeGraph = None


def check_imports():
    """检查所有模块的导入状态，返回状态字典"""
    return {
        'BaseAgent': BaseAgent is not None,
        'SmartAgent': SmartAgent is not None,
        'SmartInfoGatheringAgent': SmartInfoGatheringAgent is not None,
        'VulnScannerAgent': VulnScannerAgent is not None,
        'SmartVulnScannerAgent': SmartVulnScannerAgent is not None,
        'WebPentestAgent': WebPentestAgent is not None,
        'SmartWebPentestAgent': SmartWebPentestAgent is not None,
        'ReportAgent': ReportAgent is not None,
        'SmartReportAgent': SmartReportAgent is not None,
        'BaseAIClient': BaseAIClient is not None,
        'OpenAIClient': OpenAIClient is not None,
        'ClaudeClient': ClaudeClient is not None,
        'SiliconFlowClient': SiliconFlowClient is not None,
        'MockAIClient': MockAIClient is not None,
        'AISession': AISession is not None,
        'AIAgentFactory': AIAgentFactory is not None,
        'WorkflowOrchestrator': WorkflowOrchestrator is not None,
        'SharedMemory': SharedMemory is not None,
        'PentestKnowledgeGraph': PentestKnowledgeGraph is not None,
    }


__all__ = [
    'BaseAgent', 'TaskResult', 'SmartAgent',
    'SmartInfoGatheringAgent',
    'VulnScannerAgent', 'SmartVulnScannerAgent',
    'WebPentestAgent', 'SmartWebPentestAgent',
    'ReportAgent', 'SmartReportAgent',
    'WorkflowOrchestrator',
    'BaseAIClient', 'OpenAIClient', 'ClaudeClient',
    'SiliconFlowClient', 'MockAIClient',
    'AISession', 'AIAgentFactory',
    'SharedMemory', 'PentestKnowledgeGraph',
    'check_imports',
]
