#!/usr/bin/env python3
"""
HexStrike 工具管理器 — Kali/Linux 系统工具检测

功能：
1. 自动检测系统 PATH 中已安装的渗透测试工具
2. Kali Linux 特殊路径支持
3. 按优先级选择最佳可用工具
4. 字典文件发现（/usr/share/wordlists 等）
5. 工具安装指引（apt/pip/go install）
"""

import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"

# Kali 系统字典标准路径
KALI_WORDLIST_DIRS = [
    '/usr/share/wordlists',
    '/usr/share/seclists',
    '/usr/share/dirb',
    '/usr/share/dirbuster',
    '/usr/share/wfuzz',
    '/usr/share/amass',
]


class ToolManager:
    """工具管理器 — 检测系统已安装的渗透测试工具"""

    # 工具注册表：名称 → 分类 + 安装方式
    TOOL_REGISTRY = {
        # 端口扫描
        'nmap':       {'category': 'port_scan',   'apt': 'nmap',     'go': None, 'pip': None},
        'masscan':    {'category': 'port_scan',   'apt': 'masscan',  'go': None, 'pip': None},
        # 漏洞扫描
        'nuclei':     {'category': 'vuln_scan',   'apt': 'nuclei',   'go': 'github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest', 'pip': None},
        # 指纹识别
        'whatweb':    {'category': 'fingerprint', 'apt': 'whatweb',  'go': None, 'pip': None},
        'nikto':      {'category': 'fingerprint', 'apt': 'nikto',    'go': None, 'pip': None},
        # 目录扫描
        'dirsearch':  {'category': 'dir_scan',    'apt': 'dirsearch', 'go': None, 'pip': None},
        'gobuster':   {'category': 'dir_scan',    'apt': 'gobuster',  'go': 'github.com/OJ/gobuster/v3@latest', 'pip': None},
        'feroxbuster': {'category': 'dir_scan',   'apt': 'feroxbuster', 'go': None, 'pip': None},
        'dirb':       {'category': 'dir_scan',    'apt': 'dirb',      'go': None, 'pip': None},
        'ffuf':       {'category': 'dir_scan',    'apt': 'ffuf',      'go': 'github.com/ffuf/ffuf/v2@latest', 'pip': None},
        # 子域名枚举
        'amass':      {'category': 'subdomain',   'apt': 'amass',    'go': None, 'pip': None},
        'subfinder':  {'category': 'subdomain',   'apt': 'subfinder', 'go': 'github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest', 'pip': None},
        # SQL注入
        'sqlmap':     {'category': 'sqli_scan',   'apt': 'sqlmap',   'go': None, 'pip': None},
        # XSS扫描
        'dalfox':     {'category': 'xss_scan',    'apt': 'dalfox',   'go': 'github.com/hahwul/dalfox/v2@latest', 'pip': None},
        # SSL/TLS扫描
        'sslyze':     {'category': 'ssl_scan',    'apt': None,       'go': None, 'pip': 'sslyze'},
        'testssl':    {'category': 'ssl_scan',    'apt': 'testssl.sh', 'go': None, 'pip': None},
        # DNS工具
        'dig':        {'category': 'dns',         'apt': 'dnsutils',  'go': None, 'pip': None},
        'dnsrecon':   {'category': 'dns',         'apt': 'dnsrecon',  'go': None, 'pip': None},
        # Web扫描
        'wpscan':     {'category': 'web_scan',    'apt': 'wpscan',    'go': None, 'pip': None},
    }

    def __init__(self):
        self._tool_cache: Dict[str, Dict] = {}
        self._scan_tools()

    def _is_kali(self) -> bool:
        """检测是否在 Kali Linux 上运行"""
        try:
            if os.path.exists('/etc/os-release'):
                with open('/etc/os-release', 'r') as f:
                    if 'kali' in f.read().lower():
                        return True
        except Exception:
            pass
        return False

    def _scan_tools(self):
        """扫描所有可用工具"""
        self._tool_cache = {}

        # 确保 ~/.local/bin 在 PATH 中（GitHub 安装的路径）
        local_bin = os.path.expanduser('~/.local/bin')
        if local_bin not in os.environ.get('PATH', '') and os.path.isdir(local_bin):
            os.environ['PATH'] = local_bin + os.pathsep + os.environ.get('PATH', '')

        for tool_name, registry_info in self.TOOL_REGISTRY.items():
            path = shutil.which(tool_name)

            # Kali 特殊路径检测
            if not path and self._is_kali():
                path = self._check_kali_path(tool_name)

            # sqlmap 特殊：也检查 python 模块
            if tool_name == 'sqlmap' and not path:
                try:
                    r = subprocess.run(['sqlmap', '--version'], capture_output=True, timeout=5)
                    if r.returncode == 0:
                        path = 'sqlmap'
                except Exception:
                    pass
                if not path:
                    path = shutil.which('sqlmap')

            # sslyze 特殊：也检查 python 模块
            if tool_name == 'sslyze' and not path:
                try:
                    r = subprocess.run([sys.executable, '-m', 'sslyze', '--version'],
                                       capture_output=True, timeout=5)
                    if r.returncode == 0:
                        path = 'python -m sslyze'
                except Exception:
                    pass

            self._tool_cache[tool_name] = {
                'available': path is not None,
                'path': path,
                'source': 'system' if path else 'none',
                'category': registry_info['category'],
            }

        available = sum(1 for t in self._tool_cache.values() if t['available'])
        total = len(self._tool_cache)
        logger.info(f"工具扫描完成: {available}/{total} 可用")

    def _check_kali_path(self, tool_name: str) -> Optional[str]:
        """Kali Linux 的特殊工具路径 + ~/.local/bin"""
        # 优先检查 ~/.local/bin（GitHub 安装路径）
        local_bin = os.path.expanduser(f'~/.local/bin/{tool_name}')
        if os.path.isfile(local_bin) and os.access(local_bin, os.X_OK):
            return local_bin

        kali_paths = {
            'testssl': '/usr/bin/testssl',
            'nikto': '/usr/bin/nikto',
            'dirsearch': '/usr/bin/dirsearch',
            'sqlmap': '/usr/bin/sqlmap',
            'nmap': '/usr/bin/nmap',
            'masscan': '/usr/bin/masscan',
            'gobuster': '/usr/bin/gobuster',
            'feroxbuster': '/usr/bin/feroxbuster',
            'nuclei': '/usr/bin/nuclei',
            'whatweb': '/usr/bin/whatweb',
            'amass': '/usr/bin/amass',
            'subfinder': '/usr/bin/subfinder',
            'dalfox': '/usr/bin/dalfox',
            'dirb': '/usr/bin/dirb',
            'ffuf': '/usr/bin/ffuf',
            'dnsrecon': '/usr/bin/dnsrecon',
            'wpscan': '/usr/bin/wpscan',
        }
        kali_path = kali_paths.get(tool_name)
        if kali_path and os.path.isfile(kali_path) and os.access(kali_path, os.X_OK):
            return kali_path
        return None

    # =========================================================================
    # 公共 API
    # =========================================================================

    def is_available(self, tool_name: str) -> bool:
        info = self._tool_cache.get(tool_name, {})
        return info.get('available', False)

    def get_tool_path(self, tool_name: str) -> Optional[str]:
        info = self._tool_cache.get(tool_name, {})
        return info.get('path')

    def get_run_command(self, tool_name: str) -> Optional[List[str]]:
        """获取工具运行命令（可直接传给 subprocess）"""
        info = self._tool_cache.get(tool_name, {})
        if not info.get('available'):
            return None

        path = info.get('path')

        # sslyze 走 python 模块
        if tool_name == 'sslyze' and path == 'python -m sslyze':
            return [sys.executable, '-m', 'sslyze']

        # sqlmap 走系统命令
        if tool_name == 'sqlmap' and path:
            return [path]

        # 其他系统工具直接用可执行文件路径或名称
        if path:
            return [path]

        return None

    def get_available_tools(self) -> Dict[str, Dict]:
        return {k: v for k, v in self._tool_cache.items() if v.get('available')}

    def get_all_tools(self) -> Dict[str, Dict]:
        return self._tool_cache.copy()

    def get_tools_by_category(self, category: str) -> Dict[str, Dict]:
        return {k: v for k, v in self._tool_cache.items() if v.get('category') == category}

    def get_tool_info(self, tool_name: str) -> Dict:
        return self._tool_cache.get(tool_name, {})

    def get_best_tool(self, category: str) -> Optional[str]:
        """获取某类别中最佳可用工具"""
        priority = {
            'port_scan': ['nmap', 'masscan'],
            'vuln_scan': ['nuclei'],
            'fingerprint': ['whatweb', 'nikto'],
            'dir_scan': ['feroxbuster', 'gobuster', 'dirsearch', 'dirb', 'ffuf'],
            'subdomain': ['subfinder', 'amass'],
            'sqli_scan': ['sqlmap'],
            'xss_scan': ['dalfox'],
            'ssl_scan': ['sslyze', 'testssl'],
            'dns': ['dig', 'dnsrecon'],
            'web_scan': ['wpscan'],
        }
        for tool in priority.get(category, []):
            if self.is_available(tool):
                return tool
        # 兜底：该类别第一个可用的
        for name, info in self.get_tools_by_category(category).items():
            if info.get('available'):
                return name
        return None

    def find_wordlist(self, name: str = 'common') -> Optional[str]:
        """查找字典文件"""
        search_paths = [
            # Kali 标准路径
            Path(f'/usr/share/wordlists/dirb/{name}.txt'),
            Path(f'/usr/share/wordlists/dirbuster/{name}.txt'),
            Path('/usr/share/wordlists/dirb/common.txt'),
            Path('/usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt'),
            Path('/usr/share/seclists/Discovery/Web-Content/common.txt'),
            Path('/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt'),
            # 项目本地
            DATA_DIR / 'wordlists' / f'{name}.txt',
            DATA_DIR / f'{name}.txt',
        ]

        for p in search_paths:
            if p.exists():
                return str(p)

        # 在系统字典目录中递归查找
        for wdir in KALI_WORDLIST_DIRS:
            wp = Path(wdir)
            if wp.is_dir():
                for candidate in wp.rglob(f'{name}.txt'):
                    return str(candidate)

        return None

    def get_install_hint(self, tool_name: str) -> str:
        """获取工具安装提示"""
        info = self._tool_cache.get(tool_name, {})
        if info.get('available'):
            return f"✅ {tool_name} 已安装 (路径: {info.get('path', '_unknown')})"

        registry = self.TOOL_REGISTRY.get(tool_name, {})
        apt_pkg = registry.get('apt')
        go_pkg = registry.get('go')
        pip_pkg = registry.get('pip')

        hints = []
        if apt_pkg:
            hints.append(f"  apt install {apt_pkg}")
        if pip_pkg:
            hints.append(f"  pip install {pip_pkg}")
        if go_pkg:
            hints.append(f"  go install {go_pkg}")

        if hints:
            return f"📥 安装 {tool_name}:\n" + "\n".join(hints)

        return f"📥 未知工具: {tool_name}"

    def get_status_report(self) -> str:
        """获取所有工具状态的文本报告"""
        categories = {
            'port_scan': '📡 端口扫描',
            'vuln_scan': '🔍 漏洞扫描',
            'fingerprint': '🖐 指纹识别',
            'dir_scan': '📂 目录扫描',
            'subdomain': '🌐 子域名枚举',
            'sqli_scan': '💉 SQL注入',
            'xss_scan': '✖️ XSS扫描',
            'ssl_scan': '🔒 SSL/TLS扫描',
            'dns': '📋 DNS工具',
            'web_scan': '🌍 Web扫描',
        }

        lines = ["=" * 60, "🔧 HexStrike 工具状态报告", "=" * 60, ""]

        for cat_id, cat_name in categories.items():
            tools = self.get_tools_by_category(cat_id)
            if not tools:
                continue
            lines.append(f"  {cat_name}")
            for tool_name, info in tools.items():
                status = "✅" if info.get('available') else "❌"
                path = info.get('path', '')
                if info.get('available'):
                    lines.append(f"    {status} {tool_name} ({path})")
                else:
                    lines.append(f"    {status} {tool_name}")
            lines.append("")

        unavailable = {k: v for k, v in self._tool_cache.items() if not v.get('available')}
        if unavailable:
            lines.append("📝 未安装工具安装指引:")
            lines.append("-" * 40)
            for tool_name in unavailable:
                lines.append(self.get_install_hint(tool_name))
                lines.append("")

        return "\n".join(lines)

    def refresh(self):
        """重新扫描工具"""
        self._scan_tools()


# 全局单例
_tool_manager_instance: Optional[ToolManager] = None


def get_tool_manager() -> ToolManager:
    global _tool_manager_instance
    if _tool_manager_instance is None:
        _tool_manager_instance = ToolManager()
    return _tool_manager_instance


def is_tool_available(tool_name: str) -> bool:
    return get_tool_manager().is_available(tool_name)


def get_tool_command(tool_name: str) -> Optional[List[str]]:
    return get_tool_manager().get_run_command(tool_name)


def find_wordlist(name: str = 'common') -> Optional[str]:
    return get_tool_manager().find_wordlist(name)
