# agents/workflow_orchestrator.py
# 工作流编排器 - AI驱动的动态工作流 + SharedMemory
import json
import logging
import asyncio
import time
from typing import Dict, Any, List
from .ai_client import AIAgentFactory, AISession
from .shared_memory import SharedMemory
from .knowledge_graph import PentestKnowledgeGraph
from .utils import parse_json_response
from .info_gathering_agent import SmartInfoGatheringAgent
from .vuln_scanner_agent import VulnScannerAgent, SmartVulnScannerAgent
from .web_pentest_agent import WebPentestAgent, SmartWebPentestAgent
from .report_agent import ReportAgent, SmartReportAgent


class WorkflowOrchestrator:
    """工作流编排器 - AI驱动的动态工作流

    核心特性：
    1. SharedMemory 统一管理Agent间上下文传递
    2. 知识图谱辅助AI决策（AI不可用时降级到图谱推理）
    3. 动态策略调整：根据实时结果修改后续计划
    4. 并行执行支持：同一阶段内多个Agent可并行
    5. 两套Agent体系兼容：SmartAgent（AI推理）和 BaseAgent（传统）
    """

    def __init__(self, ai_config: Dict[str, Any]):
        self.logger = logging.getLogger("WorkflowOrchestrator")
        self.start_time = time.time()
        self._global_options = {}  # 保存全局选项（stealth_mode, deep_scan等）
        self._thinking_callback = None  # AI思考过程回调

        # SharedMemory: 统一的Agent间上下文传递
        self.shared_memory = SharedMemory()

        # 知识图谱: 辅助决策和降级
        self.knowledge_graph = PentestKnowledgeGraph()

        # AI客户端初始化
        self.ai_client = None
        self.ai_session = None
        if ai_config and 'provider' in ai_config and 'config' in ai_config:
            try:
                self.ai_client = AIAgentFactory.create_client(
                    ai_config['provider'], ai_config['config']
                )
                self.ai_session = AISession(self.ai_client, self._get_orchestrator_prompt())
            except Exception as e:
                self.logger.warning(f"AI客户端初始化失败: {e}")

        if not self.ai_session:
            self.logger.info("AI不可用，将使用知识图谱驱动的策略")

        # 初始化Agent（同时保留Smart和Base两种）
        self.agents = {
            'info_gathering': SmartInfoGatheringAgent('InfoGathering', ai_config, 'workspace'),
            'vuln_scanner': SmartVulnScannerAgent('VulnScanner', ai_config, 'workspace'),
            'web_pentest': SmartWebPentestAgent('WebPentest', ai_config, 'workspace'),
            'report': SmartReportAgent('Report', ai_config, 'workspace'),
        }

    def _get_orchestrator_prompt(self) -> str:
        return """你是一个渗透测试工作流编排专家。

你的职责:
1. 根据目标特征选择合适的Agent
2. 根据实时结果动态调整策略
3. 优化执行顺序和并行度
4. 识别关键路径和高价值目标
5. 在时间和资源约束下做出最优决策

原则:
- 优先攻击高价值目标
- 避免重复工作
- 快速失败，及时调整
- 保持隐蔽性（如果需要）
- 最大化发现/时间比
- 信息收集结果指导后续扫描
- 发现高危漏洞时深入验证"""

    def set_thinking_callback(self, callback):
        """设置AI思考过程回调 — 同时传递给所有Agent"""
        self._thinking_callback = callback
        for agent in self.agents.values():
            if hasattr(agent, 'set_thinking_callback'):
                agent.set_thinking_callback(callback)

    def set_scan_id(self, scan_id: str):
        """设置当前扫描ID（用于用户交互）"""
        self._scan_id = scan_id

    def _check_pause_and_chat(self):
        """检查是否暂停或收到用户消息（非阻塞）"""
        if not hasattr(self, '_scan_id') or not self._scan_id:
            return None
        try:
            from web_server import get_user_message
            return get_user_message(self._scan_id, timeout=0.05)
        except Exception:
            return None

    def _wait_if_paused(self):
        """如果是暂停状态，循环等待直到收到resume消息"""
        while True:
            try:
                from web_server import SCANS
                scan = SCANS.get(self._scan_id) if hasattr(self, '_scan_id') and self._scan_id else None
                if not scan or not scan.get('paused', False):
                    break
            except Exception:
                break
            msg = self._check_pause_and_chat()
            if msg and msg.get('role') == 'resume':
                break
            if msg and msg.get('role') == 'user':
                # 用户在暂停期间发了消息，AI处理
                self._handle_user_message(msg.get('content', ''))
            time.sleep(0.5)

    def _handle_user_message(self, message: str):
        """处理用户对话消息"""
        self._emit_thinking("info", f"💬 用户指令: {message}")

        if self.ai_session:
            # 让AI分析用户指令，决定是否调整策略
            context = self.shared_memory.get_summary()
            prompt = f"""用户发出了以下指令: "{message}"

当前渗透测试上下文:
- 已发现漏洞: {context.get('total_vulnerabilities', 0)}
- 严重/高危: {context.get('critical_vulns', 0)}/{context.get('high_vulns', 0)}
- 已发现端口: {context.get('total_findings', 0)}

请分析用户意图，返回JSON:
{{
  "action": "continue/adjust/stop",
  "target_focus": "用户想要重点关注的方向",
  "additional_tasks": ["额外任务1", "额外任务2"],
  "reason": "分析原因"
}}"""
            try:
                response = self._ai_chat_with_timeout(prompt, timeout=30)
                parsed = parse_json_response(response)
                if parsed:
                    self._emit_thinking("decide",
                        "🤖 AI响应用户指令: {}\\n"
                        "   动作: {} | 原因: {}".format(
                            message[:50],
                            parsed.get('action', 'continue'),
                            parsed.get('reason', '继续执行')
                        ))
                    # 存储用户意图到SharedMemory
                    self.shared_memory._context.setdefault('user_instructions', []).append({
                        'message': message,
                        'ai_response': parsed,
                        'time': time.time()
                    })
            except Exception as e:
                self.logger.warning(f"AI处理用户消息失败: {e}")
                self._emit_thinking("info", f"📝 已记录用户指令: {message[:50]}")
        else:
            self._emit_thinking("info", f"📝 已记录用户指令: {message[:50]}")
            self.shared_memory._context.setdefault('user_instructions', []).append({
                'message': message, 'time': time.time()
            })

    def _emit_thinking(self, thinking_type: str, content: str):
        """发送编排器级AI思考"""
        if self._thinking_callback:
            try:
                self._thinking_callback(thinking_type, content, "📌 编排器")
            except Exception as e:
                self.logger.debug(f"编排器思考回调异常: {e}")

    async def execute_intelligent_workflow(self, target: str, options: Dict[str, Any]) -> Dict:
        """执行智能工作流"""
        self.logger.info(f"开始智能渗透测试: {target}")
        self._global_options = options  # 保存全局选项供Agent使用
        self.shared_memory.start_timer()

        self._emit_thinking("analyze", "🎯 开始智能渗透测试\n   目标: {}\n   选项: {}".format(
            target, json.dumps(options, ensure_ascii=False)[:200]))

        # 1. 初始分析
        initial_analysis = await self._ai_initial_analysis(target, options)

        # 🧠 编排器思考：初始分析结果
        attack_surface = initial_analysis.get('attack_surface', [])
        self._emit_thinking("analyze",
            "🧩 初始分析完成\n"
            "   目标类型: {}\n"
            "   可能技术栈: {}\n"
            "   攻击面: {}".format(
                initial_analysis.get('target_type', '未知'),
                ', '.join(initial_analysis.get('tech_stack', ['未知'])),
                ', '.join(attack_surface[:8]) if attack_surface else '待探测'
            ))

        # 2. 制定总体策略
        strategy = await self._ai_create_strategy(initial_analysis)

        # 🧠 编排器思考：策略制定
        phases = strategy.get('phases', [])
        phase_names = [p.get('name', '?') for p in phases]
        agent_names = []
        for p in phases:
            for a in p.get('agents', []):
                agent_names.append(a.get('agent', '?'))
        self._emit_thinking("plan",
            "📋 策略制定完成\n"
            "   阶段: {} → {}\n"
            "   涉及Agent: {}\n"
            "   预计总时间: {}秒\n"
            "   关键路径: {}".format(
                len(phases),
                ' → '.join(phase_names),
                ', '.join(set(agent_names)),
                strategy.get('total_estimated_time', '?'),
                ' → '.join(strategy.get('critical_path', []))
            ))

        # 3. 动态执行
        results = await self._execute_dynamic_workflow(target, strategy)

        # 4. 生成报告
        report = await self._ai_generate_report(results)

        # 获取最终统计
        final_stats = self.shared_memory.get_summary()

        # 🧠 编排器思考：最终总结
        self._emit_thinking("evaluate",
            "🏁 渗透测试完成\n"
            "   总发现: {} | 总漏洞: {}\n"
            "   严重/高危: {}/{}\n"
            "   耗时: {:.0f}秒".format(
                final_stats.get('total_findings', 0),
                final_stats.get('total_vulnerabilities', 0),
                final_stats.get('critical_vulns', 0),
                final_stats.get('high_vulns', 0),
                final_stats.get('elapsed_time', 0)
            ))

        return {
            'target': target,
            'initial_analysis': initial_analysis,
            'strategy': strategy,
            'results': results,
            'report': report,
            'statistics': final_stats,
        }

    async def _ai_initial_analysis(self, target: str, options: Dict[str, Any]) -> Dict:
        """AI初始分析"""
        if self.ai_session:
            prompt = f"""
目标: {target}
选项: {json.dumps(options, indent=2, ensure_ascii=False)}

请分析:
1. 目标类型（IP/域名/Web应用/API等）
2. 可能的技术栈
3. 潜在的攻击面
4. 建议的测试策略
5. 预计的时间分配

返回JSON格式。
"""
            try:
                response = self._ai_chat_with_timeout(prompt, timeout=30)
                result = parse_json_response(response)
                if result:
                    return result
            except Exception as e:
                self.logger.warning(f"AI初始分析失败: {e}")

        # 降级：使用知识图谱推理
        return self._knowledge_graph_initial_analysis(target, options)

    def _knowledge_graph_initial_analysis(self, target: str, options: Dict) -> Dict:
        """使用知识图谱进行初始分析（AI不可用时的降级方案）"""
        import re
        # 检测目标类型
        if target.startswith('http://') or target.startswith('https://'):
            target_type = "web_application"
            attack_surface = ["web_fingerprint", "directory_scan", "vulnerability_scan", "sqli_test", "xss_test"]
        elif re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', target):
            target_type = "ip_address"
            attack_surface = ["port_scan", "service_detect", "vulnerability_scan"]
        else:
            target_type = "domain"
            attack_surface = ["port_scan", "subdomain_enum", "web_fingerprint", "vulnerability_scan"]

        # 使用知识图谱获取推荐动作
        initial_findings = [{'type': t} for t in attack_surface]
        recommendations = self.knowledge_graph.classify_and_recommend(initial_findings)

        return {
            "target_type": target_type,
            "tech_stack": ["Unknown - 需要信息收集"],
            "attack_surface": attack_surface,
            "strategy": recommendations.get('recommendation', '先进行信息收集，再针对性扫描'),
            "time_estimate": 600,
            "source": "knowledge_graph"
        }

    async def _ai_create_strategy(self, analysis: Dict) -> Dict:
        """AI制定策略"""
        if self.ai_session:
            prompt = f"""
初始分析:
{json.dumps(analysis, indent=2, ensure_ascii=False)}

可用的Agent:
{json.dumps(self._get_agent_capabilities(), indent=2, ensure_ascii=False)}

请制定一个高效的渗透测试策略:
1. 执行阶段（Phase）
2. 每个阶段的Agent和任务
3. 并行执行的可能性
4. 成功/失败的分支策略
5. 时间分配

返回JSON格式:
{{
    "phases": [
        {{
            "name": "阶段名称",
            "agents": [
                {{
                    "agent": "agent_name",
                    "tasks": ["task1", "task2"],
                    "parallel": true/false,
                    "priority": "high/medium/low",
                    "timeout": 300
                }}
            ],
            "success_criteria": "成功标准",
            "failure_action": "失败后的动作"
        }}
    ],
    "total_estimated_time": 1800,
    "critical_path": ["phase1", "phase2"]
}}
"""
            try:
                response = self._ai_chat_with_timeout(prompt, timeout=60)
                result = parse_json_response(response)
                if result and result.get('phases'):
                    return result
            except Exception as e:
                self.logger.warning(f"AI策略制定失败: {e}")

        # 降级：知识图谱驱动策略
        return self._knowledge_graph_strategy(analysis)

    def _knowledge_graph_strategy(self, analysis: Dict) -> Dict:
        """使用知识图谱制定策略"""
        target_type = analysis.get('target_type', 'web_application')

        if target_type == 'web_application':
            phases = [
                {
                    "name": "信息收集",
                    "agents": [{"agent": "info_gathering", "tasks": ["port_scan", "fingerprint", "directory_scan"], "parallel": False, "priority": "high", "timeout": 300}],
                    "success_criteria": "发现开放端口和服务",
                    "failure_action": "扩展扫描范围"
                },
                {
                    "name": "并行扫描（漏洞+Web渗透）",
                    "agents": [
                        {"agent": "vuln_scanner", "tasks": ["nuclei_scan", "basic_vuln_scan", "ssl_scan"], "parallel": True, "priority": "high", "timeout": 600},
                        {"agent": "web_pentest", "tasks": ["sqli_test", "xss_test", "auth_test"], "parallel": True, "priority": "high", "timeout": 600}
                    ],
                    "success_criteria": "发现漏洞或可利用点",
                    "failure_action": "使用更全面的模板"
                },
                {
                    "name": "报告生成",
                    "agents": [{"agent": "report", "tasks": ["generate_report"], "parallel": False, "priority": "medium", "timeout": 120}],
                    "success_criteria": "报告生成完成",
                    "failure_action": "简化报告格式"
                }
            ]
        else:
            phases = [
                {
                    "name": "信息收集",
                    "agents": [{"agent": "info_gathering", "tasks": ["port_scan", "service_detect", "subdomain_enum"], "parallel": False, "priority": "high", "timeout": 300}],
                    "success_criteria": "发现开放端口和服务",
                    "failure_action": "扩展端口范围"
                },
                {
                    "name": "并行扫描（漏洞+Web渗透）",
                    "agents": [
                        {"agent": "vuln_scanner", "tasks": ["nuclei_scan", "cve_detection"], "parallel": True, "priority": "high", "timeout": 600},
                        {"agent": "web_pentest", "tasks": ["sqli_test", "xss_test"], "parallel": True, "priority": "high", "timeout": 600}
                    ],
                    "success_criteria": "发现漏洞或可利用点",
                    "failure_action": "增加扫描深度"
                },
                {
                    "name": "报告生成",
                    "agents": [{"agent": "report", "tasks": ["generate_report"], "parallel": False, "priority": "medium", "timeout": 120}],
                    "success_criteria": "报告生成完成",
                    "failure_action": "简化报告格式"
                }
            ]

        return {
            "phases": phases,
            "total_estimated_time": sum(p.get('agents', [{}])[0].get('timeout', 300) for p in phases),
            "critical_path": [p['name'] for p in phases],
            "source": "knowledge_graph"
        }

    def _get_agent_capabilities(self) -> Dict:
        """获取Agent能力列表"""
        capabilities = {}
        for name, agent in self.agents.items():
            if hasattr(agent, 'capabilities'):
                capabilities[name] = agent.capabilities
            else:
                capabilities[name] = {"type": "base_agent", "name": agent.name}
        return capabilities

    def _ai_chat_with_timeout(self, prompt: str, timeout: int = 60) -> str:
        """带超时的AI调用 — 防止AI卡住导致整个工作流挂起"""
        import concurrent.futures
        if not self.ai_session:
            return ""
        try:
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(self.ai_session.chat, prompt)
                return future.result(timeout=timeout)
        except concurrent.futures.TimeoutError:
            self.logger.warning("AI调用超时 (%ds)，使用降级策略", timeout)
            return ""
        except Exception as e:
            self.logger.warning("AI调用失败: %s", e)
            return ""

    def _parse_json_response(self, response: str) -> Dict:
        """解析JSON响应 — 委托给公共函数"""
        return parse_json_response(response)

    async def _execute_dynamic_workflow(self, target: str, strategy: Dict) -> List:
        """动态执行工作流"""
        all_results = []

        for phase in strategy.get('phases', []):
            # 🛑 检查暂停状态
            self._wait_if_paused()

            # 💬 检查用户消息（非暂停状态下也能交互）
            msg = self._check_pause_and_chat()
            if msg and msg.get('role') == 'user':
                self._handle_user_message(msg.get('content', ''))

            self.logger.info(f"执行阶段: {phase['name']}")
            # 🧠 编排器思考：开始新阶段
            phase_agents = [a.get('agent', '?') for a in phase.get('agents', [])]
            self._emit_thinking("action",
                "🏗 进入阶段: {}\n"
                "   涉及Agent: {}\n"
                "   成功标准: {}".format(
                    phase['name'],
                    ', '.join(phase_agents),
                    phase.get('success_criteria', '无')
                ))

            phase_results = await self._execute_phase(target, phase)
            all_results.extend(phase_results)

            # 更新SharedMemory
            for result in phase_results:
                if isinstance(result, dict):
                    agent_name = result.get('agent_name', phase.get('name', 'unknown'))
                    await self.shared_memory.update_from_agent_output(agent_name, result)

            self.shared_memory.increment_phase()

            # AI评估：是否继续
            should_continue = await self._ai_should_continue(phase, phase_results)

            if not should_continue.get('continue', True):
                self.logger.info(f"AI决定停止: {should_continue.get('reason', '无原因')}")
                self._emit_thinking("decide",
                    "🛑 AI决定停止\n"
                    "   原因: {}\n"
                    "   已达成目标: {}".format(
                        should_continue.get('reason', '未说明'),
                        ', '.join(should_continue.get('achieved_goals', []))
                    ))
                break
            else:
                self._emit_thinking("decide",
                    "✅ 阶段完成，继续执行\n"
                    "   建议: {}".format(
                        should_continue.get('recommendation', '继续正常流程')
                    ))

            # AI调整：是否需要修改后续策略
            adjustments = await self._ai_adjust_strategy(phase_results, strategy)
            if adjustments.get('modified', False):
                self.logger.info(f"AI调整策略: {adjustments.get('changes', [])}")
                self._emit_thinking("plan",
                    "🔄 AI调整策略\n"
                    "   变更: {}\n"
                    "   原因: {}".format(
                        ', '.join(adjustments.get('changes', [])),
                        adjustments.get('reason', '未说明')
                    ))
                new_strategy = adjustments.get('new_strategy')
                if new_strategy and isinstance(new_strategy, dict):
                    strategy = new_strategy

        return all_results

    async def _execute_phase(self, target: str, phase: Dict) -> List:
        """执行一个阶段 — 支持并行Agent同时运行"""
        agent_tasks = phase.get('agents', [])

        parallel_tasks = [task for task in agent_tasks if task.get('parallel', False)]
        sequential_tasks = [task for task in agent_tasks if not task.get('parallel', False)]

        results = []

        # 并行执行：多个Agent同时运行
        if parallel_tasks:
            parallel_names = [t.get('agent', '?') for t in parallel_tasks]
            self._emit_thinking("action",
                "⚡ 并行执行 {} 个Agent: {}".format(
                    len(parallel_tasks),
                    ', '.join(parallel_names)
                ))

            parallel_results = await asyncio.gather(*[
                self._execute_agent_task(target, task)
                for task in parallel_tasks
            ], return_exceptions=True)
            for r in parallel_results:
                if isinstance(r, Exception):
                    self.logger.error(f"并行执行失败: {r}")
                    results.append({'error': str(r)})
                else:
                    results.append(r)

        # 顺序执行
        for task in sequential_tasks:
            result = await self._execute_agent_task(target, task)
            results.append(result)

        return results

    async def _execute_agent_task(self, target: str, task: Dict) -> Dict:
        """执行单个Agent任务"""
        agent_name = task['agent']
        agent = self.agents.get(agent_name)

        if not agent:
            return {'error': f'Agent not found: {agent_name}'}

        try:
            from .base_agent import SmartAgent, BaseAgent
            if isinstance(agent, SmartAgent):
                # SmartAgent: 传递SharedMemory上下文 + 编排器指定任务
                context = await self.shared_memory.get_context()
                # 将task中的信息合并进options
                agent_options = dict(task.get('params', {}))
                agent_options['tasks'] = task.get('tasks', [])
                agent_options['stealth_mode'] = self._global_options.get('stealth_mode', False)
                agent_options['deep_scan'] = self._global_options.get('deep_scan', False)
                result = await agent.execute_with_reasoning(
                    target,
                    context,
                    agent_options
                )
                # 更新SmartAgent的context引用
                agent.context = context
                return result
            elif isinstance(agent, BaseAgent):
                task_result = await agent.execute(target, task.get('params', {}))
                result = task_result.to_dict() if hasattr(task_result, 'to_dict') else task_result
                return result
            else:
                return {'error': f'Unknown agent type: {type(agent)}'}
        except Exception as e:
            self.logger.error(f"执行Agent任务失败: {e}")
            return {'error': str(e)}

    async def _ai_should_continue(self, phase: Dict, results: List) -> Dict:
        """AI决定是否继续"""
        if self.ai_session:
            summary = self.shared_memory.get_summary()
            prompt = f"""
刚完成的阶段: {phase['name']}
结果概要: {json.dumps(summary, indent=2, ensure_ascii=False)}

全局统计:
- 已发现漏洞数: {summary.get('total_vulnerabilities', 0)}
- 严重/高危漏洞: {summary.get('critical_vulns', 0)}/{summary.get('high_vulns', 0)}
- 已用时间: {summary.get('elapsed_time', 0):.0f}秒
- 已发现服务数: {summary.get('discovered_services', 0)}

请决定是否继续下一阶段。

返回JSON:
{{
    "continue": true/false,
    "reason": "原因",
    "achieved_goals": ["目标1"],
    "recommendation": "建议"
}}
"""
            try:
                response = self._ai_chat_with_timeout(prompt, timeout=30)
                result = parse_json_response(response)
                if result:
                    return result
            except Exception as e:
                self.logger.warning(f"AI继续决策失败: {e}")

        # 降级：使用知识图谱判断
        vulnerabilities = self.shared_memory._context.get('vulnerabilities', [])
        critical_vulns = [v for v in vulnerabilities if isinstance(v, dict) and v.get('severity') == 'critical']

        return {
            "continue": True,
            "reason": "继续执行直至完成所有阶段",
            "achieved_goals": [],
            "recommendation": "发现关键漏洞时应深入验证" if critical_vulns else "继续正常流程"
        }

    async def _ai_adjust_strategy(self, results: List, current_strategy: Dict) -> Dict:
        """AI调整策略"""
        if self.ai_session:
            summary = self.shared_memory.get_summary()
            prompt = f"""
最新统计: {json.dumps(summary, indent=2, ensure_ascii=False)}

当前策略: {json.dumps(current_strategy, indent=2, ensure_ascii=False)[:2000]}

基于最新发现，是否需要调整策略？

返回JSON:
{{
    "modified": true/false,
    "changes": ["变更1"],
    "new_strategy": {{}},
    "reason": "调整原因"
}}
"""
            try:
                response = self._ai_chat_with_timeout(prompt, timeout=30)
                result = parse_json_response(response)
                if result:
                    return result
            except Exception as e:
                self.logger.warning(f"AI策略调整失败: {e}")

        return {"modified": False, "changes": [], "reason": "无需调整"}

    async def _ai_generate_report(self, results: List) -> Dict:
        """AI生成报告"""
        summary = self.shared_memory.get_summary()

        if self.ai_session:
            prompt = f"""
测试统计: {json.dumps(summary, indent=2, ensure_ascii=False)}

请生成一份渗透测试报告摘要，包括:
1. 测试概要
2. 关键发现
3. 风险评估
4. 修复建议
5. 总结

返回JSON格式。
"""
            try:
                response = self._ai_chat_with_timeout(prompt, timeout=60)
                result = parse_json_response(response)
                if result:
                    return result
            except Exception as e:
                self.logger.warning(f"AI生成报告失败: {e}")

        # 降级报告
        return {
            "executive_summary": f"智能渗透测试完成: {summary.get('total_vulnerabilities', 0)}个漏洞发现",
            "findings": [],
            "risk_assessment": f"严重: {summary.get('critical_vulns', 0)}, 高危: {summary.get('high_vulns', 0)}",
            "remediation": ["检查发现的问题", "应用安全补丁"],
            "conclusion": "测试完成，请查看详细报告",
            "source": "knowledge_graph_fallback"
        }
