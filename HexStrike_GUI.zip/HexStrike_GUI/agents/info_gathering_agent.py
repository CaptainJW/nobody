# agents/info_gathering_agent.py
# 智能信息收集Agent - AI驱动的动态决策
import json
import logging
import os
import sys
from typing import Dict, Any, List
import asyncio
import socket
import re
from urllib.parse import urlparse
from .base_agent import SmartAgent
from .tool_manager import get_tool_manager, find_wordlist
from .utils import parse_url_target as _parse_url_target

# SSL验证 — 从环境变量读取，默认关闭（渗透测试工具常见需求）
# 生产环境设 VERIFY_SSL=1 启用验证
_VERIFY_SSL = os.environ.get('VERIFY_SSL', '0') == '1'


class SmartInfoGatheringAgent(SmartAgent):
    """智能信息收集Agent - AI动态决策扫描策略"""

    display_name = "信息收集"

    # ACTION_ALIASES 中增加了 sqlmap/dalfox/feroxbuster/sslyze 等新工具别名
    ACTION_ALIASES = {
        # 端口扫描
        "port_scan": "port_scan",
        "portscan": "port_scan",
        "port_scan_full": "port_scan",
        "scan_ports": "port_scan",
        # 子域名枚举
        "subdomain_enum": "subdomain_enum",
        "subdomain_enumeration": "subdomain_enum",
        "subdomain_scan": "subdomain_enum",
        "subdomains": "subdomain_enum",
        # 指纹识别
        "fingerprint": "fingerprint",
        "web_fingerprint": "fingerprint",
        "tech_detect": "fingerprint",
        "technology_detect": "fingerprint",
        # 目录扫描
        "directory_scan": "directory_scan",
        "dir_scan": "directory_scan",
        "dirsearch": "directory_scan",
        "gobuster": "directory_scan",
        "feroxbuster": "directory_scan",
        "path_scan": "directory_scan",
        # DNS枚举
        "dns_enum": "dns_enum",
        "dns_scan": "dns_enum",
        "dns_enumeration": "dns_enum",
        # 服务检测
        "service_detect": "service_detect",
        "service_detection": "service_detect",
        "service_scan": "service_detect",
        # SQL注入（来自Web渗透，这里也可以做简单检测）
        "sqlmap": "sqlmap_scan",
        "sql_injection": "sqlmap_scan",
        "sqli": "sqlmap_scan",
        # XSS扫描
        "dalfox": "dalfox_scan",
        "xss_scan": "dalfox_scan",
        "xss": "dalfox_scan",
        # SSL扫描
        "ssl_scan": "ssl_scan",
        "ssl_check": "ssl_scan",
        "tls_scan": "ssl_scan",
        "sslyze": "ssl_scan",
    }

    def get_system_prompt(self) -> str:
        return """你是一个专业的渗透测试信息收集专家。

你的职责:
1. 根据目标类型选择最优的扫描策略
2. 合理分配扫描资源和时间
3. 识别高价值信息并优先获取
4. 根据中间结果动态调整策略

原则:
- 先快后深：先快速扫描获取轮廓，再针对性深度扫描
- 隐蔽优先：在隐蔽模式下使用被动信息收集
- 资源节约：避免无效的全端口扫描
- 降级策略：工具不可用时及时切换到备选方案
"""

    def define_capabilities(self) -> Dict:
        return {
            "port_scan": {
                "tools": ["nmap", "masscan", "python_socket"],
                "speed": {"nmap": "medium", "masscan": "fast", "python_socket": "slow"},
                "accuracy": {"nmap": "high", "masscan": "medium", "python_socket": "low"},
                "stealth": {"nmap_sS": "high", "nmap_sT": "low", "masscan": "low"}
            },
            "subdomain_enum": {
                "tools": ["amass", "subfinder", "dns_query"],
                "coverage": {"amass": "comprehensive", "subfinder": "fast", "dns_query": "basic"}
            },
            "fingerprint": {
                "tools": ["whatweb", "wappalyzer", "http_headers"],
                "depth": {"whatweb": "deep", "wappalyzer": "medium", "http_headers": "basic"}
            },
            "directory_scan": {
                "tools": ["dirsearch", "gobuster", "feroxbuster"],
                "speed": {"dirsearch": "medium", "gobuster": "fast", "feroxbuster": "fast"}
            },
            "dns_enum": {
                "tools": ["dig", "dnsrecon", "python_dns"],
                "depth": {"dig": "basic", "dnsrecon": "deep", "python_dns": "basic"}
            }
        }

    def _analyze_situation(self, target: str, context: Dict) -> Dict:
        """分析当前情况"""
        # 从上下文中获取已有发现
        previous_findings = context.get('findings', [])
        known_ports = []
        known_services = []

        # 从已有发现中提取端口和服务信息
        for finding in previous_findings:
            if isinstance(finding, dict):
                if 'port' in finding:
                    known_ports.append(finding['port'])
                if 'service' in finding:
                    known_services.append(finding['service'])

        return {
            "target": target,
            "target_type": self._detect_target_type(target),
            "previous_findings": previous_findings[-10:],  # 最近10条
            "known_ports": known_ports,
            "known_services": known_services,
            "time_budget": context.get('time_budget', 300),
            "stealth_mode": context.get('stealth_mode', False),
            "available_tools": self._check_available_tools()
        }

    def _detect_target_type(self, target: str) -> str:
        """检测目标类型"""
        if target.startswith('http://') or target.startswith('https://'):
            return "web_application"
        elif self._is_ip(target):
            return "ip_address"
        else:
            # 可能是域名
            return "domain"

    def _is_ip(self, target: str) -> bool:
        """判断是否为IP地址"""
        try:
            socket.inet_aton(target)
            return True
        except socket.error:
            return False

    def _check_available_tools(self) -> Dict:
        """检查可用工具（使用ToolManager统一管理）"""
        tm = get_tool_manager()
        tools = {}
        for tool in ['nmap', 'masscan', 'whatweb', 'dirsearch', 'gobuster', 'feroxbuster',
                      'amass', 'subfinder', 'sqlmap', 'dalfox', 'sslyze']:
            tools[tool] = tm.is_available(tool)
        return tools

    async def _execute_plan(self, plan: Dict, target: str) -> List:
        """执行AI制定的计划"""
        results = []

        for step in plan.get('steps', []):
            raw_action = step['action']
            params = step.get('params', {})
            # 使用别名解析
            action = self._resolve_action_name(raw_action)
            if action != raw_action:
                self.logger.info(f"[InfoGathering] 动作别名解析: {raw_action} → {action}")

            self.logger.info(f"[InfoGathering] 执行: {action} - 原因: {step.get('reason', '无')}")

            # 🧠 发送思考：正在执行动作
            self._emit_thinking("action",
                "⚡ 执行: {} | 参数: {} | 原因: {}".format(
                    action,
                    json.dumps(params, ensure_ascii=False) if params else '默认',
                    step.get('reason', '编排器指定')
                ))

            # 动态调用方法 _do_{action}
            if hasattr(self, f'_do_{action}'):
                method = getattr(self, f'_do_{action}')
                try:
                    if asyncio.iscoroutinefunction(method):
                        result = await method(target, params)
                    else:
                        result = method(target, params)
                    results.append({
                        'action': action,
                        'result': result,
                        'success': result.get('success', False) if isinstance(result, dict) else True
                    })
                except Exception as e:
                    self.logger.error(f"[InfoGathering] 执行 {action} 失败: {e}")
                    results.append({
                        'action': action,
                        'result': {'success': False, 'error': str(e)},
                        'success': False
                    })
            else:
                self.logger.warning(f"[InfoGathering] 未知动作: {action}, 尝试降级执行")
                # 降级：尝试通用执行
                result = await self._do_generic_action(target, action, params)
                results.append({
                    'action': action,
                    'result': result,
                    'success': result.get('success', False)
                })

        return results

    # =========================================================================
    # 具体动作实现
    # =========================================================================

    def _validate_ports(self, ports: str) -> str:
        """校验端口范围参数"""
        if not re.match(r'^[\d,\-]+$', str(ports)):
            return "1-1000"
        return str(ports)

    def _validate_target(self, target: str) -> str:
        """校验目标地址 — 支持完整URL（含查询参数 & ? = % 等）"""
        if not target or not target.strip():
            return ""
        target = target.strip()
        # 如果是完整URL，用urllib解析验证
        if target.startswith(('http://', 'https://')):
            try:
                parsed = urlparse(target)
                if parsed.hostname:
                    return target
            except Exception:
                pass
            return ""
        # 非URL（IP或域名），只允许字母数字.−:/
        if not re.match(r'^[a-zA-Z0-9.\-:/]+$', target):
            return ""
        return target

    async def _do_port_scan(self, target: str, params: Dict) -> Dict:
        """端口扫描 - 带智能工具选择和降级"""
        target = self._validate_target(target)
        if not target:
            return {'success': False, 'error': 'Invalid target'}

        # 🔧 解析URL：nmap/masscan 只接受 hostname/IP，不接受完整URL
        parsed = _parse_url_target(target)
        host_for_scan = parsed['host_for_nmap']  # 只取 hostname 部分
        port_from_url = parsed['port']            # URL中的端口号

        tm = get_tool_manager()
        tool = params.get('tool', 'auto')
        # 如果URL指定了非标准端口，优先扫描该端口
        ports = self._validate_ports(params.get('ports', '1-1000'))

        # 自动选择工具
        if tool == 'auto':
            available = self._check_available_tools()
            if available.get('nmap'):
                tool = 'nmap'
            elif available.get('masscan'):
                tool = 'masscan'
            else:
                tool = 'python_socket'

        # 🧠 发送思考：展示解析后的目标信息
        self._emit_thinking("action",
            f"📡 端口扫描目标解析:\n"
            f"   原始输入: {target}\n"
            f"   扫描主机: {host_for_scan}\n"
            f"   URL端口: {port_from_url}\n"
            f"   扫描范围: {ports}\n"
            f"   使用工具: {tool}")

        if tool == 'nmap' and tm.is_available('nmap'):
            return await self._nmap_scan(host_for_scan, ports, params)
        elif tool == 'masscan' and tm.is_available('masscan'):
            return await self._masscan_scan(host_for_scan, ports)
        else:
            return await self._python_scan(host_for_scan, ports)

    async def _do_subdomain_enum(self, target: str, params: Dict) -> Dict:
        """子域名枚举"""
        # 🔧 从URL中提取hostname
        parsed = _parse_url_target(target)
        host_for_enum = parsed['host_for_nmap']

        tm = get_tool_manager()
        tool = params.get('tool', 'auto')

        if tool in ['subfinder', 'auto'] and tm.is_available('subfinder'):
            return await self._tool_subdomain_scan(host_for_enum, 'subfinder')
        elif tool in ['amass', 'auto'] and tm.is_available('amass'):
            return await self._tool_subdomain_scan(host_for_enum, 'amass')
        else:
            return await self._dns_subdomain_enum(host_for_enum)

    async def _do_fingerprint(self, target: str, params: Dict) -> Dict:
        """指纹识别"""
        # 🔧 从URL中提取 — whatweb需要完整URL，http_headers也需要完整URL
        parsed = _parse_url_target(target)
        url_for_scan = parsed['full_url']

        tm = get_tool_manager()
        tool = params.get('tool', 'auto')

        if tool in ['whatweb', 'auto'] and tm.is_available('whatweb'):
            return await self._whatweb_scan(url_for_scan)
        else:
            return await self._http_fingerprint(url_for_scan)

    async def _do_directory_scan(self, target: str, params: Dict) -> Dict:
        """目录扫描 - 智能选择工具"""
        # 🔧 从URL中提取 — 目录扫描需要完整URL
        parsed = _parse_url_target(target)
        url_for_scan = parsed['full_url']

        tm = get_tool_manager()
        tool = params.get('tool', 'auto')

        # 自动选择：优先feroxbuster > gobuster > dirsearch
        if tool == 'auto':
            if tm.is_available('feroxbuster'):
                tool = 'feroxbuster'
            elif tm.is_available('gobuster'):
                tool = 'gobuster'
            elif tm.is_available('dirsearch'):
                tool = 'dirsearch'
            else:
                tool = 'python'

        if tool == 'dirsearch' and tm.is_available('dirsearch'):
            return await self._tool_directory_scan(url_for_scan, 'dirsearch')
        elif tool == 'gobuster' and tm.is_available('gobuster'):
            return await self._tool_directory_scan(url_for_scan, 'gobuster')
        elif tool == 'feroxbuster' and tm.is_available('feroxbuster'):
            return await self._tool_directory_scan(url_for_scan, 'feroxbuster')
        else:
            return await self._python_directory_scan(url_for_scan)

    async def _do_dns_enum(self, target: str, params: Dict) -> Dict:
        """DNS枚举"""
        parsed = _parse_url_target(target)
        return await self._dns_subdomain_enum(parsed['host_for_nmap'])

    async def _do_service_detect(self, target: str, params: Dict) -> Dict:
        """服务版本检测"""
        parsed = _parse_url_target(target)
        return await self._nmap_scan(parsed['host_for_nmap'], '1-1000', {'service_detect': True})

    async def _do_sqlmap_scan(self, target: str, params: Dict) -> Dict:
        """SQL注入扫描（使用sqlmap）— 直接使用完整URL（含查询参数）"""
        tm = get_tool_manager()
        if not tm.is_available('sqlmap'):
            return {'success': False, 'tool': 'sqlmap', 'error': 'sqlmap不可用。' + tm.get_install_hint('sqlmap')}

        # 🔧 sqlmap需要完整的URL（含查询参数），如 ?id=1&submit=查询
        parsed = _parse_url_target(target)
        url_for_sqlmap = parsed['full_url']
        # 如果原始输入包含查询参数，使用原始输入
        if '?' in target:
            url_for_sqlmap = target if target.startswith('http') else parsed['full_url']

        cmd_base = tm.get_run_command('sqlmap')
        try:
            cmd = cmd_base + [
                '-u', url_for_sqlmap,
                '--batch',           # 非交互模式
                '--random-agent',    # 随机User-Agent
                '--level', str(params.get('level', 3)),
                '--risk', str(params.get('risk', 2)),
                '--timeout', '30',
                '--retries', '2',
                '--threads', '3',
            ]
            if params.get('dbs'):
                cmd.extend(['--dbs'])
            if params.get('tables'):
                cmd.extend(['--tables'])
            if params.get('tamper'):
                cmd.extend(['--tamper', params['tamper']])

            self.logger.info(f"[InfoGathering] sqlmap命令: {' '.join(cmd)}")

            # 🧠 发出命令语法思考事件
            result = await self._run_tool_async(cmd, tool_name='sqlmap', purpose='SQL注入检测', timeout=params.get('timeout', 600))
            
            output = result.get('stdout', '')
            if not result.get('success'):
                return {'success': False, 'tool': 'sqlmap', 'error': result.get('stderr', '未知错误')}

            # 解析sqlmap输出中的关键信息
            vulns = []
            if 'is vulnerable' in output.lower() or 'sql injection' in output.lower():
                vulns.append({
                    'type': 'SQL注入',
                    'tool': 'sqlmap',
                    'vulnerable': True,
                    'severity': 'critical',
                    'output_snippet': output[-2000:] if len(output) > 2000 else output
                })
            elif 'does not seem to be injectable' in output.lower():
                return {'success': True, 'tool': 'sqlmap', 'injection_found': False,
                        'message': '未发现SQL注入漏洞'}
            else:
                return {'success': True, 'tool': 'sqlmap', 'injection_found': False,
                        'output': output[-1000:]}

            return {'success': True, 'tool': 'sqlmap', 'vulnerabilities': vulns}

        except asyncio.TimeoutError:
            return {'success': False, 'tool': 'sqlmap', 'error': 'sqlmap扫描超时(600s)'}
        except Exception as e:
            return {'success': False, 'tool': 'sqlmap', 'error': str(e)}

    async def _do_dalfox_scan(self, target: str, params: Dict) -> Dict:
        """XSS扫描（使用dalfox）— 使用完整URL"""
        tm = get_tool_manager()
        if not tm.is_available('dalfox'):
            return {'success': False, 'tool': 'dalfox', 'error': 'dalfox不可用。' + tm.get_install_hint('dalfox')}

        # 🔧 dalfox需要完整URL（含查询参数）
        parsed = _parse_url_target(target)
        url_for_scan = parsed['full_url']
        if '?' in target:
            url_for_scan = target if target.startswith('http') else parsed['full_url']

        cmd_base = tm.get_run_command('dalfox')
        try:
            cmd = cmd_base + [
                'url', url_for_scan,
                '--silence',         # 静默模式，只输出发现
                '--follow-redirects',
                '--timeout', '10',
                '--delay', '100ms',
            ]
            if params.get('blind'):
                cmd.extend(['--blind', params['blind']])

            self.logger.info(f"[InfoGathering] dalfox命令: {' '.join(cmd)}")
            self._emit_thinking("command", ' '.join(cmd))

            process = await self._run_tool_async(cmd, tool_name='dalfox', purpose='XSS扫描', timeout=params.get('timeout', 300))
            output = process.get('stdout', '')
            xss_findings = []

            # 解析dalfox输出
            for line in output.strip().split('\n'):
                line = line.strip()
                if line and ('[V]' in line or 'found' in line.lower() or 'xss' in line.lower()):
                    xss_findings.append({
                        'type': 'XSS',
                        'tool': 'dalfox',
                        'detail': line,
                        'severity': 'high'
                    })

            return {
                'success': True, 'tool': 'dalfox',
                'findings': xss_findings,
                'total': len(xss_findings)
            }

        except asyncio.TimeoutError:
            return {'success': False, 'tool': 'dalfox', 'error': 'dalfox扫描超时(300s)'}
        except Exception as e:
            return {'success': False, 'tool': 'dalfox', 'error': str(e)}

    async def _do_ssl_scan(self, target: str, params: Dict) -> Dict:
        """SSL/TLS扫描（使用sslyze）— 需要hostname"""
        tm = get_tool_manager()

        # 🔧 从URL中提取hostname
        parsed = _parse_url_target(target)
        hostname = parsed['host_for_nmap']

        # 优先使用sslyze
        if tm.is_available('sslyze'):
            return await self._sslyze_scan(hostname)

        # 降级到Python ssl模块
        return await self._python_ssl_scan(hostname)

    async def _sslyze_scan(self, hostname: str) -> Dict:
        """使用sslyze进行SSL扫描"""
        tm = get_tool_manager()
        cmd_base = tm.get_run_command('sslyze')

        try:
            cmd = cmd_base + [
                '--json_out=-',      # JSON输出到stdout
                hostname,
            ]

            self.logger.info(f"[InfoGathering] sslyze命令: {' '.join(cmd)}")

            process = await self._run_tool_async(cmd, tool_name='sslyze', purpose='SSL安全检测', timeout=120)
            
            output = process.get('stdout', '')
            issues = []

            try:
                result_data = json.loads(output)
                # 解析sslyze JSON输出
                for scan in result_data.get('scan_commands_results', []):
                    if scan.get('ssl_2_0_cipher_suites', {}).get('accepted_cipher_suites'):
                        issues.append({'name': 'SSLv2启用', 'severity': 'critical'})
                    if scan.get('ssl_3_0_cipher_suites', {}).get('accepted_cipher_suites'):
                        issues.append({'name': 'SSLv3启用(POODLE)', 'severity': 'high'})
                    if scan.get('tls_1_0_cipher_suites', {}).get('accepted_cipher_suites'):
                        issues.append({'name': 'TLS 1.0启用', 'severity': 'medium'})
                    if scan.get('tls_1_1_cipher_suites', {}).get('accepted_cipher_suites'):
                        issues.append({'name': 'TLS 1.1启用', 'severity': 'medium'})
                    if scan.get('certificate_info', {}).get('received_certificate_chain'):
                        issues.append({'name': '证书链检查完成', 'severity': 'info'})
            except json.JSONDecodeError:
                # 非JSON输出，直接解析文本
                if 'SSLv2' in output:
                    issues.append({'name': 'SSLv2启用', 'severity': 'critical'})
                if 'SSLv3' in output:
                    issues.append({'name': 'SSLv3启用(POODLE)', 'severity': 'high'})
                if 'TLSv1.0' in output or 'TLS 1.0' in output:
                    issues.append({'name': 'TLS 1.0启用', 'severity': 'medium'})

            return {'success': True, 'tool': 'sslyze', 'issues': issues, 'total': len(issues)}

        except asyncio.TimeoutError:
            return {'success': False, 'tool': 'sslyze', 'error': 'sslyze扫描超时(120s)'}
        except Exception as e:
            return {'success': False, 'tool': 'sslyze', 'error': str(e)}

    async def _python_ssl_scan(self, hostname: str) -> Dict:
        """Python原生SSL扫描（降级方案）"""
        import ssl
        issues = []
        try:
            context = ssl.create_default_context()
            with socket.create_connection((hostname, 443), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    protocol = ssock.version()
                    cipher = ssock.cipher()
                    cert = ssock.getpeercert()

                    if protocol in ('TLSv1', 'TLSv1.1', 'SSLv3'):
                        issues.append({'name': f'弱TLS协议: {protocol}', 'severity': 'high'})

                    if cert:
                        import datetime as dt
                        try:
                            # TLS证书格式: "Nov  4 00:00:00 2023 GMT"
                            expiry = dt.datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
                            expiry = expiry.replace(tzinfo=dt.timezone.utc)
                        except (ValueError, KeyError):
                            # 降级: 尝试 RFC 2822 格式
                            try:
                                from email.utils import parsedate_to_datetime
                                expiry = parsedate_to_datetime(cert['notAfter'])
                            except Exception:
                                expiry = None

                        if expiry and expiry < dt.datetime.now(dt.timezone.utc):
                            issues.append({'name': '证书已过期', 'severity': 'high'})
                        elif expiry and (expiry - dt.datetime.now(dt.timezone.utc)).days < 30:
                            issues.append({'name': '证书即将过期(30天内)', 'severity': 'medium'})

                    if cipher and cipher[1] < 128:
                        issues.append({'name': f'弱加密套件: {cipher[0]}', 'severity': 'medium'})

        except Exception as e:
            return {'success': False, 'tool': 'python_ssl', 'error': str(e)}

        return {'success': True, 'tool': 'python_ssl', 'issues': issues, 'total': len(issues)}

    async def _do_generic_action(self, target: str, action: str, params: Dict) -> Dict:
        """通用动作降级执行"""
        self.logger.warning(f"未知动作 {action}, 执行默认端口扫描")
        return await self._do_port_scan(target, {'tool': 'auto', 'ports': '1-1000'})

    # =========================================================================
    # 扫描工具实现
    # =========================================================================

    def _is_tool_available(self, tool_name: str) -> bool:
        """检查工具是否可用（使用ToolManager统一管理）"""
        return get_tool_manager().is_available(tool_name)

    async def _nmap_scan(self, target: str, ports: str, params: Dict = None) -> Dict:
        """Nmap扫描（通过ToolManager定位可执行文件）"""
        params = params or {}
        tm = get_tool_manager()
        nmap_cmd = tm.get_run_command('nmap') or ['nmap']
        try:
            cmd = nmap_cmd + ['-p', ports]
            if params.get('service_detect'):
                cmd.extend(['-sV', '-sC'])
            elif params.get('stealth'):
                cmd.append('-sS')
            else:
                cmd.append('-sV')
            cmd.append(target)

            process = await self._run_tool_async(cmd, tool_name='nmap', purpose='端口扫描', timeout=params.get('timeout', 300))

            if process.get('success'):
                output = process.get('stdout', '')
                return {
                    'success': True,
                    'tool': 'nmap',
                    'output': output,
                    'ports': self._parse_nmap_output(output)
                }
            else:
                return {'success': False, 'tool': 'nmap', 'error': process.get('stderr', '未知错误')}
        except Exception as e:
            return {'success': False, 'tool': 'nmap', 'error': str(e)}

    async def _masscan_scan(self, target: str, ports: str) -> Dict:
        """Masscan扫描（通过ToolManager定位可执行文件）"""
        tm = get_tool_manager()
        masscan_cmd = tm.get_run_command('masscan') or ['masscan']
        try:
            cmd = masscan_cmd + ['-p', ports, target, '--rate', '1000']
            process = await self._run_tool_async(cmd, tool_name='masscan', purpose='快速端口扫描')

            if process.get('success'):
                return {
                    'success': True,
                    'tool': 'masscan',
                    'output': process.get('stdout', ''),
                    'ports': self._parse_masscan_output(process.get('stdout', ''))
                }
            else:
                return {'success': False, 'tool': 'masscan', 'error': process.get('stderr', '未知错误')}
        except Exception as e:
            return {'success': False, 'tool': 'masscan', 'error': str(e)}

    async def _python_scan(self, target: str, ports: str) -> Dict:
        """Python原生端口扫描（降级方案）— 使用线程池避免阻塞事件循环"""
        open_ports = []
        try:
            port_list = self._parse_port_range(ports)

            def _scan_port(tgt, port):
                """单端口扫描（同步，在线程池中执行）"""
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1)
                    result = sock.connect_ex((tgt, port))
                    sock.close()
                    if result == 0:
                        return {'port': str(port), 'service': self._get_service_name(port)}
                except Exception:
                    pass
                return None

            loop = asyncio.get_event_loop()
            # 并发扫描，最多50个线程
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=50) as executor:
                futures = [loop.run_in_executor(executor, _scan_port, target, port)
                           for port in port_list]
                results = await asyncio.gather(*futures)
                open_ports = [r for r in results if r is not None]

            return {
                'success': True,
                'tool': 'python_socket',
                'ports': open_ports,
                'total_scanned': len(port_list)
            }
        except Exception as e:
            return {'success': False, 'tool': 'python_socket', 'error': str(e)}

    async def _tool_subdomain_scan(self, target: str, tool: str) -> Dict:
        """使用工具进行子域名枚举（通过ToolManager定位可执行文件）"""
        tm = get_tool_manager()
        cmd_base = tm.get_run_command(tool)
        if not cmd_base:
            return {'success': False, 'tool': tool, 'error': f'{tool}不可用。{tm.get_install_hint(tool)}'}

        try:
            # 不同工具有不同的命令行参数
            if tool == 'amass':
                cmd = cmd_base + ['enum', '-d', target, '-passive']
            elif tool == 'subfinder':
                cmd = cmd_base + ['-d', target, '-silent']
            else:
                cmd = cmd_base + ['-d', target]

            self.logger.info(f"[InfoGathering] {tool}命令: {' '.join(cmd)}")
            self._emit_thinking("command", ' '.join(cmd))

            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), timeout=300
            )

            subdomains = []
            for line in stdout.decode().split('\n'):
                line = line.strip()
                if line and target in line:
                    subdomains.append(line)

            return {
                'success': True,
                'tool': tool,
                'subdomains': subdomains,
                'count': len(subdomains)
            }
        except Exception as e:
            return {'success': False, 'tool': tool, 'error': str(e)}

    async def _dns_subdomain_enum(self, target: str) -> Dict:
        """DNS子域名枚举（降级方案）"""
        common_subdomains = ['www', 'mail', 'ftp', 'admin', 'api', 'dev', 'staging', 'test']
        found = []

        for sub in common_subdomains:
            try:
                domain = f"{sub}.{target}"
                ip = socket.gethostbyname(domain)
                found.append({'subdomain': domain, 'ip': ip})
            except socket.gaierror:
                pass

        return {
            'success': True,
            'tool': 'dns_query',
            'subdomains': found,
            'count': len(found)
        }

    async def _whatweb_scan(self, target: str) -> Dict:
        """WhatWeb指纹识别（通过ToolManager定位可执行文件）"""
        # target 应该已经是完整URL（由 _do_fingerprint 传入）
        if not target.startswith('http'):
            target = f"http://{target}"
        tm = get_tool_manager()
        cmd_base = tm.get_run_command('whatweb')
        if not cmd_base:
            return await self._http_fingerprint(target)
        try:
            cmd = cmd_base + ['-a', '3', target]  # -a 3 = 聚合模式，更全面
            self.logger.info(f"[InfoGathering] whatweb命令: {' '.join(cmd)}")
            self._emit_thinking("command", ' '.join(cmd))
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), timeout=60
            )
            output = stdout.decode(errors='replace')
            # 尝试解析whatweb的结构化输出
            technologies = []
            # whatweb输出格式: http://target [200 OK] Apache[2.4.41], PHP[7.4], WordPress[5.8]
            tech_pattern = r'(\w+)\[([^\]]*)\]'
            for match in re.finditer(tech_pattern, output):
                tech_name = match.group(1)
                tech_version = match.group(2)
                technologies.append({'name': tech_name, 'version': tech_version})

            return {
                'success': True,
                'tool': 'whatweb',
                'output': output,
                'technologies': technologies
            }
        except Exception as e:
            return {'success': False, 'tool': 'whatweb', 'error': str(e)}

    async def _http_fingerprint(self, target: str) -> Dict:
        """HTTP头部指纹识别（降级方案）"""
        import requests
        if not target.startswith('http'):
            target = f"http://{target}"
        try:
            resp = requests.get(target, timeout=10, verify=_VERIFY_SSL)
            headers = dict(resp.headers)
            return {
                'success': True,
                'tool': 'http_headers',
                'status_code': resp.status_code,
                'server': headers.get('Server', 'unknown'),
                'technologies': self._detect_tech_from_headers(headers),
                'headers': headers
            }
        except Exception as e:
            return {'success': False, 'tool': 'http_headers', 'error': str(e)}

    async def _tool_directory_scan(self, target: str, tool: str) -> Dict:
        """使用工具进行目录扫描（通过ToolManager定位可执行文件+字典）"""
        if not target.startswith('http'):
            target = f"http://{target}"

        tm = get_tool_manager()
        cmd_base = tm.get_run_command(tool)
        if not cmd_base:
            return {'success': False, 'tool': tool, 'error': f'{tool}不可用。{tm.get_install_hint(tool)}'}

        # 查找字典文件
        wordlist = find_wordlist('common')

        try:
            if tool == 'dirsearch':
                cmd = cmd_base + ['-u', target, '--quiet', '-e', 'php,asp,aspx,jsp,html,js']
            elif tool == 'gobuster':
                if not wordlist:
                    return {'success': False, 'tool': 'gobuster',
                            'error': '未找到字典文件。请将字典放入 data/wordlists/common.txt'}
                cmd = cmd_base + ['dir', '-u', target, '-w', wordlist,
                                  '-x', 'php,asp,aspx,jsp,html,js', '-q']
            elif tool == 'feroxbuster':
                if not wordlist:
                    return {'success': False, 'tool': 'feroxbuster',
                            'error': '未找到字典文件。请将字典放入 data/wordlists/common.txt'}
                cmd = cmd_base + ['-u', target, '-w', wordlist,
                                  '-x', 'php,asp,aspx,jsp,html,js',
                                  '--quiet', '--no-recursion-depth']
            else:
                cmd = cmd_base + ['-u', target]

            self.logger.info(f"[InfoGathering] {tool}命令: {' '.join(cmd)}")
            self._emit_thinking("command", ' '.join(cmd))

            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), timeout=300
            )

            output = stdout.decode(errors='replace')
            # 解析目录扫描结果
            found_paths = []
            for line in output.strip().split('\n'):
                line = line.strip()
                if not line:
                    continue
                # feroxbuster: 200      24l     118w   1234c http://target/path
                # gobuster: /path (Status: 200) [Size: 1234]
                # dirsearch: 200   1234B  http://target/path
                status_match = re.search(r'(\d{3})', line)
                path_match = re.search(r'(https?://\S+|/\S+)', line)
                if status_match and path_match:
                    status = int(status_match.group(1))
                    if status in (200, 301, 302, 403):
                        found_paths.append({
                            'path': path_match.group(1),
                            'status': status,
                        })

            return {
                'success': True,
                'tool': tool,
                'output': output[:3000],
                'found_paths': found_paths,
                'total': len(found_paths)
            }
        except asyncio.TimeoutError:
            return {'success': False, 'tool': tool, 'error': f'{tool}扫描超时(300s)'}
        except Exception as e:
            return {'success': False, 'tool': tool, 'error': str(e)}

    async def _python_directory_scan(self, target: str) -> Dict:
        """Python原生目录扫描（降级方案）"""
        import requests
        if not target.startswith('http'):
            target = f"http://{target}"

        common_paths = [
            '/admin', '/login', '/backup', '/config', '/.git/config',
            '/.env', '/robots.txt', '/sitemap.xml', '/phpinfo.php',
            '/wp-admin', '/wp-login.php', '/api', '/docs', '/swagger',
            '/server-status', '/.DS_Store', '/WEB-INF/web.xml'
        ]

        found = []
        for path in common_paths:
            try:
                resp = requests.get(f"{target}{path}", timeout=5, verify=_VERIFY_SSL)
                if resp.status_code in [200, 301, 302, 403]:
                    found.append({
                        'path': path,
                        'status': resp.status_code,
                        'length': len(resp.text)
                    })
            except Exception:
                pass

        return {
            'success': True,
            'tool': 'python_requests',
            'found_paths': found,
            'count': len(found)
        }

    # =========================================================================
    # 辅助方法
    # =========================================================================

    def _parse_nmap_output(self, output: str) -> list:
        """解析Nmap输出"""
        ports = []
        for line in output.split('\n'):
            if '/tcp' in line and 'open' in line:
                parts = line.split()
                if len(parts) >= 3:
                    ports.append({
                        'port': parts[0].split('/')[0],
                        'state': 'open',
                        'service': parts[2] if len(parts) > 2 else 'unknown'
                    })
        return ports

    def _parse_masscan_output(self, output: str) -> list:
        """解析Masscan输出"""
        ports = []
        for line in output.split('\n'):
            if 'open tcp' in line:
                parts = line.split()
                if len(parts) >= 4:
                    ports.append({
                        'port': parts[3].split('/')[0],
                        'state': 'open',
                        'service': 'unknown'
                    })
        return ports

    def _parse_port_range(self, ports: str) -> list:
        """解析端口范围字符串"""
        port_list = []
        for part in ports.split(','):
            part = part.strip()
            if '-' in part:
                try:
                    start, end = map(int, part.split('-'))
                    port_list.extend(range(start, min(end + 1, 65536)))
                except ValueError:
                    pass
            else:
                try:
                    port_list.append(int(part))
                except ValueError:
                    pass
        # 限制最大端口数
        return port_list[:5000]

    def _get_service_name(self, port: int) -> str:
        """获取端口对应的服务名"""
        service_map = {
            21: 'ftp', 22: 'ssh', 23: 'telnet', 25: 'smtp', 53: 'dns',
            80: 'http', 110: 'pop3', 143: 'imap', 443: 'https',
            993: 'imaps', 995: 'pop3s', 1433: 'mssql', 1521: 'oracle',
            3306: 'mysql', 3389: 'rdp', 5432: 'postgresql',
            6379: 'redis', 8080: 'http-proxy', 8443: 'https-alt',
            27017: 'mongodb', 11211: 'memcached'
        }
        return service_map.get(port, 'unknown')

    def _detect_tech_from_headers(self, headers: Dict) -> List[str]:
        """从HTTP头部检测技术栈"""
        techs = []
        server = headers.get('Server', '')
        if 'apache' in server.lower():
            techs.append('Apache')
        if 'nginx' in server.lower():
            techs.append('Nginx')
        if 'iis' in server.lower():
            techs.append('IIS')

        powered = headers.get('X-Powered-By', '')
        if 'php' in powered.lower():
            techs.append('PHP')
        if 'asp' in powered.lower():
            techs.append('ASP.NET')
        if 'express' in powered.lower():
            techs.append('Express.js')

        return techs
