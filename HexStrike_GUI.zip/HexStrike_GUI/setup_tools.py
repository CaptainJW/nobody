#!/usr/bin/env python3
"""
HexStrike 工具一键安装脚本 (Kali/Linux 专用)

所有工具通过系统包管理器安装，无需本地源码。

使用方法:
    python3 setup_tools.py          # 交互式安装
    python3 setup_tools.py --auto   # 自动安装所有可安装的工具
    python3 setup_tools.py --check  # 仅检查工具状态
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path


def is_kali():
    try:
        if os.path.exists('/etc/os-release'):
            with open('/etc/os-release', 'r') as f:
                if 'kali' in f.read().lower():
                    return True
    except Exception:
        pass
    return False


IS_KALI = is_kali()


# 颜色输出
class C:
    G = '\033[92m'; Y = '\033[93m'; R = '\033[91m'; B = '\033[94m'; BD = '\033[1m'; E = '\033[0m'

def ok(m):   print(f"  {C.G}✅ {m}{C.E}")
def warn(m): print(f"  {C.Y}⚠️  {m}{C.E}")
def fail(m): print(f"  {C.R}❌ {m}{C.E}")
def info(m): print(f"  {C.B}ℹ️  {m}{C.E}")
def head(m): print(f"\n{C.BD}{'='*60}\n  {m}\n{'='*60}{C.E}"")


def check_command(name):
    return shutil.which(name) is not None


def check_all_tools():
    """检查所有工具状态"""
    head("🔧 HexStrike 工具状态检查")

    try:
        from agents.tool_manager import get_tool_manager
        tm = get_tool_manager()
        tm.refresh()
        all_tools = tm.get_all_tools()
        available = sum(1 for t in all_tools.values() if t.get('available'))
        total = len(all_tools)

        # 按分类显示
        categories = {
            'port_scan': '📡 端口扫描',
            'vuln_scan': '🔍 漏洞扫描',
            'fingerprint': '🖐 指纹识别',
            'dir_scan': '📂 目录扫描',
            'subdomain': '🌐 子域名枚举',
            'sqli_scan': '💉 SQL注入',
            'xss_scan': '✖️ XSS扫描',
            'ssl_scan': '🔒 SSL/TLS扫描',
            'dns': '📋 DNS工具',
            'web_scan': '🌍 Web扫描',
        }

        for cat_id, cat_name in categories.items():
            tools = tm.get_tools_by_category(cat_id)
            if not tools:
                continue
            print(f"\n  {cat_name}")
            for tool_name, info in tools.items():
                if info.get('available'):
                    ok(f"{tool_name} ({info.get('path', '')})")
                else:
                    fail(f"{tool_name} — 未安装")
                    registry = tm.TOOL_REGISTRY.get(tool_name, {})
                    apt_pkg = registry.get('apt')
                    go_pkg = registry.get('go')
                    pip_pkg = registry.get('pip')
                    if apt_pkg:
                        info(f"  → sudo apt install {apt_pkg}")
                    if pip_pkg:
                        info(f"  → pip install {pip_pkg}")
                    if go_pkg:
                        info(f"  → go install {go_pkg}")

        print(f"\n  {'='*50}")
        if available == total:
            ok(f"全部 {total} 个工具可用！")
        else:
            missing = [k for k, v in all_tools.items() if not v.get('available')]
            warn(f"{available}/{total} 可用，缺失: {', '.join(missing)}")
            print(f"\n  运行 {C.B}sudo python3 setup_tools.py --auto{C.E} 自动安装缺失工具")

        return all_tools

    except Exception as e:
        fail(f"工具检查失败: {e}")
        return {}


def auto_install():
    """自动安装所有缺失工具"""
    head("🚀 HexStrike 工具自动安装")

    if not IS_KALI and not os.path.exists('/etc/debian_version'):
        warn("非 Debian/Kali 系统，apt 安装可能不可用")
        print("  继续尝试安装...")

    # 先更新源
    info("更新软件源...")
    subprocess.run(['sudo', 'apt-get', 'update', '-qq'], timeout=60, capture_output=True)

    # APT 安装
    head("📦 APT 安装系统工具")
    apt_tools = [
        ('nmap', 'nmap'), ('masscan', 'masscan'), ('nuclei', 'nuclei'),
        ('whatweb', 'whatweb'), ('nikto', 'nikto'), ('dirsearch', 'dirsearch'),
        ('gobuster', 'gobuster'), ('feroxbuster', 'feroxbuster'),
        ('amass', 'amass'), ('subfinder', 'subfinder'), ('sqlmap', 'sqlmap'),
        ('dalfox', 'dalfox'), ('testssl.sh', 'testssl'),
        ('dnsrecon', 'dnsrecon'), ('dnsutils', 'dnsutils'),
        ('dirb', 'dirb'), ('ffuf', 'ffuf'), ('wpscan', 'wpscan'),
    ]

    apt_installed = 0
    apt_failed = 0
    for tool_name, apt_pkg in apt_tools:
        if check_command(tool_name):
            ok(f"{tool_name} — 已安装")
            apt_installed += 1
        else:
            print(f"  ⏳ 安装 {tool_name} ({apt_pkg})...")
            try:
                r = subprocess.run(
                    ['sudo', 'apt-get', 'install', '-y', '-qq', apt_pkg],
                    capture_output=True, timeout=120
                )
                if r.returncode == 0 and check_command(tool_name):
                    ok(f"{tool_name} — 安装成功")
                    apt_installed += 1
                else:
                    fail(f"{tool_name} — apt 安装失败")
                    apt_failed += 1
            except Exception as e:
                fail(f"{tool_name} — 安装超时: {e}")
                apt_failed += 1

    info(f"APT: {apt_installed} 成功, {apt_failed} 失败")

    # pip 安装
    head("🐍 PIP 安装 Python 工具")
    pip_tools = ['sslyze']
    for tool in pip_tools:
        print(f"  ⏳ 安装 {tool}...")
        try:
            r = subprocess.run(
                [sys.executable, '-m', 'pip', 'install', tool, '--break-system-packages', '-q'],
                capture_output=True, timeout=120
            )
            if r.returncode == 0:
                ok(f"{tool} — pip 安装成功")
            else:
                warn(f"{tool} — pip 安装失败: {r.stderr.decode(errors='replace')[:200]}")
        except Exception as e:
            warn(f"{tool} — pip 安装超时: {e}")

    # Go 编译安装
    head("🐹 Go 编译安装（补充 apt 未装的工具）")
    if shutil.which('go'):
        info(f"Go 版本: {shutil.run(['go', 'version'], capture_output=True, timeout=5).stdout.decode().strip()}" if shutil.which('go') else "")

        go_tools = {
            'dalfox': 'github.com/hahwul/dalfox/v2@latest',
            'subfinder': 'github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest',
            'nuclei': 'github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest',
            'gobuster': 'github.com/OJ/gobuster/v3@latest',
            'ffuf': 'github.com/ffuf/ffuf/v2@latest',
        }
        gopath = os.environ.get('GOPATH', os.path.expanduser('~/go'))

        # 配置国内 Go 代理镜像（解决 proxy.golang.org 被墙问题）
        go_env = {
            **os.environ,
            'GOPATH': gopath,
            'GOPROXY': 'https://goproxy.cn,https://goproxy.io,direct',
            'GONOSUMCHECK': '*',
            'GO111MODULE': 'on',
            'PATH': os.environ.get('PATH', '') + f':{gopath}/bin:/usr/local/go/bin',
        }

        for tool, pkg in go_tools.items():
            if check_command(tool):
                ok(f"{tool} — 已在PATH中")
            else:
                print(f"  ⏳ go install {tool}...")
                try:
                    r = subprocess.run(
                        ['go', 'install', pkg],
                        capture_output=True, timeout=300, text=True,
                        env=go_env
                    )
                    if r.returncode == 0:
                        bin_path = os.path.join(gopath, 'bin', tool)
                        if os.path.exists(bin_path):
                            link = os.path.expanduser(f'~/.local/bin/{tool}')
                            os.makedirs(os.path.dirname(link), exist_ok=True)
                            if os.path.exists(link) or os.path.islink(link):
                                os.remove(link)
                            os.symlink(bin_path, link)
                            subprocess.run(['sudo', 'ln', '-sf', bin_path, f'/usr/local/bin/{tool}'],
                                           timeout=5, capture_output=True)
                        ok(f"{tool} — 编译安装成功")
                    else:
                        fail(f"{tool} — 编译失败: {r.stderr[:200]}")
                except Exception as e:
                    fail(f"{tool} — 编译超时: {e}")
    else:
        warn("Go 未安装，跳过编译安装")
        info("安装 Go: sudo apt install golang")

    # 权限设置
    head("🔐 配置工具权限")
    for tool in ['nmap', 'masscan']:
        tp = shutil.which(tool)
        if tp:
            r = subprocess.run(['sudo', 'setcap', 'cap_net_raw+ep', tp],
                               capture_output=True, timeout=5)
            if r.returncode == 0:
                ok(f"{tool}: 网络权限已设置")
            else:
                warn(f"{tool}: 权限设置失败")

    # Nuclei 模板
    if check_command('nuclei'):
        info("更新 Nuclei 模板...")
        subprocess.run(['nuclei', '-update-templates'], capture_output=True, timeout=120)
        ok("Nuclei 模板已更新")

    # 字典检查
    head("📝 字典文件检查")
    wordlist_found = False
    for wdir in ['/usr/share/wordlists/dirb', '/usr/share/seclists/Discovery/Web-Content',
                 '/usr/share/wordlists/dirbuster']:
        if os.path.isdir(wdir):
            ok(f"字典目录: {wdir}")
            wordlist_found = True
    if not wordlist_found:
        warn("未发现系统字典目录")
        info("安装 SecLists: sudo apt install seclists")

    # 最终检查
    head("📊 最终检查")
    check_all_tools()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == '--auto':
            auto_install()
        elif sys.argv[1] == '--check':
            check_all_tools()
        elif sys.argv[1] == '--help':
            print(__doc__)
        else:
            print(f"未知参数: {sys.argv[1]}")
            print("用法: sudo python3 setup_tools.py [--auto|--check|--help]")
    else:
        head("🛠️  HexStrike 工具安装")
        print("""
  选择安装模式:
    1) 全部自动安装 (推荐 Kali/Debian)
    2) 仅检查工具状态
    0) 退出
""")
        try:
            choice = input("请选择 [0-2]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n退出")
            sys.exit(0)

        if choice == '1':
            auto_install()
        elif choice == '2':
            check_all_tools()
        else:
            print("退出")
