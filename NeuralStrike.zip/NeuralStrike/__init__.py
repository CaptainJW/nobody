#!/usr/bin/env python3
"""
HexStrike AI — 智能渗透测试平台（Web 版）
"""

import os
import sys

# 确保项目根目录在 Python 路径中
_current_dir = os.path.dirname(os.path.abspath(__file__))
if _current_dir not in sys.path:
    sys.path.insert(0, _current_dir)

__version__ = "3.0.0"
__author__ = "HexStrike Team"

__all__ = []
