#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NeuralStrike AI — Web 界面服务端
独立 Flask 服务，端口 7777
"""
# 版本标记 — 用于验证Kali是否同步了最新代码
_CODE_VERSION = '2024-04-17-v2'

import sys
import os
import json
import uuid
import asyncio
import threading
import time
import logging
from queue import Queue, Empty
from datetime import datetime

from flask import Flask, request, jsonify, Response, send_from_directory

# 确保项目根目录在 sys.path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

app = Flask(__name__, static_folder='web/static', static_url_path='/static')

# 注册独立聊天 Blueprint（即使主文件有问题也能工作）
try:
    from chat_api import chat_bp
    app.register_blueprint(chat_bp, url_prefix='/api')
    logger_info = logging.getLogger('web_server')
    logger_info.info('✅ 聊天 Blueprint 已注册 (/api/chat)')
except Exception as _bp_err:
    logging.getLogger('web_server').error(f'⚠️ 聊天 Blueprint 注册失败: {_bp_err}')

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger('web_server')

# SEC-02修复: 启动时生成随机访问令牌
import secrets as _secrets
_ACCESS_TOKEN = os.environ.get('NEURALSTRIKE_TOKEN', '')  # 环境变量优先
if not _ACCESS_TOKEN:
    _ACCESS_TOKEN = _secrets.token_hex(16)
    logger.info(f"🔑 访问令牌: {_ACCESS_TOKEN} (设置环境变量 NEURALSTRIKE_TOKEN 可自定义)")

def _check_auth():
    """检查请求是否携带有效令牌（仅高危接口需要）"""
    # 本地请求免认证
    if request.remote_addr in ('127.0.0.1', '::1', 'localhost'):
        return True
    # 局域网 IP 免认证（192.168.x.x / 10.x.x.x / 172.16-31.x.x）
    try:
        import ipaddress
        addr = ipaddress.ip_address(request.remote_addr)
        if addr.is_private or addr.is_loopback:
            return True
    except (ValueError, TypeError):
        pass
    # 检查 Authorization header 或 query 参数
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    if not token:
        token = request.args.get('token', '')
    return token == _ACCESS_TOKEN

# ============================================================================
# Provider 注册表 — 优先从 agents/ai_client.py 复用，避免数据不一致
# ============================================================================

try:
    from agents.ai_client import PROVIDER_REGISTRY as _AI_PROVIDER_REGISTRY
    # 从统一注册表构建 Web 版本（去掉不可序列化的 client_class）
    WEB_PROVIDER_REGISTRY = {}
    for pid, info in _AI_PROVIDER_REGISTRY.items():
        WEB_PROVIDER_REGISTRY[pid] = {k: v for k, v in info.items() if k != 'client_class'}
except ImportError:
    # 降级：内嵌备份数据
    WEB_PROVIDER_REGISTRY = {
        "openai": {"name": "OpenAI", "icon": "🟢", "default_base_url": "https://api.openai.com/v1", "default_model": "gpt-4", "models": ["gpt-4", "gpt-4-turbo", "gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo"], "description": "OpenAI GPT 系列大模型", "api_key_placeholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxx", "models_endpoint": "/models", "supports_model_fetch": True},
        "deepseek": {"name": "DeepSeek", "icon": "🔵", "default_base_url": "https://api.deepseek.com/v1", "default_model": "deepseek-chat", "models": ["deepseek-chat", "deepseek-reasoner"], "description": "DeepSeek 深度求索大模型", "api_key_placeholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxx", "models_endpoint": "/models", "supports_model_fetch": True},
        "siliconflow": {"name": "硅基流动 SiliconFlow", "icon": "🟣", "default_base_url": "https://api.siliconflow.cn/v1", "default_model": "Qwen/Qwen2.5-72B-Instruct-AWQ", "models": ["Qwen/Qwen2.5-72B-Instruct-AWQ", "Qwen/Qwen2.5-7B-Instruct", "deepseek-ai/DeepSeek-V3", "deepseek-ai/DeepSeek-R1", "THUDM/glm-4-9b-chat"], "description": "硅基流动聚合多模型平台", "api_key_placeholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxx", "models_endpoint": "/models", "supports_model_fetch": True},
        "qwen": {"name": "通义千问 Qwen", "icon": "🟠", "default_base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1", "default_model": "qwen-turbo", "models": ["qwen-turbo", "qwen-plus", "qwen-max", "qwen-long"], "description": "阿里云通义千问大模型", "api_key_placeholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxx", "models_endpoint": "/models", "supports_model_fetch": True},
        "zhipu": {"name": "智谱AI ChatGLM", "icon": "🔷", "default_base_url": "https://open.bigmodel.cn/api/paas/v4", "default_model": "glm-4-flash", "models": ["glm-4-flash", "glm-4-air", "glm-4", "glm-4-plus"], "description": "智谱AI GLM 系列大模型", "api_key_placeholder": "xxxxxxxxxxxxxxxxxxxxxxxx.xxxxxxxx", "models_endpoint": "/models", "supports_model_fetch": True},
        "kimi": {"name": "月之暗面 Kimi", "icon": "🌙", "default_base_url": "https://api.moonshot.cn/v1", "default_model": "moonshot-v1-8k", "models": ["moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-128k"], "description": "月之暗面 Kimi 大模型", "api_key_placeholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxx", "models_endpoint": "/models", "supports_model_fetch": True},
        "claude": {"name": "Anthropic Claude", "icon": "🟤", "default_base_url": "https://api.anthropic.com/v1", "default_model": "claude-3-5-sonnet-20241022", "models": ["claude-3-5-sonnet-20241022", "claude-3-5-haiku-20241022", "claude-3-opus-20240229"], "description": "Anthropic Claude 系列大模型", "api_key_placeholder": "sk-ant-xxxxxxxxxxxxxxxxxxxxxxxx", "models_endpoint": None, "supports_model_fetch": False},
    }

# ============================================================================
# 扫描状态管理
# ============================================================================

SCANS = {}          # scan_id -> ScanState dict
SCANS_LOCK = threading.Lock()
MAX_SCAN_AGE = 3600  # 保留1小时后自动清理


def _cleanup_old_scans():
    """清理过期的扫描状态，防止内存泄漏"""
    now = time.time()
    with SCANS_LOCK:
        to_delete = [
            sid for sid, s in SCANS.items()
            if s['status'] in ('finished', 'error', 'stopped')
            and now - s.get('created_at', 0) > MAX_SCAN_AGE
        ]
        for sid in to_delete:
            SCANS.pop(sid, None)
            CHAT_QUEUES.pop(sid, None)


def _new_scan_state(scan_id: str, target: str) -> dict:
    return {
        'id': scan_id,
        'status': 'running',
        'target': target,
        'created_at': time.time(),
        'queue': Queue(),
        'thread': None,
        'result': None,
        'stop_event': threading.Event(),
        'paused': False,
        'report': None,
        'report_error': None,
    }


# ============================================================================
# 独立AI对话 — 不需要开始扫描也能与AI交流并执行命令
# ============================================================================

CHAT_HISTORY = []  # 全局对话历史 [{role, content}, ...]
CHAT_HISTORY_LOCK = threading.Lock()


@app.route('/api/chat', methods=['POST'])
def api_chat():
    """独立AI对话接口 — 支持自由聊天和工具命令执行"""
    data = request.get_json(silent=True) or {}
    message = data.get('message', '').strip()
    if not message:
        return jsonify({'error': '消息不能为空'}), 400

    # 获取AI配置
    try:
        from config.ai_manager import AIConfigManager
        mgr = AIConfigManager()
        if not mgr.is_configured():
            return jsonify({'error': 'AI 服务未配置，请先在 API 设置中配置'}), 503
        ai_config = mgr.get_ai_config()
    except Exception as e:
        return jsonify({'error': f'加载 AI 配置失败: {e}'}), 500

    # 保存用户消息到历史
    with CHAT_HISTORY_LOCK:
        CHAT_HISTORY.append({'role': 'user', 'content': message})
        # 限制历史长度
        if len(CHAT_HISTORY) > 50:
            CHAT_HISTORY[:] = CHAT_HISTORY[-50:]

    # 检测是否是工具命令（如 "arp-scan 192.168.1.0/24"）
    tool_result = _try_execute_tool_command(message)

    # 构建AI系统提示
    system_prompt = """你是 NeuralStrike AI 渗透测试助手。你可以：
1. 回答安全相关问题和指导渗透测试
2. 帮助用户理解和分析扫描结果
3. 根据用户描述执行工具命令（如 arp-scan、nmap、sqlmap 等）
4. 提供漏洞利用和修复建议

当用户要求执行命令时，系统会自动检测并执行以下工具：
- 网络扫描: arp-scan, nmap, masscan
- 漏洞扫描: nuclei, nikto
- Web测试: sqlmap, dalfox, dirsearch, gobuster, feroxbuster
- DNS/子域名: amass, subfinder, dnsrecon
- SSL: testssl, sslyze
- 密码: hydra, john, hashcat
- 后渗透: chisel, crackmapexec, bloodhound
- 其他: curl, wget, whatweb, wpscan

如果用户请求的工具命令已经执行，你会在上下文中看到执行结果。
请根据执行结果给出专业分析。"""

    # 构建消息列表
    with CHAT_HISTORY_LOCK:
        messages = CHAT_HISTORY[-20:]  # 最近20条

    # 拼接工具执行结果
    context_parts = []
    if tool_result:
        context_parts.append(f"[系统] 已执行工具命令:\n{tool_result}")
    
    # 调用AI
    try:
        from agents.ai_client import AIAgentFactory, AISession
        client = AIAgentFactory.create_client(ai_config['provider'], ai_config['config'])
        session = AISession(client, system_prompt)
        # 将历史消息拼接成上下文
        context_msg = ""
        if context_parts:
            context_msg = "\n\n[系统上下文]\n" + "\n".join(context_parts)
        
        full_message = message + context_msg
        response = session.chat(full_message)
        ai_reply = response if isinstance(response, str) else str(response)

        # 保存AI回复到历史
        with CHAT_HISTORY_LOCK:
            CHAT_HISTORY.append({'role': 'assistant', 'content': ai_reply})

        result = {
            'reply': ai_reply,
            'tool_executed': tool_result is not None,
        }
        if tool_result:
            result['tool_result'] = tool_result

        return jsonify(result)

    except Exception as e:
        logger.error(f'AI对话失败: {e}')
        # AI失败但工具可能已执行
        if tool_result:
            return jsonify({
                'reply': f'AI 响应失败，但工具命令已执行:\n\n{tool_result}',
                'tool_executed': True,
                'tool_result': tool_result,
                'ai_error': str(e),
            })
        return jsonify({'error': f'AI 对话失败: {e}'}), 500


def _try_execute_tool_command(message: str) -> str:
    """检测并执行用户消息中的工具命令，返回执行结果或None"""
    import shlex
    import subprocess
    import shutil

    # 已知工具名 → 命令映射
    KNOWN_TOOLS = [
        'arp-scan', 'nmap', 'masscan', 'nuclei', 'nikto',
        'sqlmap', 'dalfox', 'dirsearch', 'gobuster', 'feroxbuster',
        'amass', 'subfinder', 'dnsrecon', 'testssl', 'sslyze',
    'hydra', 'john', 'hashcat',
    'chisel', 'crackmapexec', 'nxc', 'bloodhound',
        'curl', 'wget', 'whatweb', 'wpscan', 'ffuf',
        'whois', 'dig', 'host', 'traceroute', 'ping',
        'netstat', 'ss', 'ifconfig', 'ip',
    ]

    msg_lower = message.lower().strip()

    # 检测格式1: 直接命令 "arp-scan 192.168.1.0/24"
    first_word = msg_lower.split()[0] if msg_lower.split() else ''
    if first_word in KNOWN_TOOLS or first_word.replace('-', '') in [t.replace('-', '') for t in KNOWN_TOOLS]:
        # 找到原始大小写的命令
        words = message.strip().split()
        cmd_str = message.strip()
        # 安全检查：阻止危险命令
        dangerous = ['rm ', 'del ', 'format', 'shutdown', 'reboot', 'mkfs', 'dd if=']
        if any(d in msg_lower for d in dangerous):
            return f"❌ 拒绝执行危险命令: {cmd_str}"

        # 检查工具是否存在
        tool_name = words[0]
        if not shutil.which(tool_name):
            return f"❌ 工具 '{tool_name}' 未安装。请前往 🔧 工具管理 页面安装。"

        # 执行命令（30秒超时）
        try:
            result = subprocess.run(
                cmd_str, shell=True, capture_output=True, text=True, timeout=30,
                stdin=subprocess.DEVNULL  # 防止子进程抢占tty导致suspended
            )
            output = result.stdout[:5000] if result.stdout else ''
            error = result.stderr[:2000] if result.stderr else ''
            if result.returncode != 0 and not output:
                return f"❌ 命令执行失败 (退出码 {result.returncode}):\n{error or '无输出'}"
            if error and output:
                return f"{output}\n\n[stderr] {error[:500]}"
            return output or "(无输出)"
        except subprocess.TimeoutExpired:
            return f"⏱️ 命令执行超时 (30秒)。建议添加更严格的参数减少扫描范围。"
        except Exception as e:
            return f"❌ 执行失败: {e}"

    # 检测格式2: 自然语言 "扫描局域网" / "用arp-scan扫描网段"
    nl_tool_patterns = [
        (r'(?:扫描|scan)\s*(?:局域网|内网|网段|局域)', 'arp-scan -l'),
        (r'(?:端口扫描|port\s*scan)', 'nmap -sV -T4'),
        (r'(?:漏洞扫描|vuln.*scan)', 'nuclei'),
        (r'(?:子域名|subdomain)', 'subfinder -d'),
        (r'(?:目录扫描|dir.*scan)', 'dirsearch -u'),
        (r'(?:指纹识别|fingerprint)', 'whatweb'),
        (r'(?:ssl|证书)', 'testssl'),
        (r'(?:dns|域名解析)', 'dig'),
        (r'(?:谁在线|主机发现|host\s*discover)', 'arp-scan -l'),
    ]

    import re
    for pattern, cmd in nl_tool_patterns:
        if re.search(pattern, msg_lower):
            # 自然语言匹配成功，但需要更多信息
            if 'arp-scan' in cmd and '-' not in message and '/' not in message:
                # 没有指定目标网段，使用 -l (本地网段)
                if shutil.which('arp-scan'):
                    try:
                        result = subprocess.run(
                            ['arp-scan', '-l'], capture_output=True, text=True, timeout=60,
                            stdin=subprocess.DEVNULL
                        )
                        return result.stdout[:5000] or "(无输出)"
                    except Exception as e:
                        return f"❌ arp-scan 执行失败: {e}"
                else:
                    return "❌ arp-scan 未安装。请前往 🔧 工具管理 页面安装。"
            # 其他自然语言命令需要用户指定目标
            return None

    # 不是工具命令
    return None


# ============================================================================
# 扫描 Worker 线程
# ============================================================================

# 进度里程碑：根据 thinking_type 递增，防止倒退
THINKING_PROGRESS = {
    'analyze':  20,
    'plan':     35,
    'action':   50,
    'evaluate': 75,
    'decide':   80,
}


def _scan_worker(scan_id: str, target: str, options: dict, ai_config: dict):
    """在后台线程中运行扫描，通过 Queue 推送 SSE 事件"""
    scan = SCANS.get(scan_id)
    if not scan:
        return

    q: Queue = scan['queue']
    stop_event: threading.Event = scan['stop_event']
    last_progress = [5]  # mutable for inner closure

    def emit(event_type: str, data: dict):
        q.put({'type': event_type, 'data': data})

    def emit_log(msg: str):
        ts = datetime.now().strftime('%H:%M:%S')
        emit('log', {'message': f'[{ts}] {msg}'})

    def emit_progress(value: int, msg: str):
        # 进度只增不减
        value = max(value, last_progress[0])
        last_progress[0] = value
        emit('progress', {'value': value, 'message': msg})

    def thinking_callback(t_type: str, content: str, agent: str):
        emit('thinking', {
            'thinking_type': t_type,
            'content': content,
            'agent': agent,
        })
        # 根据思考类型推进进度
        prog = THINKING_PROGRESS.get(t_type, 0)
        if prog > last_progress[0]:
            messages = {
                'analyze':  '执行初始分析...',
                'plan':     '制定测试策略...',
                'action':   '执行扫描动作...',
                'evaluate': '评估扫描结果...',
                'decide':   '做出决策...',
            }
            emit_progress(prog, messages.get(t_type, '处理中...'))

        content_lower = content.lower() if content else ''

        # 检测工具调用 — 如果内容包含工具名 + 调用/使用关键词
        TOOL_NAMES = ['nmap', 'masscan', 'nuclei', 'whatweb', 'dirsearch', 'gobuster',
                       'feroxbuster', 'amass', 'subfinder', 'sqlmap', 'dalfox', 'sslyze',
                       'testssl', 'nikto', 'dnsrecon', 'dig', 'ffuf', 'dirb', 'wpscan',
                       'python', 'curl', 'wget']
        for tool in TOOL_NAMES:
            if tool in content_lower and any(k in content for k in ['调用', '使用', '执行', '🔧', 'tool', 'run']):
                emit('tool_call', {
                    'tool_name': tool,
                    'purpose': content.split('|')[0].replace('🔧', '').replace('调用工具:', '').strip()[:80] if '|' in content else t_type,
                    'params': content,
                    'agent': agent,
                })
                break

        # 检测命令行 — 更精确的检测
        # 1. 内容直接就是命令（以工具名开头，含 -或-- 参数）
        CMD_TOOLS = ['nmap', 'nuclei', 'gobuster', 'dirsearch', 'feroxbuster',
                     'sqlmap', 'dalfox', 'subfinder', 'amass', 'masscan',
                     'whatweb', 'nikto', 'sslyze', 'testssl', 'dig',
                     'dnsrecon', 'ffuf', 'dirb', 'wpscan', 'curl', 'wget',
                     'python', 'python3']
        first_word = content.strip().split()[0].lower() if content.strip() else ''
        is_direct_command = first_word in CMD_TOOLS and (' -' in content or '--' in content)

        # 2. 内容包含"命令:"标记
        is_labeled_command = '命令:' in content or 'command:' in content_lower

        # 3. 内容包含典型命令行参数
        CMD_FLAGS = [' -s', ' -p ', ' -u ', ' -d ', ' -w ', ' -t ', ' -o ',
                     ' -e ', ' -v ', ' -a ', '--silent', '--json', '--quiet',
                     '--deep', '--stealth', '--timeout', '--rate', '--threads']
        has_cmd_flags = any(flag in content for flag in CMD_FLAGS)

        if is_direct_command or is_labeled_command:
            # 提取纯命令（去掉标签前缀）
            cmd_text = content
            if '命令:' in cmd_text:
                cmd_text = cmd_text.split('命令:', 1)[1].strip()
            elif 'command:' in cmd_text.lower():
                cmd_text = cmd_text.lower().split('command:', 1)[1].strip()
            emit('command', {'command': cmd_text, 'agent': agent})
        elif has_cmd_flags and any(t in content_lower for t in CMD_TOOLS):
            # 包含命令行特征但不是纯命令，尝试提取命令部分
            for line in content.split('\n'):
                line_stripped = line.strip()
                if any(line_stripped.lower().startswith(t) for t in CMD_TOOLS):
                    emit('command', {'command': line_stripped, 'agent': agent})
                    break

        # 检测结果输出
        RESULT_KEYWORDS = ['发现', '端口', '开放', '漏洞', '子域名', 'CVE', 'HTTP',
                           'found', 'open', 'vuln', 'duplicate', '执行完成', '检出']
        if t_type == 'evaluate' or (t_type == 'action' and any(k in content for k in RESULT_KEYWORDS)):
            stats = {}
            if '端口' in content or 'port' in content_lower:
                import re as _re
                m = _re.search(r'(\d+)\s*个?\s*端口', content)
                stats['ports'] = int(m.group(1)) if m else 1
            if '漏洞' in content or 'vuln' in content_lower:
                stats['vulns'] = 1
            if '子域名' in content or 'subdomain' in content_lower:
                stats['subdomains'] = 1
            if '路径' in content or 'path' in content_lower or '目录' in content:
                stats['paths'] = 1
            emit('scan_result', {
                'summary': content[:200],
                'content': content,
                'agent': agent,
                'stats': stats,
            })

    try:
        emit_progress(5, '加载工作流编排器...')
        emit_log(f'目标: {target}')
        emit_log(f'AI 供应商: {ai_config.get("provider", "unknown")}')

        if stop_event.is_set():
            _finish_scan(scan, q, False, '扫描已被用户停止')
            return

        from agents.workflow_orchestrator import WorkflowOrchestrator

        emit_progress(10, 'AI 初始分析中...')
        emit_log('初始化 AI 工作流编排器...')

        # 发送阶段事件：初始化
        emit('phase', {'name': '🧩 初始分析', 'status': 'active'})

        orchestrator = WorkflowOrchestrator(ai_config)
        orchestrator.set_thinking_callback(thinking_callback)
        orchestrator.set_scan_id(scan_id)  # 设置扫描ID，支持用户交互

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        try:
            result = loop.run_until_complete(
                orchestrator.execute_intelligent_workflow(target, options)
            )
        finally:
            loop.close()

        if stop_event.is_set():
            _finish_scan(scan, q, False, '扫描已被用户停止')
            return

        emit_progress(95, '生成报告...')
        emit('result', {'data': result})
        scan['result'] = result
        # 保存SharedMemory上下文供报告生成使用
        try:
            loop2 = asyncio.new_event_loop()
            asyncio.set_event_loop(loop2)
            try:
                scan['shared_memory_context'] = loop2.run_until_complete(
                    orchestrator.shared_memory.get_context())
            finally:
                loop2.close()
        except Exception:
            scan['shared_memory_context'] = {}
        emit_progress(100, '完成!')
        emit_log('渗透测试完成！')
        _finish_scan(scan, q, True, '渗透测试完成')

    except ImportError as e:
        emit_log(f'模块导入失败: {e}')
        emit('error', {'message': f'依赖缺失: {e}'})
        _finish_scan(scan, q, False, f'依赖缺失: {e}')
    except Exception as e:
        logger.exception('Scan worker error')
        emit('error', {'message': str(e)})
        _finish_scan(scan, q, False, f'扫描失败: {e}')


def _finish_scan(scan: dict, q: Queue, success: bool, message: str):
    scan['status'] = 'finished' if success else ('stopped' if '停止' in message else 'error')
    q.put({'type': 'finished', 'data': {'success': success, 'message': message}})
    # 清理过期扫描状态
    _cleanup_old_scans()


# ============================================================================
# 目标验证
# ============================================================================

import re
from urllib.parse import urlparse

# 支持 http://host:port/path?query=value&key=val 形式的完整URL
_TARGET_RE = re.compile(
    r'^(https?://)?'
    r'(([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}'
    r'|\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
    r'(:\d{1,5})?'
    r'(/[^\s]*)?'   # 路径 + 查询字符串
    r'(\?[^\s]*)?'  # ?key=value&key2=val2
    r'$'
)

# 只禁止真正的Shell注入元字符，允许 URL 中的 & ? = % 等字符
_DANGEROUS = set(';|`$\n\r')


def _validate_target(target: str):
    """返回 (ok: bool, error_msg: str)"""
    if not target or not target.strip():
        return False, '目标地址不能为空'
    target = target.strip()
    # 检查危险字符（;|`$ 换行回车）— 允许 & ? = % 用于URL查询参数
    for c in target:
        if c in _DANGEROUS:
            return False, f'目标地址包含非法字符: {repr(c)}'
    # 如果是完整URL，用urllib先解析验证
    if target.startswith(('http://', 'https://')):
        try:
            parsed = urlparse(target)
            if not parsed.hostname:
                return False, 'URL中缺少主机名'
            return True, ''
        except Exception as e:
            return False, f'URL格式无效: {e}'
    # 非URL（IP或域名），用正则
    if not _TARGET_RE.match(target):
        return False, '请输入有效的 IP 地址、域名或 URL'
    return True, ''


# ============================================================================
# 密钥脱敏
# ============================================================================

def _mask_key(key: str) -> str:
    if not key or len(key) <= 8:
        return '****'
    return key[:4] + '*' * (len(key) - 8) + key[-4:]


# ============================================================================
# 路由：静态文件 & 主页
# ============================================================================

@app.route('/')
def index():
    return send_from_directory('web', 'index.html')


# ============================================================================
# 路由：扫描管理
# ============================================================================

@app.route('/api/scan/start', methods=['POST'])
def scan_start():
    data = request.get_json(force=True) or {}
    target = (data.get('target') or '').strip()

    ok, err = _validate_target(target)
    if not ok:
        return jsonify({'error': err}), 400

    # 加载 AI 配置
    try:
        from config.ai_manager import AIConfigManager
        mgr = AIConfigManager()
        if not mgr.is_configured():
            return jsonify({'error': 'AI 服务未配置，请先在 API 设置中配置'}), 503
        ai_config = mgr.get_ai_config()
    except Exception as e:
        return jsonify({'error': f'加载 AI 配置失败: {e}'}), 500

    options = {
        'port_scan':    bool(data.get('port_scan', True)),
        'vuln_scan':    bool(data.get('vuln_scan', True)),
        'web_scan':     bool(data.get('web_scan', True)),
        'stealth_mode': bool(data.get('stealth_mode', False)),
        'deep_scan':    bool(data.get('deep_scan', False)),
        'selected_agents': data.get('selected_agents', ['info', 'vuln', 'web', 'report']),
        'mode':         data.get('mode', 'ai'),
    }

    scan_id = str(uuid.uuid4())
    state = _new_scan_state(scan_id, target)

    t = threading.Thread(
        target=_scan_worker,
        args=(scan_id, target, options, ai_config),
        daemon=True,
    )
    state['thread'] = t

    with SCANS_LOCK:
        SCANS[scan_id] = state

    t.start()
    logger.info('Scan started: %s target=%s', scan_id, target)
    return jsonify({'scan_id': scan_id, 'status': 'started', 'target': target})


@app.route('/api/scan/<scan_id>/stream')
def scan_stream(scan_id: str):
    with SCANS_LOCK:
        scan = SCANS.get(scan_id)
    if not scan:
        def not_found():
            yield f'event: error\ndata: {json.dumps({"message": "Scan not found"})}\n\n'
            yield f'event: finished\ndata: {json.dumps({"success": False})}\n\n'
        return Response(not_found(), mimetype='text/event-stream')

    def generate():
        q: Queue = scan['queue']
        last_ping = time.time()
        while True:
            # 保活 ping
            if time.time() - last_ping > 20:
                yield 'event: ping\ndata: {}\n\n'
                last_ping = time.time()

            try:
                event = q.get(timeout=1)
                evt_type = event['type']
                evt_data = json.dumps(event['data'], ensure_ascii=False)
                yield f'event: {evt_type}\ndata: {evt_data}\n\n'
                if evt_type == 'finished':
                    break
            except Empty:
                with SCANS_LOCK:
                    is_finished = scan['status'] in ('finished', 'error', 'stopped')
                if is_finished:
                    yield f'event: finished\ndata: {json.dumps({"success": False, "message": "已结束"})}\n\n'
                    break

    # SEC-03 修复: 限制CORS为同源
    headers = {
        'Cache-Control': 'no-cache',
        'X-Accel-Buffering': 'no',
        'Access-Control-Allow-Origin': request.host_url.rstrip('/'),
    }
    return Response(generate(), mimetype='text/event-stream', headers=headers)


@app.route('/api/scan/<scan_id>/stop', methods=['POST'])
def scan_stop(scan_id: str):
    with SCANS_LOCK:
        scan = SCANS.get(scan_id)
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    scan['stop_event'].set()
    scan['queue'].put({
        'type': 'finished',
        'data': {'success': False, 'message': '用户已停止扫描'},
    })
    scan['status'] = 'stopped'
    return jsonify({'status': 'stopped'})


@app.route('/api/scan/<scan_id>/status')
def scan_status(scan_id: str):
    with SCANS_LOCK:
        scan = SCANS.get(scan_id)
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    return jsonify({
        'status': scan['status'],
        'target': scan['target'],
        'result': scan.get('result'),
    })


@app.route('/api/scan/<scan_id>', methods=['DELETE'])
def scan_delete(scan_id: str):
    with SCANS_LOCK:
        SCANS.pop(scan_id, None)
    return jsonify({'deleted': True})


# ============================================================================
# 路由：AI 配置
# ============================================================================

@app.route('/api/config')
def config_get():
    try:
        from config.ai_manager import AIConfigManager
        mgr = AIConfigManager()
        active = mgr.get_active_provider()

        providers_out = {}
        cfg_providers = mgr.config.get('providers', {})
        for pid, pinfo in WEB_PROVIDER_REGISTRY.items():
            pdata = cfg_providers.get(pid, {})
            raw_key = pdata.get('api_key', '')
            is_cfg = bool(raw_key and not raw_key.startswith('your-') and not raw_key.startswith('sk-your'))
            providers_out[pid] = {
                'api_key': _mask_key(raw_key) if is_cfg else '',
                'has_saved_key': is_cfg,  # ✅ 新增：标记是否已有已保存的key
                'model': pdata.get('model', pinfo['default_model']),
                'base_url': pdata.get('base_url', pinfo['default_base_url']),
                'is_configured': is_cfg,
                'is_default': (pid == active),
            }

        return jsonify({
            'default_provider': mgr.config.get('default_provider', 'openai'),
            'active_provider': active,
            'providers': providers_out,
            'has_any_configured': any(p['is_configured'] for p in providers_out.values()),
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/config/provider', methods=['POST'])
def config_save_provider():
    data = request.get_json(force=True) or {}
    provider = data.get('provider', '').strip()
    if not provider or provider not in WEB_PROVIDER_REGISTRY:
        return jsonify({'error': '无效的供应商 ID'}), 400

    try:
        from config.ai_manager import AIConfigManager
        mgr = AIConfigManager()

        api_key = (data.get('api_key') or '').strip()

        # 🐛 修复：如果前端传入的key是脱敏掩码（包含****），忽略它
        if '****' in api_key:
            api_key = None  # 不覆盖已有key

        # 🐛 修复：如果key为空，也不覆盖已有key（用户可能只是改了模型或URL）
        if not api_key:
            api_key = None  # 不覆盖已有key

        mgr.save_provider(
            provider_name=provider,
            api_key=api_key,
            model=data.get('model'),
            base_url=data.get('base_url'),
        )
        return jsonify({'success': True, 'message': '配置已保存'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/config/default', methods=['POST'])
def config_set_default():
    data = request.get_json(force=True) or {}
    provider = data.get('provider', '').strip()
    if not provider or provider not in WEB_PROVIDER_REGISTRY:
        return jsonify({'error': '无效的供应商 ID'}), 400

    try:
        from config.ai_manager import AIConfigManager
        AIConfigManager().set_default_provider(provider)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/config/test', methods=['POST'])
def config_test():
    """测试 API 连接，不写入磁盘"""
    import requests as http_req
    data = request.get_json(force=True) or {}
    provider = data.get('provider', '')
    api_key = (data.get('api_key') or '').strip()
    base_url = (data.get('base_url') or '').strip().rstrip('/')
    model = (data.get('model') or '').strip()

    # 🐛 修复：如果前端传入的是脱敏key，忽略它
    if '****' in api_key:
        api_key = ''

    # 🐛 修复：如果key为空，尝试从已保存的配置中读取
    if not api_key:
        try:
            from config.ai_manager import AIConfigManager
            mgr = AIConfigManager()
            saved_key = mgr.config.get('providers', {}).get(provider, {}).get('api_key', '')
            if saved_key and not saved_key.startswith('your-') and not saved_key.startswith('sk-your'):
                api_key = saved_key
        except Exception:
            pass

    if not api_key:
        return jsonify({'success': False, 'message': 'API 密钥不能为空，请先输入或保存密钥'})
    if not base_url:
        # 尝试从注册表获取
        base_url = WEB_PROVIDER_REGISTRY.get(provider, {}).get('default_base_url', '')
    if not base_url:
        return jsonify({'success': False, 'message': '接口地址不能为空'})
    if not model:
        info = WEB_PROVIDER_REGISTRY.get(provider, {})
        model = info.get('default_model', 'gpt-3.5-turbo')

    # 🔒 安全：不记录完整密钥
    logger.info(f'测试连接: provider={provider}, base_url={base_url}, model={model}, key={_mask_key(api_key)}')

    try:
        if provider == 'claude':
            headers = {
                'x-api-key': api_key,
                'anthropic-version': '2023-06-01',
                'Content-Type': 'application/json',
            }
            payload = {'model': model, 'max_tokens': 10, 'messages': [{'role': 'user', 'content': 'Hi'}]}
            url = f'{base_url}/messages'
        else:
            headers = {'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'}
            payload = {'model': model, 'messages': [{'role': 'user', 'content': 'Hi'}], 'max_tokens': 10}
            url = f'{base_url}/chat/completions'

        t0 = time.time()
        resp = http_req.post(url, headers=headers, json=payload, timeout=30)
        latency = round(time.time() - t0, 2)

        if resp.status_code == 200:
            # 🐛 修复：尝试解析响应，确认模型可用
            try:
                body = resp.json()
                choices = body.get('choices', [])
                if choices:
                    content = choices[0].get('message', {}).get('content', '')
                    preview = content[:50] if content else '(空响应)'
                else:
                    preview = '(无choices)'
            except Exception:
                preview = ''

            return jsonify({
                'success': True,
                'message': f'连接成功！延迟: {latency}s，模型: {model}',
                'latency': latency,
                'model': model,
                'response_preview': preview,
            })
        elif resp.status_code == 401:
            return jsonify({'success': False, 'message': '❌ API 密钥无效或已过期，请检查密钥是否正确'})
        elif resp.status_code == 429:
            return jsonify({'success': False, 'message': '⚠️ API 调用频率超限，请稍后重试'})
        elif resp.status_code == 404:
            return jsonify({'success': False, 'message': f'❌ 模型 {model} 不存在或接口地址错误，请检查模型名和URL'})
        elif resp.status_code == 400:
            # 尝试解析错误信息
            try:
                err_body = resp.json()
                err_msg = err_body.get('error', {}).get('message', resp.text[:200])
            except Exception:
                err_msg = resp.text[:200]
            return jsonify({'success': False, 'message': f'❌ 请求参数错误: {err_msg}'})
        else:
            return jsonify({'success': False, 'message': f'❌ HTTP {resp.status_code}: {resp.text[:200]}'})

    except http_req.exceptions.Timeout:
        return jsonify({'success': False, 'message': '⏱️ 连接超时（30s），请检查网络或接口地址'})
    except http_req.exceptions.ConnectionError:
        return jsonify({'success': False, 'message': f'❌ 无法连接到 {base_url}，请检查网络和接口地址'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'❌ 测试失败: {e}'})


@app.route('/api/config/models/<provider_id>')
def config_models(provider_id: str):
    """代理：从供应商 API 拉取可用模型列表"""
    import requests as http_req
    info = WEB_PROVIDER_REGISTRY.get(provider_id)
    if not info:
        return jsonify({'error': '未知供应商'}), 404
    if not info.get('supports_model_fetch'):
        return jsonify({'error': f'{info["name"]} 不支持在线获取模型列表'}), 400

    api_key = request.args.get('api_key', '').strip()
    base_url = request.args.get('base_url', info['default_base_url']).strip().rstrip('/')

    if not api_key:
        return jsonify({'error': 'API 密钥不能为空'}), 400

    try:
        headers = {'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'}
        url = f'{base_url}{info["models_endpoint"]}'
        resp = http_req.get(url, headers=headers, timeout=15)

        if resp.status_code != 200:
            return jsonify({'success': False, 'message': f'HTTP {resp.status_code}', 'models': info['models']})

        body = resp.json()
        # 解析标准 OpenAI 格式
        if isinstance(body, dict) and 'data' in body:
            models = [m.get('id', m) if isinstance(m, dict) else str(m) for m in body['data']]
        elif isinstance(body, list):
            models = [m.get('id', m) if isinstance(m, dict) else str(m) for m in body]
        else:
            models = info['models']

        return jsonify({'success': True, 'models': models, 'message': f'成功获取 {len(models)} 个模型'})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e), 'models': info['models']})


@app.route('/api/providers')
def providers_list():
    """返回供应商注册表（序列化字段）"""
    return jsonify({'providers': WEB_PROVIDER_REGISTRY})


@app.route('/api/status')
def api_status():
    try:
        from config.ai_manager import AIConfigManager
        mgr = AIConfigManager()
        configured = mgr.is_configured()
        active = mgr.get_active_provider()
        name = WEB_PROVIDER_REGISTRY.get(active, {}).get('name', active)
        
        # 检测 Kali 环境
        is_kali = False
        kali_version = ''
        try:
            if os.path.exists('/etc/os-release'):
                with open('/etc/os-release', 'r') as f:
                    release = f.read()
                if 'kali' in release.lower():
                    is_kali = True
                    for line in release.splitlines():
                        if line.startswith('PRETTY_NAME='):
                            kali_version = line.split('=', 1)[1].strip('"')
                            break
        except Exception:
            pass
        
        # 获取局域网 IP
        local_ip = '127.0.0.1'
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            local_ip = s.getsockname()[0]
            s.close()
        except Exception:
            pass
        
        return jsonify({
            'ai_configured': configured,
            'active_provider': active,
            'provider_name': name,
            'is_kali': is_kali,
            'kali_version': kali_version,
            'local_ip': local_ip,
            'access_token': _ACCESS_TOKEN if request.remote_addr in ('127.0.0.1', '::1', 'localhost') else '',
        })
    except Exception:
        return jsonify({
            'ai_configured': False,
            'active_provider': '',
            'provider_name': '',
            'is_kali': False,
            'local_ip': '127.0.0.1',
        })


@app.route('/api/tools')
def api_tools():
    """获取所有工具的可用状态"""
    try:
        from agents.tool_manager import get_tool_manager
        tm = get_tool_manager()
        all_tools = tm.get_all_tools()
        result = {}
        for name, info in all_tools.items():
            result[name] = {
                'available': info.get('available', False),
                'source': info.get('source', ''),
                'category': info.get('category', ''),
                'install_hint': tm.get_install_hint(name),
            }
        return jsonify({
            'tools': result,
            'report': tm.get_status_report(),
            'best_tools': {
                cat: tm.get_best_tool(cat) or ''
                for cat in ['port_scan', 'vuln_scan', 'fingerprint', 'dir_scan',
                            'subdomain', 'sqli_scan', 'xss_scan', 'ssl_scan']
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/tools/install', methods=['POST'])
def api_tools_install():
    if not _check_auth():
        return jsonify({'error': '未授权访问'}), 401
    """一键安装缺失工具（纯系统安装：apt + pip + go install + github）"""
    import subprocess
    import shutil
    mode = request.args.get('mode', 'all')  # all / apt / pip / go / github
    try:
        # 确保 ~/.local/bin 在 PATH 中
        local_bin = os.path.expanduser('~/.local/bin')
        if local_bin not in os.environ.get('PATH', ''):
            os.environ['PATH'] = local_bin + ':' + os.environ.get('PATH', '')
        log_lines = []
        
        # APT 工具安装
        if mode in ('all', 'apt'):
            apt_tools = [
                ('nmap', 'nmap'), ('masscan', 'masscan'), ('nuclei', 'nuclei'),
                ('whatweb', 'whatweb'), ('nikto', 'nikto'), ('dirsearch', 'dirsearch'),
                ('gobuster', 'gobuster'), ('feroxbuster', 'feroxbuster'),
                ('amass', 'amass'), ('subfinder', 'subfinder'), ('sqlmap', 'sqlmap'),
                ('dalfox', 'dalfox'), ('testssl', 'testssl.sh'),
                ('dnsrecon', 'dnsrecon'), ('dnsutils', 'dnsutils'),
                ('dirb', 'dirb'), ('ffuf', 'ffuf'), ('wpscan', 'wpscan'),
                ('seclists', 'seclists'),
                # 暴力破解
                ('hydra', 'hydra'), ('medusa', 'medusa'), ('ncrack', 'ncrack'),
                ('john', 'john'), ('hashcat', 'hashcat'), ('crowbar', 'crowbar'),
                ('patator', 'patator'),
                # 后渗透 — bloodhound 在部分Kali版本中无apt包，会自动走备选安装
                ('crackmapexec', 'crackmapexec'), 
                ('bloodhound', 'bloodhound-ce'),
                ('socat', 'socat'), ('responder', 'responder'),
                ('enum4linux', 'enum4linux'), ('smbclient', 'samba'),
                ('proxychains4', 'proxychains4'), ('msfvenom', 'metasploit-framework'),
                # 网络
                ('arp-scan', 'arp-scan'), ('whois', 'whois'),
                ('netcat', 'netcat'), ('nbtscan', 'nbtscan'),
            ]
            installed = []
            failed = []
            for tool_name, apt_pkg in apt_tools:
                if shutil.which(tool_name):
                    installed.append(tool_name)
                    continue
                try:
                    result = subprocess.run(
                        ['sudo', 'apt-get', 'install', '-y', '-qq', apt_pkg],
                        capture_output=True, timeout=120, text=True,
                        stdin=subprocess.DEVNULL
                    )
                    if result.returncode == 0:
                        installed.append(tool_name)
                        log_lines.append(f'✅ {tool_name} (apt) 安装成功')
                    else:
                        failed.append(tool_name)
                        log_lines.append(f'❌ {tool_name} (apt) 安装失败: {result.stderr[:100]}')
                except Exception as e:
                    failed.append(tool_name)
                    log_lines.append(f'❌ {tool_name} (apt) 安装异常: {e}')
            
            log_lines.insert(0, f'APT 安装: {len(installed)} 成功, {len(failed)} 失败')

            # APT 安装失败的工具 — 尝试备选安装方式
            apt_fallbacks = {
                'bloodhound': {
                    'method': 'pip',
                    'pip_name': 'bloodhound-ce',
                    'note': 'BloodHound CE Python 收集器 (pip)',
                    'check_cmd': [sys.executable, '-c', 'import bloodhound; print("ok")'],
                },
            }
            for tool_name in failed:
                if tool_name in apt_fallbacks:
                    fb = apt_fallbacks[tool_name]
                    try:
                        if fb['method'] == 'pip':
                    r = subprocess.run(
                        [sys.executable, '-m', 'pip', 'install', 'sslyze', '--break-system-packages'],
                        capture_output=True, timeout=120, text=True,
                        stdin=subprocess.DEVNULL
                    )
                            if r.returncode == 0:
                                log_lines.append(f'✅ {tool_name} (pip备选) 安装成功: {fb["note"]}')
                            else:
                                log_lines.append(f'❌ {tool_name} (pip备选) 安装失败: {r.stderr[:100]}')
                        elif fb['method'] == 'github':
                            install_dir = os.path.expanduser(f'~/neuralstrike-tools/{tool_name}')
                            if not os.path.exists(install_dir):
                                r = subprocess.run(
                                    ['git', 'clone', '--depth', '1', fb['repo'], install_dir],
                                    capture_output=True, timeout=120, text=True,
                                    stdin=subprocess.DEVNULL
                                )
                                if r.returncode != 0:
                                    log_lines.append(f'❌ {tool_name} (github备选) clone失败')
                                    continue
                            entry_path = os.path.join(install_dir, fb['entry'])
                            # 如果entry不存在，搜索
                            if not os.path.exists(entry_path):
                                for root, dirs, files in os.walk(install_dir):
                                    for f in files:
                                        if f.lower() in ('sqlmap.py',):
                                            entry_path = os.path.join(root, f)
                                            break
                            if os.path.exists(entry_path):
                                local_bin = os.path.expanduser('~/.local/bin')
                                os.makedirs(local_bin, exist_ok=True)
                                # 创建wrapper脚本
                                for name in [tool_name, tool_name.capitalize(), tool_name.title()]:
                                    wrapper = os.path.join(local_bin, name)
                                    with open(wrapper, 'w') as wf:
                                        wf.write(f'#!/bin/bash\nexec {sys.executable} "{entry_path}" "$@"\n')
                                    os.chmod(wrapper, 0o755)
                                log_lines.append(f'✅ {tool_name} (github备选) 安装成功: {fb["note"]}')
                            else:
                                log_lines.append(f'❌ {tool_name} (github备选) 入口文件未找到')
                    except Exception as e:
                        log_lines.append(f'❌ {tool_name} (备选安装) 失败: {e}')

            # APT 安装后：为命令名与包名不一致的工具创建符号链接
            apt_aliases = {
                'crackmapexec': ['nxc', 'cme', 'netexec'],  # 新版改名
                'testssl': ['testssl.sh'],       # apt包testssl.sh，命令名testssl.sh
                'bloodhound': ['bloodhound-ce', 'bloodhound-python'],
            }
            local_bin = os.path.expanduser('~/.local/bin')
            os.makedirs(local_bin, exist_ok=True)
            for tool_name, aliases in apt_aliases.items():
                for alias in aliases:
                    alias_path = shutil.which(alias)
                    if alias_path and not shutil.which(tool_name):
                        link = os.path.join(local_bin, tool_name)
                        try:
                            if os.path.exists(link) or os.path.islink(link):
                                os.remove(link)
                            os.symlink(alias_path, link)
                            log_lines.append(f'  🔗 {alias} → {tool_name} 符号链接已创建')
                        except Exception as e:
                            log_lines.append(f'  ⚠️ {alias} → {tool_name} 符号链接失败: {e}')

        # pip 工具安装
        if mode in ('all', 'pip'):
            pip_tools = [
                ('sslyze', 'sslyze'),
                ('pymysql', 'pymysql'),
                ('psycopg2-binary', 'psycopg2-binary'),
                ('pymssql', 'pymssql'),
                ('python-nmap', 'python-nmap'),
                ('beautifulsoup4', 'beautifulsoup4'),
                ('paramiko', 'paramiko'),
                ('impacket', 'impacket'),
                ('crackmapexec', 'crackmapexec'),
                ('scapy', 'scapy'),
            ]
            for pip_name, pip_import in pip_tools:
                # 先检查是否已安装
                check_name = pip_name
                if pip_name == 'beautifulsoup4':
                    check_name = 'bs4'
                elif pip_name == 'psycopg2-binary':
                    check_name = 'psycopg2'
                elif pip_name == 'python-nmap':
                    check_name = 'nmap'
                else:
                    check_name = pip_name
                try:
                    r = subprocess.run(
                        [sys.executable, '-c', f'import {check_name}'],
                        capture_output=True, timeout=5, text=True,
                        stdin=subprocess.DEVNULL
                    )
                    if r.returncode == 0:
                        log_lines.append(f'✅ {pip_name} (pip) 已安装')
                        continue
                except Exception:
                    pass
                # 未安装，执行安装
                try:
                    result = subprocess.run(
                        [sys.executable, '-m', 'pip', 'install', pip_name, '--break-system-packages', '-q'],
                        capture_output=True, timeout=120, text=True,
                        stdin=subprocess.DEVNULL
                    )
                    if result.returncode == 0:
                        log_lines.append(f'✅ {pip_name} (pip) 安装成功')
                    else:
                        log_lines.append(f'❌ {pip_name} (pip) 安装失败: {result.stderr[:100]}')
                except Exception as e:
                    log_lines.append(f'❌ {pip_name} (pip) 安装异常: {e}')

        # Go 工具编译安装
        if mode in ('all', 'go'):
            if shutil.which('go'):
                go_tools = {
                    'dalfox': 'github.com/hahwul/dalfox/v2@latest',
                    'subfinder': 'github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest',
                    'nuclei': 'github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest',
                    'gobuster': 'github.com/OJ/gobuster/v3@latest',
                    'ffuf': 'github.com/ffuf/ffuf/v2@latest',
                    'chisel': 'github.com/jpillora/chisel@latest',
                }
                gopath = os.environ.get('GOPATH', os.path.expanduser('~/go'))
                # 配置国内 Go 代理镜像（解决 proxy.golang.org 被墙问题）
                go_env = {
                    **os.environ,
                    'GOPATH': gopath,
                    'GOPROXY': 'https://goproxy.cn,https://goproxy.io,direct',
                    'GONOSUMCHECK': '*',
                    'GO111MODULE': 'on',
                    'PATH': os.environ.get('PATH', '') + f':{gopath}/bin:/usr/local/go/bin',
                }
                for tool, pkg in go_tools.items():
                    if shutil.which(tool):
                        continue
                    try:
                        result = subprocess.run(
                            ['go', 'install', pkg],
                            capture_output=True, timeout=300, text=True,
                            env=go_env,
                            stdin=subprocess.DEVNULL
                        )
                        if result.returncode == 0:
                            bin_path = os.path.join(gopath, 'bin', tool)
                            # 优先链接到 ~/.local/bin（无需 sudo），其次 /usr/local/bin
                            link = os.path.expanduser(f'~/.local/bin/{tool}')
                            os.makedirs(os.path.dirname(link), exist_ok=True)
                            if os.path.exists(bin_path):
                                if os.path.exists(link) or os.path.islink(link):
                                    os.remove(link)
                                os.symlink(bin_path, link)
                            subprocess.run(['sudo', 'ln', '-sf', bin_path, f'/usr/local/bin/{tool}'],
                                           timeout=5, capture_output=True,
                                           stdin=subprocess.DEVNULL)
                            log_lines.append(f'✅ {tool} (go) 编译安装成功')
                        else:
                            log_lines.append(f'❌ {tool} (go) 编译失败: {result.stderr[:200]}')
                    except Exception as e:
                        log_lines.append(f'❌ {tool} (go) 编译异常: {e}')
            else:
                log_lines.append('⚠️ Go 编译器未安装，跳过 Go 工具编译 (sudo apt install golang)')

        # 权限设置
        if mode in ('all', 'apt'):
            for tool in ['nmap', 'masscan']:
                tp = shutil.which(tool)
                if tp:
                    subprocess.run(['sudo', 'setcap', 'cap_net_raw+ep', tp],
                                   capture_output=True, timeout=5,
                                   stdin=subprocess.DEVNULL)

        # Nuclei 模板更新
        if mode in ('all', 'apt'):
            if shutil.which('nuclei'):
                subprocess.run(['nuclei', '-update-templates'],
                               capture_output=True, timeout=120,
                               stdin=subprocess.DEVNULL)

        # GitHub 源码安装（补充 apt/go 未装的工具）
        if mode in ('all', 'github'):
            GITHUB_TOOLS = {
                'sqlmap':    {'repo': 'https://github.com/sqlmapproject/sqlmap.git',       'type': 'python', 'entry': 'sqlmap.py'},
                'dalfox':    {'repo': 'https://github.com/hahwul/dalfox.git',              'type': 'go'},
                'subfinder': {'repo': 'https://github.com/projectdiscovery/subfinder.git', 'type': 'go'},
                'gobuster':  {'repo': 'https://github.com/OJ/gobuster.git',                'type': 'go'},
                'ffuf':      {'repo': 'https://github.com/ffuf/ffuf.git',                  'type': 'go'},
                'nuclei':    {'repo': 'https://github.com/projectdiscovery/nuclei.git',     'type': 'go'},
                'chisel':    {'repo': 'https://github.com/jpillora/chisel.git',             'type': 'go'},
                'feroxbuster': {'repo': 'https://github.com/epi052/feroxbuster.git',       'type': 'rust'},
                'testssl.sh': {'repo': 'https://github.com/drwetter/testssl.sh.git',       'type': 'bash', 'entry': 'testssl.sh'},
                'bloodhound': {'repo': 'https://github.com/BloodHoundAD/BloodHound.git',   'type': 'go'},
            }
            install_dir = os.path.join(os.path.expanduser('~'), 'neuralstrike-tools')
            os.makedirs(install_dir, exist_ok=True)

            # 确保 git 可用
            if not shutil.which('git'):
                log_lines.append('❌ git 未安装，无法从 GitHub 克隆 (sudo apt install git)')
            else:
                for tool, info in GITHUB_TOOLS.items():
                    # 检查原始名或别名是否已在PATH中
                    already_installed = False
                    extra_names = {
                        'bloodhound': [],
                        'testssl.sh': ['testssl'],
                        'bloodhound': ['bloodhound-ce', 'bloodhound-python'],
                    }
                    check_names = [tool, tool.lower(), tool.replace('.sh', ''), tool.replace('.py', '')]
                    check_names.extend(extra_names.get(tool, []))
                    for check_name in set(check_names):
                        if shutil.which(check_name):
                            already_installed = True
                            break
                    if already_installed:
                        continue
                    tool_dir = os.path.join(install_dir, tool)
                    try:
                        # 如果目录不存在则 clone
                        if not os.path.isdir(tool_dir):
                            log_lines.append(f'⏳ {tool}: 从 GitHub 克隆 {info["repo"]}...')
                            r = subprocess.run(
                                ['git', 'clone', '--depth', '1', info['repo'], tool_dir],
                                capture_output=True, timeout=120, text=True,
                                stdin=subprocess.DEVNULL
                            )
                            if r.returncode != 0:
                                log_lines.append(f'❌ {tool}: 克隆失败 - {r.stderr[:100]}')
                                continue

                        if info['type'] == 'python':
                            # Python 工具：创建 wrapper 脚本
                            entry = os.path.join(tool_dir, info.get('entry', 'main.py'))
                            # 如果entry不存在，尝试搜索
                            if not os.path.exists(entry):
                                # 优先尝试 entry_fallbacks
                                fallbacks = info.get('entry_fallbacks', ['main.py'])
                                search_names = [info.get('entry', 'main.py')] + fallbacks
                                found = False
                                for root, dirs, files in os.walk(tool_dir):
                                    for fname in files:
                                        if fname in search_names or fname.lower() in [n.lower() for n in search_names]:
                                            entry = os.path.join(root, fname)
                                            found = True
                                            break
                                    if found:
                                        break
                                if not found:
                                    # 最后尝试：搜索任何 .py 文件包含关键函数
                                    for root, dirs, files in os.walk(tool_dir):
                                        for fname in files:
                                            if fname.endswith('.py') and tool.lower().replace('-', '') in fname.lower().replace('_', '').replace('-', ''):
                                                entry = os.path.join(root, fname)
                                                found = True
                                                break
                                        if found:
                                            break
                            if os.path.exists(entry):
                                script = f'#!/bin/bash\nexec {sys.executable} {entry} "$@"\n'
                                wrapper = os.path.join(install_dir, 'bin', tool)
                                os.makedirs(os.path.dirname(wrapper), exist_ok=True)
                                with open(wrapper, 'w') as f:
                                    f.write(script)
                                os.chmod(wrapper, 0o755)
                                # 符号链接到用户可写目录
                                link = os.path.expanduser(f'~/.local/bin/{tool}')
                                os.makedirs(os.path.dirname(link), exist_ok=True)
                                if os.path.exists(link):
                                    os.remove(link)
                                os.symlink(wrapper, link)
                                # 同时创建小写符号链接
                                if tool != tool.lower():
                                    lower_link = os.path.expanduser(f'~/.local/bin/{tool.lower()}')
                                    if os.path.exists(lower_link) or os.path.islink(lower_link):
                                        os.remove(lower_link)
                                    os.symlink(wrapper, lower_link)
                                log_lines.append(f'✅ {tool} (github/python) 安装成功 → {link}')
                            else:
                                log_lines.append(f'❌ {tool}: 入口文件 {entry} 不存在')

                        elif info['type'] == 'go':
                            if shutil.which('go'):
                                gopath = os.environ.get('GOPATH', os.path.expanduser('~/go'))
                                # 配置国内 Go 代理镜像（解决 proxy.golang.org 被墙问题）
                                go_env = {
                                    **os.environ,
                                    'GOPATH': gopath,
                                    'GOPROXY': 'https://goproxy.cn,https://goproxy.io,direct',
                                    'GONOSUMCHECK': '*',
                                    'GO111MODULE': 'on',
                                    'PATH': os.environ.get('PATH', '') + f':{gopath}/bin:/usr/local/go/bin',
                                }
                                pkg_map = {
                                    'dalfox': 'github.com/hahwul/dalfox/v2@latest',
                                    'subfinder': 'github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest',
                                    'gobuster': 'github.com/OJ/gobuster/v3@latest',
                                    'ffuf': 'github.com/ffuf/ffuf/v2@latest',
                                    'nuclei': 'github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest',
                                    'chisel': 'github.com/jpillora/chisel@latest',
                                }
                                pkg = pkg_map.get(tool)
                                if pkg:
                                    r = subprocess.run(
                                        ['go', 'install', pkg],
                                        capture_output=True, timeout=300, text=True,
                                        env=go_env,
                                        stdin=subprocess.DEVNULL
                                    )
                                    if r.returncode == 0:
                                        bin_path = os.path.join(gopath, 'bin', tool)
                                        link = os.path.expanduser(f'~/.local/bin/{tool}')
                                        os.makedirs(os.path.dirname(link), exist_ok=True)
                                        if os.path.exists(bin_path):
                                            if os.path.exists(link):
                                                os.remove(link)
                                            os.symlink(bin_path, link)
                                        log_lines.append(f'✅ {tool} (github/go) 编译安装成功 → {link}')
                                    else:
                                        log_lines.append(f'❌ {tool} (github/go) 编译失败: {r.stderr[:100]}')
                                else:
                                    log_lines.append(f'⚠️ {tool}: 无Go包路径')
                            else:
                                log_lines.append(f'⚠️ {tool}: 需要Go编译器 (sudo apt install golang)')

                        elif info['type'] == 'rust':
                            if shutil.which('cargo'):
                                r = subprocess.run(
                                    ['cargo', 'build', '--release'],
                                    cwd=tool_dir, capture_output=True, timeout=600, text=True,
                                    stdin=subprocess.DEVNULL
                                )
                                if r.returncode == 0:
                                    bin_src = os.path.join(tool_dir, 'target', 'release', tool)
                                    link = os.path.expanduser(f'~/.local/bin/{tool}')
                                    os.makedirs(os.path.dirname(link), exist_ok=True)
                                    if os.path.exists(bin_src):
                                        if os.path.exists(link):
                                            os.remove(link)
                                        os.symlink(bin_src, link)
                                    log_lines.append(f'✅ {tool} (github/rust) 编译安装成功 → {link}')
                                else:
                                    log_lines.append(f'❌ {tool} (github/rust) 编译失败: {r.stderr[:100]}')
                            else:
                                log_lines.append(f'⚠️ {tool}: 需要Rust编译器 (sudo apt install rustc cargo)')

                        elif info['type'] == 'bash':
                            entry = os.path.join(tool_dir, info.get('entry', tool))
                            if os.path.exists(entry):
                                os.chmod(entry, 0o755)
                                link = os.path.expanduser(f'~/.local/bin/{tool}')
                                os.makedirs(os.path.dirname(link), exist_ok=True)
                                if os.path.exists(link):
                                    os.remove(link)
                                os.symlink(entry, link)
                                log_lines.append(f'✅ {tool} (github/bash) 安装成功 → {link}')
                            else:
                                log_lines.append(f'❌ {tool}: 入口文件 {entry} 不存在')

                    except subprocess.TimeoutExpired:
                        log_lines.append(f'❌ {tool}: 安装超时')
                    except Exception as e:
                        log_lines.append(f'❌ {tool}: 安装异常 - {e}')

        # 刷新工具缓存
        try:
            from agents.tool_manager import get_tool_manager
            get_tool_manager().refresh()
        except Exception:
            pass

        msg = f'安装完成，共 {len(log_lines)} 条记录'
        if not log_lines:
            msg = '所有工具均已安装，无需额外操作'

        return jsonify({
            'success': True,
            'message': msg,
            'log': '\n'.join(log_lines) if log_lines else '无需安装',
        })
    except Exception as e:
        logger.exception('Tools install error')
        return jsonify({'success': False, 'message': f'安装失败: {str(e)}', 'log': ''})


# ============================================================================
# 路由：报告生成与下载
# ============================================================================

@app.route('/api/report/generate', methods=['POST'])
def report_generate():
    """生成报告（简报/详报）"""
    data = request.get_json(force=True) or {}
    scan_id = data.get('scan_id', '')
    detail_level = data.get('detail_level', 'detailed')  # summary / detailed / full

    scan = SCANS.get(scan_id)
    if not scan:
        return jsonify({'error': '无报告 — 尚未进行扫描'}), 200
    if scan['status'] not in ('finished',):
        if scan['status'] == 'running':
            return jsonify({'error': '扫描尚未完成，请等待扫描结束后再生成报告'}), 200
        elif scan['status'] == 'stopped':
            return jsonify({'error': '扫描已被停止，报告可能不完整'}), 200
        else:
            return jsonify({'error': f'扫描状态异常: {scan["status"]}，无法生成报告'}), 200

    # ── 直接从扫描结果构建上下文，不再重建整个 Orchestrator ──
    def _deep_extract_context(result_data):
        """从扫描结果深度提取上下文信息（模拟SharedMemory的数据结构）
        
        扫描结果可能是两种结构:
        1. list: [agent_output1, agent_output2, ...]  — 来自 workflow_orchestrator
        2. dict: {'results': [agent_output1, ...]}     — 旧格式兼容
        
        每个 agent_output 结构:
        {
            'agent_name': 'info_gathering',
            'display_name': '信息收集',
            'results': [                      ← _execute_plan 返回的列表
                {'action': 'port_scan', 'result': {'success': True, 'ports': [...]}},
                {'action': 'fingerprint', 'result': {'success': True, 'technologies': [...]}},
            ],
            'evaluation': {...},
            'next_actions': {...},
            'context_updates': {...}         ← _extract_context 提取的上下文
        }
        """
        context = {
            'vulnerabilities': [],
            'findings': [],
            'services': {},
            'technologies': [],
            'execution_history': [],
        }
        if not result_data:
            return context

        # 兼容 list 和 dict 两种输入格式
        if isinstance(result_data, list):
            items = result_data
        elif isinstance(result_data, dict):
            # 旧格式：{'results': [...]}
            items = result_data.get('results', [result_data])
        else:
            return context

        for item in items:
            if not isinstance(item, dict):
                continue

            agent_name = item.get('agent_name', item.get('agent', ''))
            display_name = item.get('display_name', agent_name)

            # ── 提取 context_updates（_extract_context 的输出直接有用） ──
            ctx_updates = item.get('context_updates', {})
            if isinstance(ctx_updates, dict):
                for v in ctx_updates.get('vulnerabilities', []):
                    if isinstance(v, dict):
                        context['vulnerabilities'].append(v)
                for f in ctx_updates.get('findings', []):
                    if isinstance(f, dict):
                        context['findings'].append(f)
                for t in ctx_updates.get('technologies', []):
                    if isinstance(t, dict):
                        context['technologies'].append(t)
                    elif isinstance(t, str):
                        context['technologies'].append({'name': t})
                if ctx_updates.get('services'):
                    context['services'].update(ctx_updates['services'])

            # ── 遍历 agent 的每步执行结果 ──
            for step in item.get('results', []):
                if not isinstance(step, dict):
                    continue
                sr = step.get('result', step)
                if not isinstance(sr, dict):
                    continue

                # 记录到执行历史
                context['execution_history'].append({
                    'agent': agent_name,
                    'display_name': display_name,
                    'action': step.get('action', ''),
                    'result': sr,
                })

                # 提取端口→服务
                for p in sr.get('ports', []):
                    if isinstance(p, dict) and p.get('state') == 'open':
                        port_id = str(p.get('port', p.get('id', '')))
                        context['services'][port_id] = {
                            'service': p.get('name', p.get('service', '')),
                            'state': 'open',
                        }

                # 提取漏洞
                for v in sr.get('vulnerabilities', []):
                    if isinstance(v, dict):
                        context['vulnerabilities'].append(v)

                # 提取CVE
                for cve in sr.get('cves', []):
                    if isinstance(cve, dict):
                        context['vulnerabilities'].append({
                            'type': 'cve', 'name': cve.get('id', cve.get('cve_id', 'CVE')),
                            'severity': cve.get('severity', 'medium'),
                            'description': cve.get('description', ''),
                        })

                # 提取SQL注入
                for sqli in sr.get('sqli_found', sr.get('sqli_results', [])):
                    if isinstance(sqli, dict):
                        context['vulnerabilities'].append({
                            'type': 'sql_injection', 'name': f"SQL注入 - {sqli.get('param', sqli.get('url', ''))}",
                            'severity': 'critical', 'url': sqli.get('url', ''),
                            'description': sqli.get('evidence', sqli.get('payload', '')),
                            'payload': sqli.get('payload', ''),
                        })

                # 提取XSS
                for xss in sr.get('xss_found', sr.get('xss_results', [])):
                    if isinstance(xss, dict):
                        context['vulnerabilities'].append({
                            'type': 'xss', 'name': f"XSS - {xss.get('param', xss.get('url', ''))}",
                            'severity': 'high', 'url': xss.get('url', ''),
                            'description': xss.get('evidence', xss.get('payload', '')),
                            'payload': xss.get('payload', ''),
                        })

                # 提取路径遍历
                for pt in sr.get('path_traversal_found', []):
                    if isinstance(pt, dict):
                        context['vulnerabilities'].append({
                            'type': 'path_traversal', 'name': f"路径遍历 - {pt.get('param', '')}",
                            'severity': 'high', 'url': pt.get('url', ''),
                        })

                # 提取命令注入
                for ci in sr.get('command_injection_found', []):
                    if isinstance(ci, dict):
                        context['vulnerabilities'].append({
                            'type': 'command_injection', 'name': f"命令注入 - {ci.get('param', '')}",
                            'severity': 'critical', 'url': ci.get('url', ''),
                        })

                # 提取敏感路径 → 同时加入 findings 和 vulnerabilities
                for sp in sr.get('sensitive_paths', sr.get('found_paths', [])):
                    if isinstance(sp, dict):
                        path = sp.get('path', sp.get('url', ''))
                        url = sp.get('url', '')
                        context['findings'].append({
                            'type': 'sensitive_file',
                            'path': path,
                            'url': url,
                        })
                        context['vulnerabilities'].append({
                            'type': 'sensitive_file',
                            'name': f"敏感文件 - {path}",
                            'severity': sp.get('severity', 'medium'),
                            'url': url,
                            'path': path,
                        })

                # 提取子域名
                for sub in sr.get('subdomains', []):
                    context['findings'].append({'type': 'subdomain', 'name': sub if isinstance(sub, str) else str(sub)})

                # 提取技术栈
                for tech in sr.get('technologies', sr.get('tech_stack', [])):
                    if isinstance(tech, dict):
                        context['technologies'].append(tech)
                    elif isinstance(tech, str):
                        context['technologies'].append({'name': tech})

                # 提取认证问题
                for auth in sr.get('auth_issues', sr.get('weak_auth', [])):
                    if isinstance(auth, dict):
                        context['vulnerabilities'].append({
                            'type': 'weak_auth', 'name': f"弱认证 - {auth.get('type', auth.get('url', ''))}",
                            'severity': 'high', 'url': auth.get('url', ''),
                        })

                # 提取SSL问题
                for ssl in sr.get('ssl_issues', []):
                    if isinstance(ssl, dict):
                        context['vulnerabilities'].append({
                            'type': 'ssl_issue', 'name': f"SSL问题 - {ssl.get('issue', ssl.get('type', ''))}",
                            'severity': ssl.get('severity', 'medium'),
                        })

                # 提取文件上传
                for up in sr.get('upload_vulns', []):
                    if isinstance(up, dict):
                        context['vulnerabilities'].append({
                            'type': 'file_upload', 'name': f"文件上传 - {up.get('param', '')}",
                            'severity': 'critical', 'url': up.get('url', ''),
                        })

                # 提取后渗透结果
                for cred in sr.get('credentials', sr.get('found_credentials', [])):
                    if isinstance(cred, dict):
                        context['findings'].append({
                            'type': 'credential',
                            'username': cred.get('username', ''),
                            'source': cred.get('source', ''),
                        })
                for fpath in sr.get('sensitive_files', sr.get('found_files', [])):
                    if isinstance(fpath, dict):
                        context['findings'].append({
                            'type': 'sensitive_file',
                            'path': fpath.get('path', fpath.get('name', '')),
                        })
                for priv in sr.get('privilege_escalation', []):
                    if isinstance(priv, dict):
                        context['vulnerabilities'].append({
                            'type': 'privilege_escalation',
                            'name': f"提权路径 - {priv.get('method', priv.get('type', ''))}",
                            'severity': 'critical',
                            'description': priv.get('description', ''),
                        })

        return context

    def _report_worker():
        """后台生成报告"""
        try:
            # 构建上下文
            result_data = scan.get('result', {})
            logger.info(f"[报告] 扫描结果类型: {type(result_data).__name__}, 数据量: {len(result_data) if result_data else 0}")
            context = _deep_extract_context(result_data)
            logger.info(f"[报告] 深度提取完成: 漏洞={len(context.get('vulnerabilities', []))}, "
                       f"发现={len(context.get('findings', []))}, "
                       f"服务={len(context.get('services', {}))}, "
                       f"技术={len(context.get('technologies', []))}")

            # 如果扫描过程中保存了SharedMemory上下文，合并
            saved_context = scan.get('shared_memory_context', {})
            if isinstance(saved_context, dict) and saved_context:
                logger.info(f"[报告] 合并SharedMemory: 漏洞={len(saved_context.get('vulnerabilities', []))}, "
                           f"发现={len(saved_context.get('findings', []))}")
                for k in ('vulnerabilities', 'findings', 'technologies'):
                    if saved_context.get(k):
                        context[k] = saved_context[k] + context.get(k, [])
                if saved_context.get('services'):
                    context['services'].update(saved_context['services'])

            logger.info(f"[报告] 最终上下文: 漏洞={len(context.get('vulnerabilities', []))}, "
                       f"发现={len(context.get('findings', []))}, "
                       f"服务={len(context.get('services', {}))}")

            # 创建独立的报告Agent
            ai_config = None
            try:
                from config.ai_manager import AIConfigManager
                mgr = AIConfigManager()
                if mgr.is_configured():
                    ai_config = mgr.get_ai_config()
            except Exception:
                pass

            from agents.report_agent import SmartReportAgent
            report_agent = SmartReportAgent('report', ai_config or {}, 'pentest_results')
            report_agent.context = context

            # 设置AI会话（如果可用）
            if ai_config and not report_agent.ai_session:
                try:
                    from agents.ai_client import AIAgentFactory, AISession
                    client = AIAgentFactory.create_client(
                        ai_config.get('provider', 'openai'),
                        ai_config.get('config', {})
                    )
                    report_agent.ai_session = AISession(client, report_agent.get_system_prompt())
                except Exception as e2:
                    logger.warning(f'报告Agent AI会话创建失败: {e2}')

            # 生成报告 — 使用单一 event loop
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                if detail_level == 'summary':
                    report_result = loop.run_until_complete(
                        report_agent._do_generate_summary(scan['target'], {}))
                elif detail_level == 'detailed':
                    report_result = loop.run_until_complete(
                        report_agent._do_generate_detailed(scan['target'], {}))
                else:
                    report_result = loop.run_until_complete(
                        report_agent._do_generate_report(scan['target'], {}))
            finally:
                loop.close()

            # 安全检查结果
            if not isinstance(report_result, dict):
                report_result = {'success': True, 'type': detail_level, 'raw': str(report_result)[:1000]}

            scan['report'] = report_result

        except Exception as e:
            logger.exception('Report generation error')
            scan['report_error'] = str(e)

    t = threading.Thread(target=_report_worker, daemon=True)
    t.start()
    t.join(timeout=120)  # 最多等120秒

    report = scan.get('report')
    if not report:
        return jsonify({'error': scan.get('report_error', '报告生成超时')}), 500

    return jsonify({'success': True, 'report': report})


REPORT_BASE_DIR = os.path.abspath('pentest_results')
os.makedirs(REPORT_BASE_DIR, exist_ok=True)


@app.route('/api/report/download/<path:filepath>')
def report_download(filepath):
    """下载报告文件 — 防止路径穿越，兼容绝对路径和相对路径"""
    # 1. 先尝试：相对路径（相对于 REPORT_BASE_DIR）
    safe_path = os.path.abspath(os.path.join(REPORT_BASE_DIR, filepath))
    
    # 2. 如果相对路径找不到文件，尝试直接使用绝对路径
    if not os.path.isfile(safe_path):
        abs_path = os.path.abspath(filepath)
        if os.path.isfile(abs_path) and abs_path.startswith(REPORT_BASE_DIR):
            safe_path = abs_path
    
    # 3. 安全检查：确保路径在允许的目录内
    if not (safe_path.startswith(REPORT_BASE_DIR + os.sep) or safe_path == REPORT_BASE_DIR):
        return jsonify({'error': '非法路径'}), 403
    if not os.path.isfile(safe_path):
        logger.warning(f'报告文件不存在: {safe_path} (原始路径: {filepath}, BASE: {REPORT_BASE_DIR})')
        return jsonify({'error': f'文件不存在: {filepath}'}), 404
    
    # 4. 设置正确的 Content-Type
    mime_map = {'.md': 'text/markdown', '.txt': 'text/plain', '.pdf': 'application/pdf', '.html': 'text/html'}
    ext = os.path.splitext(safe_path)[1].lower()
    mimetype = mime_map.get(ext, 'application/octet-stream')
    
    return send_from_directory(os.path.dirname(safe_path),
                               os.path.basename(safe_path),
                               as_attachment=True,
                               mimetype=mimetype)


# ============================================================================
# 路由：AI 对话交互
# ============================================================================

# 用户消息队列：scan_id -> Queue
CHAT_QUEUES = {}

@app.route('/api/scan/<scan_id>/chat', methods=['POST'])
def scan_chat(scan_id: str):
    """用户发送对话消息给AI"""
    scan = SCANS.get(scan_id)
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404

    data = request.get_json(force=True) or {}
    message = (data.get('message') or '').strip()
    if not message:
        return jsonify({'error': '消息不能为空'}), 400

    # 将消息放入队列，供 Worker 线程读取
    if scan_id not in CHAT_QUEUES:
        CHAT_QUEUES[scan_id] = Queue()
    CHAT_QUEUES[scan_id].put({'role': 'user', 'content': message, 'time': time.time()})

    return jsonify({'success': True, 'message': '消息已发送'})


@app.route('/api/scan/<scan_id>/pause', methods=['POST'])
def scan_pause(scan_id: str):
    """暂停扫描，等待用户指令"""
    scan = SCANS.get(scan_id)
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    scan['paused'] = True
    # 通知前端
    scan['queue'].put({'type': 'thinking', 'data': {
        'thinking_type': 'info', 'content': '⏸️ AI 已暂停，等待您的指令...\n请在下方对话框输入您的要求，AI将根据您的描述继续', 'agent': '📌 系统'
    }})
    return jsonify({'success': True, 'message': '已暂停'})


@app.route('/api/scan/<scan_id>/resume', methods=['POST'])
def scan_resume(scan_id: str):
    """恢复扫描"""
    scan = SCANS.get(scan_id)
    if not scan:
        return jsonify({'error': 'Scan not found'}), 404
    scan['paused'] = False
    if scan_id not in CHAT_QUEUES:
        CHAT_QUEUES[scan_id] = Queue()
    CHAT_QUEUES[scan_id].put({'role': 'resume', 'content': '', 'time': time.time()})
    scan['queue'].put({'type': 'thinking', 'data': {
        'thinking_type': 'info', 'content': '▶️ AI 已恢复执行', 'agent': '📌 系统'
    }})
    return jsonify({'success': True, 'message': '已恢复'})


def get_user_message(scan_id: str, timeout: float = 0.1):
    """非阻塞读取用户消息（供 Worker 线程调用）"""
    q = CHAT_QUEUES.get(scan_id)
    if not q:
        return None
    try:
        return q.get(timeout=timeout)
    except Empty:
        return None


# ============================================================================
# 启动
# ============================================================================

if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    print('=' * 55)
    print('  HexStrike AI -- Web Interface')
    print('  URL: http://localhost:7777')
    print('=' * 55)
    app.run(host='0.0.0.0', port=7777, debug=False, threaded=True)
