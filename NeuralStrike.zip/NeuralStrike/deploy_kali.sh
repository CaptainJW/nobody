#!/usr/bin/env bash
# HexStrike AI — Kali Linux 一键部署脚本
# 所有工具通过 apt/pip/go install 从系统获取，无需本地源码
set -e

cd "$(dirname "$0")"

G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; B='\033[0;34m'; BD='\033[1m'; NC='\033[0m'

echo ""
echo -e "${BD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BD}  ⚔️  HexStrike AI — Kali Linux 一键部署${NC}"
echo -e "${BD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# 1. Python 依赖
echo -e "  ${B}🐍 安装 Python 依赖...${NC}"
pip3 install flask requests beautifulsoup4 lxml --break-system-packages 2>/dev/null || \
pip3 install flask requests beautifulsoup4 lxml 2>/dev/null || true
echo -e "  ${G}✅ Python 依赖安装完成${NC}"
echo ""

# 2. 系统渗透测试工具
echo -e "  ${B}📦 安装系统渗透测试工具 (apt)...${NC}"

APT_TOOLS=(
    nmap masscan nuclei whatweb nikto dirsearch gobuster feroxbuster
    amass subfinder sqlmap dalfox testssl.sh dnsrecon dnsutils
    dirb ffuf wpscan seclists golang
)

sudo apt-get update -qq 2>/dev/null || true

installed=0; failed=0
for tool in "${APT_TOOLS[@]}"; do
    pkg=$tool
    [ "$tool" = "testssl.sh" ] && pkg=testssl
    if command -v "$tool" &>/dev/null || [ "$tool" = "seclists" ]; then
        echo -e "  ${G}✅${NC} $tool — 已安装"
        ((installed++))
    else
        echo -ne "  ⏳ 安装 $tool ..."
        if sudo apt-get install -y -qq "$pkg" 2>/dev/null; then
            echo -e "\r  ${G}✅${NC} $tool — 安装成功      "
            ((installed++))
        else
            echo -e "\r  ${R}❌${NC} $tool — 安装失败      "
            ((failed++))
        fi
    fi
done

echo ""
echo -e "  APT: ${G}${installed} 成功${NC}, ${R}${failed} 失败${NC}"
echo ""

# 3. pip 安装 sslyze
echo -e "  ${B}🐍 pip 安装 sslyze...${NC}"
pip3 install sslyze --break-system-packages -q 2>/dev/null || \
pip3 install sslyze -q 2>/dev/null || true
echo -e "  ${G}✅ sslyze 安装完成${NC}"
echo ""

# 4. Go 编译补充工具
echo -e "  ${B}🐹 Go 编译补充工具...${NC}"
if command -v go &>/dev/null; then
    GOPATH="${GOPATH:-$HOME/go}"
    export PATH="$PATH:$GOPATH/bin:/usr/local/go/bin"
    # 配置国内 Go 代理镜像（解决 proxy.golang.org 被墙问题）
    export GOPROXY="https://goproxy.cn,https://goproxy.io,direct"
    export GONOSUMCHECK="*"
    export GO111MODULE="on"
    go version

    declare -A GO_TOOLS=(
        ["dalfox"]="github.com/hahwul/dalfox/v2@latest"
        ["subfinder"]="github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
        ["nuclei"]="github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
        ["gobuster"]="github.com/OJ/gobuster/v3@latest"
        ["ffuf"]="github.com/ffuf/ffuf/v2@latest"
    )

    for tool in "${!GO_TOOLS[@]}"; do
        if command -v "$tool" &>/dev/null; then
            echo -e "  ${G}✅${NC} $tool — 已在PATH中"
        else
            echo -ne "  ⏳ go install $tool ..."
            if go install "${GO_TOOLS[$tool]}" 2>/dev/null; then
                mkdir -p ~/.local/bin
                [ -f "$GOPATH/bin/$tool" ] && ln -sf "$GOPATH/bin/$tool" ~/.local/bin/"$tool" 2>/dev/null || true
                sudo ln -sf "$GOPATH/bin/$tool" /usr/local/bin/"$tool" 2>/dev/null || true
                echo -e "\r  ${G}✅${NC} $tool — 编译成功      "
            else
                echo -e "\r  ${R}❌${NC} $tool — 编译失败      "
            fi
        fi
    done
else
    echo -e "  ${Y}⚠️  Go 未安装，跳过编译${NC}"
fi
echo ""

# 5. 权限设置
echo -e "  ${B}🔐 配置工具权限...${NC}"
for tool in nmap masscan; do
    tp=$(command -v "$tool" 2>/dev/null || true)
    if [ -n "$tp" ]; then
        sudo setcap cap_net_raw+ep "$tp" 2>/dev/null && \
        echo -e "  ${G}✅${NC} $tool: 网络权限已设置" || \
        echo -e "  ${Y}⚠️${NC}  $tool: 权限设置失败"
    fi
done
echo ""

# 6. Nuclei 模板
if command -v nuclei &>/dev/null; then
    echo -e "  ${B}📋 更新 Nuclei 模板...${NC}"
    nuclei -update-templates 2>/dev/null || true
    echo -e "  ${G}✅ Nuclei 模板已更新${NC}"
fi
echo ""

# 7. 防火墙
echo -e "  ${B}🔥 配置防火墙 (7777端口)...${NC}"
if command -v ufw &>/dev/null; then
    sudo ufw allow 7777/tcp 2>/dev/null && echo -e "  ${G}✅ UFW: 7777端口已开放${NC}" || true
elif command -v iptables &>/dev/null; then
    sudo iptables -A INPUT -p tcp --dport 7777 -j ACCEPT 2>/dev/null && echo -e "  ${G}✅ iptables: 7777端口已开放${NC}" || true
fi
echo ""

# 8. 获取局域网IP
LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
[ -z "$LOCAL_IP" ] && LOCAL_IP="0.0.0.0"

# 完成
echo -e "${BD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BD}  🚀 部署完成！${NC}"
echo -e "${BD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "  启动命令:"
echo -e "  ${B}cd $(pwd) && python3 main.py${NC}"
echo ""
echo -e "  访问地址:"
echo -e "  🖥️  Kali:    ${B}http://localhost:7777${NC}"
echo -e "  🪟  Windows: ${B}http://${LOCAL_IP}:7777${NC}"
echo ""
echo -e "  也可以运行工具安装脚本:"
echo -e "  ${B}sudo python3 setup_tools.py --auto${NC}"
echo ""
