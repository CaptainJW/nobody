#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NeuralStrike AI — 独立聊天 API Blueprint
支持SSE实时推送：工具调用进度、命令执行、结果输出、解码结果
"""

import sys
import os
import re
import json
import time
import base64
import hashlib
import threading
import subprocess
import logging
import urllib.parse

from flask import Blueprint, request, jsonify, Response

logger = logging.getLogger('chat_api')

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

chat_bp = Blueprint('chat', __name__)

CHAT_HISTORY = []
CHAT_HISTORY_LOCK = threading.Lock()

# ═══ 解码工具集 ═══
DECODERS = {
    'base64': lambda s: base64.b64decode(s).decode('utf-8', errors='replace'),
    'base32': lambda s: base64.b32decode(s).decode('utf-8', errors='replace'),
    'base16': lambda s: base64.b16decode(s).decode('utf-8', errors='replace'),
    'hex': lambda s: bytes.fromhex(s).decode('utf-8', errors='replace'),
    'url': lambda s: urllib.parse.unquote(s),
    'html_entity': lambda s: _decode_html_entities(s),
    'rot13': lambda s: s.translate(str.maketrans('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz', 'NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm')),
    'reverse': lambda s: s[::-1],
    'md5': lambda s: f"MD5不可逆，哈希值: {hashlib.md5(s.encode()).hexdigest()}",
    'sha1': lambda s: f"SHA1不可逆，哈希值: {hashlib.sha1(s.encode()).hexdigest()}",
    'sha256': lambda s: f"SHA256不可逆，哈希值: {hashlib.sha256(s.encode()).hexdigest()}",
}

def _decode_html_entities(s):
    """解码HTML实体"""
    s = s.replace('&amp;', '&')
    s = s.replace('&lt;', '<')
    s = s.replace('&gt;', '>')
    s = s.replace('&quot;', '"')
    s = s.replace('&#39;', "'")
    s = re.sub(r'&#(\d+);', lambda m: chr(int(m.group(1))), s)
    return s


# ═══ 工具命令映射 ═══
KNOWN_TOOLS = [
    'arp-scan', 'nmap', 'masscan', 'nuclei', 'nikto',
    'sqlmap', 'dalfox', 'dirsearch', 'gobuster', 'feroxbuster',
    'amass', 'subfinder', 'dnsrecon', 'testssl', 'sslyze',
    'hydra', 'john', 'hashcat',
    'chisel', 'crackmapexec', 'nxc', 'bloodhound',
    'curl', 'wget', 'whatweb', 'wpscan', 'ffuf',
    'whois', 'dig', 'host', 'traceroute', 'ping',
    'netstat', 'ss', 'ifconfig', 'ip', 'find', 'ls', 'cat',
    'unzip', 'tar', 'file', 'strings', 'xxd',
    'enum4linux', 'smbclient', 'rpcclient', 'smbmap',
    'redis-cli', 'mongo', 'mysql', 'psql',
    'linpeas', 'winpeas', 'linux-exploit-suggester',
    'msfconsole', 'searchsploit',
]

# 自然语言到命令映射
NL_PATTERNS = [
    (r'(?:扫描|scan)\s*(?:局域网|内网|网段|局域|lan)', 'arp-scan -l'),
    (r'(?:谁在线|主机发现|存活主机|host\s*discover|alive)', 'arp-scan -l'),
    (r'(?:端口扫描|port\s*scan)', 'nmap -sV -T4'),
    (r'(?:漏洞扫描|vuln.*scan|安全扫描)', 'nuclei'),
    (r'(?:子域名|subdomain)', 'subfinder -d'),
    (r'(?:目录扫描|dir.*scan|目录爆破)', 'dirsearch -u'),
    (r'(?:指纹识别|fingerprint|技术栈)', 'whatweb'),
    (r'(?:ssl|证书|certificate|tls', 'testssl'),
    (r'(?:dns|域名解析|dns查询)', 'dig'),
    (r'(?:提权|privilege|privesc|权限提升)', 'linpeas'),
    (r'(?:密码|credential|凭据|hash)', 'hydra'),
    (r'(?:smb|samba|共享)', 'enum4linux'),
    (r'(?:数据库|database|mysql)', 'mysql'),
    (r'(?:解码|decode|解密)', None),  # 特殊处理
    (r'(?:编码|encode|加密)', None),  # 特殊处理
]


@chat_bp.route('/chat', methods=['POST'])
def api_chat():
    """独立AI对话接口 — 支持工具命令执行 + 解码 + SSE事件流"""
    data = request.get_json(silent=True) or {}
    message = data.get('message', '').strip()
    if not message:
        return jsonify({'error': '消息不能为空'}), 400

    # 获取AI配置
    try:
        from config.ai_manager import AIConfigManager
        mgr = AIConfigManager()
        if not mgr.is_configured():
            return jsonify({'error': 'AI 服务未配置，请先在 API 设置中配置'}), 503
        ai_config = mgr.get_ai_config()
    except Exception as e:
        return jsonify({'error': f'加载 AI 配置失败: {e}'}), 500

    with CHAT_HISTORY_LOCK:
        CHAT_HISTORY.append({'role': 'user', 'content': message})
        if len(CHAT_HISTORY) > 50:
            CHAT_HISTORY[:] = CHAT_HISTORY[-50:]

    # 收集事件列表（发给前端展示）
    events = []

    # 1. 检测解码请求
    decode_result = _try_decode(message)
    if decode_result:
        events.append({'type': 'tool', 'content': f"🔓 解码工具执行\n解码方式: {decode_result['method']}\n原始数据: {decode_result['original'][:200]}", 'agent': '🔓 解码器'})
        events.append({'type': 'command', 'content': f"{decode_result['method']}({decode_result['original'][:100]})", 'agent': '🔓 解码器'})
        events.append({'type': 'result', 'content': f"✅ 解码成功\n方法: {decode_result['method']}\n结果: {decode_result['decoded']}", 'agent': '🔓 解码器'})

    # 2. 检测并执行工具命令
    tool_events = _execute_tool_command(message)
    events.extend(tool_events)

    # 构建AI系统提示
    system_prompt = """你是 NeuralStrike AI 渗透测试助手。你可以：
1. 回答安全相关问题和指导渗透测试
2. 帮助用户理解和分析扫描结果
3. 根据用户描述执行工具命令（如 arp-scan、nmap、sqlmap 等）
4. 提供漏洞利用和修复建议
5. 尝试提权、获取目标文件和目录信息
6. 解码编码数据（Base64、Hex、URL编码等）

当用户要求执行命令时，系统会自动检测并执行。
请根据执行结果给出专业分析。用中文回答。"""

    # 拼接工具执行结果
    context_parts = []
    if decode_result:
        context_parts.append(f"[解码结果] 方法={decode_result['method']}, 原文={decode_result['original'][:200]}, 结果={decode_result['decoded']}")
    for ev in events:
        if ev['type'] == 'result':
            context_parts.append(f"[工具输出]\n{ev['content'][:3000]}")

    # 调用AI
    try:
        from agents.ai_client import AIAgentFactory, AISession
        client = AIAgentFactory.create_client(ai_config['provider'], ai_config['config'])
        session = AISession(client, system_prompt)

        with CHAT_HISTORY_LOCK:
            history = CHAT_HISTORY[-20:]

        context_msg = ""
        if context_parts:
            context_msg = "\n\n[系统上下文]\n" + "\n".join(context_parts)

        full_message = message + context_msg
        response = session.chat(full_message)
        ai_reply = response if isinstance(response, str) else str(response)

        with CHAT_HISTORY_LOCK:
            CHAT_HISTORY.append({'role': 'assistant', 'content': ai_reply})

        result = {
            'reply': ai_reply,
            'tool_executed': len(events) > 0,
            'events': events,  # SSE事件列表
        }
        if decode_result:
            result['decode'] = decode_result
        return jsonify(result)

    except Exception as e:
        logger.error(f'AI对话失败: {e}')
        if events:
            return jsonify({
                'reply': f'AI 响应失败，但工具命令已执行',
                'tool_executed': True,
                'events': events,
                'ai_error': str(e),
            })
        return jsonify({'error': f'AI 对话失败: {e}'}), 500


@chat_bp.route('/chat/stream', methods=['POST'])
def api_chat_stream():
    """SSE流式对话 — 实时推送工具执行进度"""
    data = request.get_json(silent=True) or {}
    message = data.get('message', '').strip()
    if not message:
        return jsonify({'error': '消息不能为空'}), 400

    def generate():
        import shlex, shutil

        # 发送用户消息事件
        yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'info', 'content': '💬 用户: ' + message, 'agent': '👤 用户'})}\n\n"

        # 1. 解码检测
        decode_result = _try_decode(message)
        if decode_result:
            yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'tool', 'content': f'🔓 解码工具 | 方式: {decode_result[\"method\"]}', 'agent': '🔓 解码器'})}\n\n"
            yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'command', 'content': f'{decode_result[\"method\"]}({decode_result[\"original\"][:100]})', 'agent': '🔓 解码器'})}\n\n"
            yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'result', 'content': f'原始: {decode_result[\"original\"][:200]}\\n解码: {decode_result[\"decoded\"]}', 'agent': '🔓 解码器'})}\n\n"

        # 2. 工具命令检测与执行
        first_word = message.strip().split()[0] if message.strip().split() else ''
        is_tool_cmd = first_word in KNOWN_TOOLS or first_word.lower() in [t.lower() for t in KNOWN_TOOLS]

        if is_tool_cmd:
            cmd_str = message.strip()
            tool_name = cmd_str.split()[0]

            # 工具调用事件
            yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'tool', 'content': f'{tool_name} | 用途: 工具命令执行', 'agent': '🔧 工具'})}\n\n"

            # 检查工具可用性
            if not shutil.which(tool_name):
                yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'error', 'content': f'❌ 工具 {tool_name} 未安装，请前往🔧工具管理安装', 'agent': '❌ 系统'})}\n\n"
            else:
                # 命令执行事件
                yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'command', 'content': cmd_str, 'agent': tool_name})}\n\n"

                # 执行命令
                dangerous = ['rm ', 'del ', 'format', 'shutdown', 'reboot', 'mkfs', 'dd if=']
                if any(d in message.lower() for d in dangerous):
                    yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'error', 'content': f'❌ 拒绝执行危险命令: {cmd_str}', 'agent': '❌ 系统'})}\n\n"
                else:
                    try:
                        yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'action', 'content': '⏳ 命令执行中...', 'agent': tool_name})}\n\n"
                        result = subprocess.run(cmd_str, shell=True, capture_output=True, text=True, timeout=120, stdin=subprocess.DEVNULL)
                        output = result.stdout[:8000] if result.stdout else ''
                        error_out = result.stderr[:2000] if result.stderr else ''
                        combined = output + ('\n[stderr] ' + error_out[:500] if error_out and output else error_out if error_out else '')
                        if not combined:
                            combined = '(无输出)'
                        yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'result', 'content': combined, 'agent': tool_name})}\n\n"
                    except subprocess.TimeoutExpired:
                        yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'error', 'content': '⏱️ 命令执行超时(120秒)', 'agent': tool_name})}\n\n"
                    except Exception as e:
                        yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'error', 'content': f'执行失败: {e}', 'agent': tool_name})}\n\n"

        # 3. 自然语言检测
        elif not is_tool_cmd:
            for pattern, cmd in NL_PATTERNS:
                if re.search(pattern, message.lower()):
                    if cmd is None:
                        break  # 解码已处理
                    if shutil.which(cmd.split()[0]):
                        # 自动构建完整命令
                        full_cmd = cmd
                        if 'nmap' in cmd and not re.search(r'\d+\.\d+', message):
                            yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'info', 'content': f'💡 请指定目标地址，例如: nmap -sV 192.168.1.1', 'agent': '📌 系统'})}\n\n"
                        else:
                            yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'tool', 'content': f'{cmd.split()[0]} | 自然语言触发', 'agent': '🔧 工具'})}\n\n"
                            yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'command', 'content': full_cmd, 'agent': cmd.split()[0]})}\n\n"
                            try:
                                result = subprocess.run(full_cmd, shell=True, capture_output=True, text=True, timeout=120, stdin=subprocess.DEVNULL)
                                output = (result.stdout or '')[:8000]
                                yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'result', 'content': output or '(无输出)', 'agent': cmd.split()[0]})}\n\n"
                            except Exception as e:
                                yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'error', 'content': f'执行失败: {e}', 'agent': cmd.split()[0]})}\n\n"
                    break

        # 4. AI回复
        try:
            from config.ai_manager import AIConfigManager
            from agents.ai_client import AIAgentFactory, AISession
            mgr = AIConfigManager()
            ai_config = mgr.get_ai_config()
            client = AIAgentFactory.create_client(ai_config['provider'], ai_config['config'])
            session = AISession(client, '你是NeuralStrike AI渗透测试助手，用中文回答。')
            reply = session.chat(message)
            yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'analyze', 'content': '🤖 ' + reply, 'agent': '🤖 AI助手'})}\n\n"
        except Exception as e:
            yield f"event: thinking\ndata: {json.dumps({'thinking_type': 'error', 'content': f'AI回复失败: {e}', 'agent': '❌ AI'})}\n\n"

        yield f"event: done\ndata: {{}}\n\n"

    return Response(generate(), mimetype='text/event-stream',
                    headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'})


# ═══ 解码工具 ═══
def _try_decode(message: str) -> dict:
    """尝试自动解码消息中的编码数据"""
    # 提取可能的编码数据
    patterns = [
        (r'(?:base64|b64)[：:\s]+([A-Za-z0-9+/=]{4,})', 'base64'),
        (r'(?:base32)[：:\s]+([A-Z2-7=]{4,})', 'base32'),
        (r'(?:hex|十六进制)[：:\s]+([0-9a-fA-F]{4,})', 'hex'),
        (r'(?:url|URL编码)[：:\s]+(%.{2})+', 'url'),
        (r'(?:rot13)[：:\s]+(.+)', 'rot13'),
        (r'(?:解码|decode)[：:\s]+(.+)', None),  # 自动检测
    ]

    for pattern, method in patterns:
        match = re.search(pattern, message, re.IGNORECASE)
        if match:
            data = match.group(1).strip()
            if method:
                try:
                    decoded = DECODERS[method](data)
                    return {'method': method, 'original': data, 'decoded': decoded}
                except Exception:
                    continue
            else:
                # 自动尝试所有解码方式
                return _auto_decode(data)

    # 检测消息中是否包含编码数据（无需关键词触发）
    return _auto_detect_and_decode(message)


def _auto_decode(data: str) -> dict:
    """自动尝试所有解码方式"""
    results = []
    for name, decoder in DECODERS.items():
        try:
            decoded = decoder(data)
            if decoded and decoded != data and len(decoded) > 0:
                # 验证解码结果是否合理（包含可打印字符）
                printable_ratio = sum(1 for c in decoded if c.isprintable()) / max(len(decoded), 1)
                if printable_ratio > 0.8:
                    results.append({'method': name, 'original': data, 'decoded': decoded})
        except Exception:
            continue

    if results:
        # 返回最可能的结果（优先 base64 > hex > url > rot13）
        priority = ['base64', 'hex', 'url', 'base32', 'rot13', 'html_entity', 'reverse']
        for p in priority:
            for r in results:
                if r['method'] == p:
                    return r
        return results[0]
    return None


def _auto_detect_and_decode(message: str) -> dict:
    """自动检测消息中的编码数据并解码"""
    # 检测Base64
    b64_pattern = re.findall(r'[A-Za-z0-9+/]{20,}={0,2}', message)
    for b64 in b64_pattern:
        try:
            decoded = base64.b64decode(b64).decode('utf-8', errors='replace')
            if decoded and sum(1 for c in decoded if c.isprintable()) / max(len(decoded), 1) > 0.8:
                return {'method': 'base64', 'original': b64, 'decoded': decoded}
        except Exception:
            continue

    # 检测Hex
    hex_pattern = re.findall(r'\b[0-9a-fA-F]{16,}\b', message)
    for hex_str in hex_pattern:
        try:
            decoded = bytes.fromhex(hex_str).decode('utf-8', errors='replace')
            if decoded and sum(1 for c in decoded if c.isprintable()) / max(len(decoded), 1) > 0.8:
                return {'method': 'hex', 'original': hex_str, 'decoded': decoded}
        except Exception:
            continue

    # 检测URL编码
    if '%' in message and re.search(r'%[0-9a-fA-F]{2}', message):
        try:
            decoded = urllib.parse.unquote(message)
            if decoded != message:
                return {'method': 'url', 'original': message, 'decoded': decoded}
        except Exception:
            pass

    return None


# ═══ 工具命令执行 ═══
def _execute_tool_command(message: str) -> list:
    """检测并执行工具命令，返回事件列表"""
    import shlex, shutil

    events = []
    msg_lower = message.lower().strip()
    first_word = msg_lower.split()[0] if msg_lower.split() else ''

    # 检测直接命令
    if first_word in KNOWN_TOOLS or first_word.replace('-', '') in [t.replace('-', '') for t in KNOWN_TOOLS]:
        cmd_str = message.strip()
        dangerous = ['rm ', 'del ', 'format', 'shutdown', 'reboot', 'mkfs', 'dd if=']
        if any(d in msg_lower for d in dangerous):
            events.append({'type': 'error', 'content': f'❌ 拒绝执行危险命令: {cmd_str}', 'agent': '❌ 系统'})
            return events

        tool_name = cmd_str.split()[0]
        if not shutil.which(tool_name):
            events.append({'type': 'error', 'content': f"❌ 工具 '{tool_name}' 未安装。请前往 🔧 工具管理 页面安装。", 'agent': '❌ 系统'})
            return events

        # 工具调用事件
        events.append({'type': 'tool', 'content': f'{tool_name} | 用途: 工具命令执行\n命令: {cmd_str}', 'agent': '🔧 工具'})
        # 命令执行事件
        events.append({'type': 'command', 'content': cmd_str, 'agent': tool_name})

        try:
            result = subprocess.run(cmd_str, shell=True, capture_output=True, text=True, timeout=120, stdin=subprocess.DEVNULL)
            output = result.stdout[:8000] if result.stdout else ''
            error = result.stderr[:2000] if result.stderr else ''
            if result.returncode != 0 and not output:
                events.append({'type': 'error', 'content': f"❌ 命令执行失败 (退出码 {result.returncode}):\n{error or '无输出'}", 'agent': tool_name})
            else:
                combined = output
                if error and output:
                    combined += f"\n\n[stderr] {error[:500]}"
                events.append({'type': 'result', 'content': combined or "(无输出)", 'agent': tool_name})
        except subprocess.TimeoutExpired:
            events.append({'type': 'error', 'content': '⏱️ 命令执行超时 (120秒)。建议添加更严格的参数减少扫描范围。', 'agent': tool_name})
        except Exception as e:
            events.append({'type': 'error', 'content': f'❌ 执行失败: {e}', 'agent': tool_name})

        return events

    # 检测自然语言
    for pattern, cmd in NL_PATTERNS:
        if re.search(pattern, msg_lower):
            if cmd is None:
                return events  # 解码已处理
            if 'arp-scan' in cmd:
                if shutil.which('arp-scan'):
                    try:
                        result = subprocess.run(['arp-scan', '-l'], capture_output=True, text=True, timeout=120, stdin=subprocess.DEVNULL)
                        events.append({'type': 'tool', 'content': 'arp-scan | 用途: 局域网主机发现', 'agent': '🔧 工具'})
                        events.append({'type': 'command', 'content': 'arp-scan -l', 'agent': 'arp-scan'})
                        events.append({'type': 'result', 'content': result.stdout[:8000] or "(无输出)", 'agent': 'arp-scan'})
                    except Exception as e:
                        events.append({'type': 'error', 'content': f'❌ arp-scan 执行失败: {e}', 'agent': 'arp-scan'})
                else:
                    events.append({'type': 'error', 'content': '❌ arp-scan 未安装。请前往 🔧 工具管理 页面安装。', 'agent': '❌ 系统'})
            return events

    return events
