#!/usr/bin/env python3
"""
HexStrike GUI - 配置管理模块
修复版本：简化ConfigManager类，解决参数签名问题
"""

import os
import json
import logging
import secrets
import copy
from pathlib import Path
from typing import Any, Dict, Optional


class ConfigManager:
    """配置管理器类 - 简化版本修复参数签名问题"""

    def __init__(self):
        self.current_dir = os.path.dirname(os.path.abspath(__file__))
        self.data_dir = os.path.join(self.current_dir, "data")
        os.makedirs(self.data_dir, exist_ok=True)

        self.config_file = os.path.join(self.data_dir, "config.json")
        # 核心配置文件（来自参考材料[1][2]）
        self.core_config_file = os.path.join(self.current_dir, "core", "server_config.json")
        # AI配置文件（项目特有）
        self.ai_config_file = os.path.join(self.current_dir, "config", "ai_config.json")

        # 默认配置（基于参考材料[1][2]配置）
        self.default_config = {
            "server": {
                "host": "0.0.0.0",  # 监听所有接口，允许 Kali→Windows 远程访问
                "port": 8888,
                "debug": True,
                "threaded": True,
                "auto_start": False,
                "auto_connect": False,
                "timeout": 30,
                "retry_count": 3,
                "retry_delay": 5,
                "ssl_cert": None,
                "ssl_key": None
            },
            "gui": {
                "theme": "dark",
                "window_width": 1200,
                "window_height": 800,
                "font_size": 10,
                "font_family": "Segoe UI",
                "language": "zh_CN",
                "show_toolbar": True,
                "show_statusbar": True
            },
            "security": {
                "secret_key": "",  # 首次运行时自动生成并持久化，不再每次重启变化
                "token_expiration": 3600,
                "rate_limit_enabled": True,
                "rate_limit": {
                    "per_minute": 60,
                    "per_hour": 1000
                },
                "enable_encryption": False,
                "verify_ssl": True,
                "max_request_size": 10485760,
                "session_timeout": 1800
            },
            "mcp_servers": {
                "memory_analysis": {
                "enabled": True,
                "port": 8889
            },
            "network_analysis": {
                "enabled": True,
                "port": 8890
            },
            "process_analysis": {
                "enabled": True,
                    "port": 8891
                }
            },
            "logging": {
                "level": "INFO",
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                "file": "logs/server.log",
                "max_size_mb": 10,
                "backup_count": 5,
                "log_to_file": True,
                "log_to_console": True
            },
            "performance": {
                "cache_enabled": True,
                "cache_size": 100,
                "thread_pool_size": 4,
                "max_memory_usage": 512
            },
            "tools": {
                "auto_update": True,
                "check_interval": 3600,
                "tool_path": "tools",
                "max_concurrent_tools": 3
            }
        }

        # 加载配置
        self.config = {}
        self.load_config()

        # 确保目录存在
        self.create_directories()

    def create_directories(self):
        """创建必要目录"""
        dirs = [
            self.data_dir,
            os.path.join(self.current_dir, "logs"),
            os.path.join(self.current_dir, "results"),
            os.path.join(self.current_dir, "tools")
        ]
        for dir_path in dirs:
            os.makedirs(dir_path, exist_ok=True)

    def load_config(self):
        """加载配置"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                # 合并默认配置（深拷贝避免污染默认值）
                self.config = self._merge_dicts(
                    copy.deepcopy(self.default_config), loaded_config
                )
            else:
                self.config = copy.deepcopy(self.default_config)
                self.save_config()

            # 首次运行自动生成随机密钥（持久化，重启不变）
            if not self.config.get('security', {}).get('secret_key'):
                self.config.setdefault('security', {})
                self.config['security']['secret_key'] = secrets.token_hex(32)
                self.save_config()

            logging.info(f"配置加载成功: {self.config_file}")

        except Exception as e:
            logging.error(f"加载配置失败: {e}")
            self.config = copy.deepcopy(self.default_config)

    def save_config(self):
        """保存配置"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            logging.info(f"配置已保存: {self.config_file}")
            return True
        except Exception as e:
            logging.error(f"保存配置失败: {e}")
            return False

    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """
        根据键获取配置值，支持点分隔符
        示例: get("server.host") 或 get("server.port")
        """
        try:
            # 分割键路径
            keys = key.split('.')
            value = self.config

            # 遍历路径
            for k in keys:
                if isinstance(value, dict) and k in value:
                    value = value[k]
                else:
                    return default

            return value

        except Exception as e:
            logging.error(f"获取配置失败 {key}: {e}")
            return default

    def set(self, key: str, value: Any) -> bool:
        """
        设置配置值，支持点分隔符
        示例: set("server.host", "localhost")
        """
        try:
            # 分割键路径
            keys = key.split('.')
            config = self.config

            # 遍历到最后一个键的父级
            for k in keys[:-1]:
                if k not in config:
                    config[k] = {}
                config = config[k]

            # 设置值
            config[keys[-1]] = value

            # 保存到文件
            return self.save_config()

        except Exception as e:
            logging.error(f"设置配置失败 {key}: {e}")
            return False

    def _merge_dicts(self, default: Dict, override: Dict) -> Dict:
        """递归合并字典（深拷贝，避免污染默认值）"""
        result = copy.deepcopy(default)

        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_dicts(result[key], value)
            else:
                result[key] = value

        return result

    # 方便的属性访问
    @property
    def server_host(self):
        return self.get("server.host", "localhost")

    @property
    def server_port(self):
        value = self.get("server.port", 8888)
        return value if isinstance(value, int) else 8888

    @property
    def server_path(self):
        return self.get("server.path", "core/hexstrike_server.py")

    @property
    def auto_start(self):
        return self.get("server.auto_start", False)

    @server_host.setter
    def server_host(self, value):
        self.set("server.host", value)

    @server_port.setter
    def server_port(self, value):
        self.set("server.port", value)

    @server_path.setter
    def server_path(self, value):
        self.set("server.path", value)


# 全局配置实例
_config_manager = None


def get_config() -> ConfigManager:
    """获取配置管理器单例"""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
    return _config_manager


# 测试函数
if __name__ == "__main__":
    config = get_config()
    print("配置文件路径:", config.config_file)
    print("服务器主机:", config.server_host)
    print("服务器端口:", config.server_port)
    print("服务器路径:", config.server_path)