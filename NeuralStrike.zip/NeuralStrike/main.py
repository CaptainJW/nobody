#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NeuralStrike AI — 主入口（Linux/Kali 专用）
启动 Web 界面服务，浏览器访问 http://localhost:7777
"""

import sys
import os
import atexit
import signal
import socket
import logging
import threading
import subprocess

# 关闭标准输入 — 防止 Flask 或其他库尝试读取 tty 导致 suspended (tty input)
try:
    sys.stdin.close()
    sys.stdin = open(os.devnull, 'r')
except Exception:
    pass

# 确保 ~/.local/bin 在 PATH 中（GitHub 安装的工具路径）
_local_bin = os.path.expanduser('~/.local/bin')
if _local_bin not in os.environ.get('PATH', ''):
    os.environ['PATH'] = _local_bin + os.pathsep + os.environ.get('PATH', '')

# 确保日志目录和数据目录存在
os.makedirs('logs', exist_ok=True)
os.makedirs('data', exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/neuralstrike.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger('NeuralStrike')

# 记录服务器端口，退出时自动清理
_SERVER_PORT = None
_FLASK_SERVER = None


def _cleanup_port():
    """退出时自动关闭占用端口的进程"""
    global _SERVER_PORT, _FLASK_SERVER
    if _SERVER_PORT is None:
        return

    port = _SERVER_PORT
    killed_pids = []

    # 方法1: 通过 lsof 找到占用进程
    try:
        result = subprocess.run(
            ['lsof', '-t', '-i', f':{port}'],
            capture_output=True, text=True, timeout=5
        )
        pids = result.stdout.strip().split('\n') if result.stdout.strip() else []
        for pid in pids:
            if pid and pid.isdigit() and int(pid) != os.getpid():
                try:
                    os.kill(int(pid), signal.SIGKILL)
                    killed_pids.append(pid)
                except (ProcessLookupError, PermissionError):
                    pass
    except Exception:
        pass

    # 方法2: 通过 fuser 找到占用进程（lsof 可能不存在）
    if not killed_pids:
        try:
            result = subprocess.run(
                ['fuser', f'{port}/tcp'],
                capture_output=True, text=True, timeout=5
            )
            pids = result.stdout.strip().split()
            for pid in pids:
                if pid.isdigit() and int(pid) != os.getpid():
                    try:
                        os.kill(int(pid), signal.SIGKILL)
                        killed_pids.append(pid)
                    except (ProcessLookupError, PermissionError):
                        pass
        except Exception:
            pass

    # 方法3: 通过 ss/netstat 找到占用进程
    if not killed_pids:
        try:
            result = subprocess.run(
                ['ss', '-tlnp', f'sport = :{port}'],
                capture_output=True, text=True, timeout=5
            )
            import re
            for match in re.finditer(r'pid=(\d+)', result.stdout):
                pid = match.group(1)
                if pid.isdigit() and int(pid) != os.getpid():
                    try:
                        os.kill(int(pid), signal.SIGKILL)
                        killed_pids.append(pid)
                    except (ProcessLookupError, PermissionError):
                        pass
        except Exception:
            pass

    if killed_pids:
        print(f'  🧹 已清理端口 {port} 上的进程: PID={", ".join(killed_pids)}')
    print('  ✅ NeuralStrike 服务器已停止，端口已释放')


def _shutdown_flask():
    """优雅关闭 Flask 服务器"""
    global _FLASK_SERVER
    try:
        # 尝试通过 Werkzeug 的 shutdown 钩子关闭
        from werkzeug.serving import _get_reloader_provider
        os.kill(os.getpid(), signal.SIGTERM)
    except Exception:
        pass


def _signal_handler(signum, frame):
    """统一信号处理 — 优雅退出"""
    sig_names = {
        signal.SIGINT: 'SIGINT (Ctrl+C)',
        signal.SIGTERM: 'SIGTERM',
        signal.SIGHUP: 'SIGHUP (终端关闭)',
        signal.SIGTSTP: 'SIGTSTP (Ctrl+Z)',
        signal.SIGQUIT: 'SIGQUIT',
    }
    sig_name = sig_names.get(signum, f'信号{signum}')

    print()
    print(f'  🛑 收到 {sig_name}，正在停止 NeuralStrike 服务器...')

    # 清理端口
    _cleanup_port()

    # 直接退出，不挂起
    os._exit(0)


def _suspend_handler(signum, frame):
    """SIGTSTP (Ctrl+Z) 处理 — 终止而非挂起"""
    print()
    print('  ⚠️  检测到 Ctrl+Z (挂起请求)，NeuralStrike 不支持挂起')
    print('  🛑 正在终止服务器并释放端口...')

    _cleanup_port()

    # 确保终止所有子进程
    try:
        import subprocess
        subprocess.run(['pkill', '-f', 'python3.*main.py'], capture_output=True, timeout=3)
    except Exception:
        pass

    print('  ✅ 服务器已终止')
    os._exit(0)


# 注册信号处理
signal.signal(signal.SIGINT, _signal_handler)     # Ctrl+C
signal.signal(signal.SIGTERM, _signal_handler)     # kill 命令
signal.signal(signal.SIGHUP, _signal_handler)      # 终端关闭
signal.signal(signal.SIGTSTP, _suspend_handler)    # Ctrl+Z — 终止而非挂起
signal.signal(signal.SIGQUIT, _signal_handler)     # Ctrl+\

# 忽略 SIGPIPE（Broken pipe 防止崩溃）
try:
    signal.signal(signal.SIGPIPE, signal.SIG_IGN)
except AttributeError:
    pass  # Windows 没有 SIGPIPE

# 注册退出清理
atexit.register(_cleanup_port)


def check_port_available(port):
    """检查端口是否可用"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.settimeout(1)
            result = s.connect_ex(('127.0.0.1', port))
            return result != 0  # 连接失败=端口可用
    except Exception:
        return True


def check_firewall(port):
    """检查防火墙是否放行了指定端口"""
    try:
        result = subprocess.run(['ufw', 'status'], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            if 'inactive' in result.stdout.lower():
                return True, 'UFW 防火墙未启用（所有端口开放）'
            if str(port) in result.stdout:
                return True, f'UFW 已放行端口 {port}'
            return False, f'UFW 防火墙可能阻止了端口 {port}，请运行: sudo ufw allow {port}/tcp'
    except Exception:
        pass

    try:
        result = subprocess.run(['iptables', '-L', '-n'], capture_output=True, text=True, timeout=5)
        if result.returncode == 0 and 'DROP' in result.stdout and str(port) not in result.stdout:
            return None, f'iptables 可能阻止端口 {port}'
    except Exception:
        pass

    return True, '防火墙检查完成'


def check_dependencies():
    """检查必要依赖"""
    missing = []
    try:
        import flask
    except ImportError:
        missing.append('flask')
    try:
        import requests
    except ImportError:
        missing.append('requests')

    if missing:
        print(f'  ❌ 缺少依赖: {", ".join(missing)}')
        print(f'  💡 请运行: pip3 install {" ".join(missing)}')
        sys.exit(1)


def check_code_version():
    """验证 web_server.py 是否包含最新API"""
    try:
        with open(os.path.join(os.path.dirname(__file__), 'web_server.py'), 'r', encoding='utf-8') as f:
            content = f.read()

        missing_apis = []
        for api in ['/api/chat', '/api/report/generate', '/api/tools/install']:
            if api not in content:
                missing_apis.append(api)

        if missing_apis:
            print(f'  ⚠️  web_server.py 缺少API: {", ".join(missing_apis)}')
            print(f'  💡 请同步最新代码到 Kali 后重启')
            print()
            return False
        return True
    except Exception as e:
        logger.debug(f'版本检查失败: {e}')
        return True  # 继续启动


def check_tools():
    """启动时快速检查工具可用状态"""
    try:
        from agents.tool_manager import get_tool_manager
        tm = get_tool_manager()
        available = sum(1 for t in tm.get_all_tools().values() if t.get('available'))
        total = len(tm.get_all_tools())
        if available < total:
            missing = [k for k, v in tm.get_all_tools().items() if not v.get('available')]
            print(f'  ⚠️  工具: {available}/{total} 可用 (缺失: {", ".join(missing[:5])}{"..." if len(missing)>5 else ""})')
            print(f'  💡 打开网页 → 🔧 工具管理 → 点击"一键安装"')
        else:
            print(f'  ✅ 工具: {available}/{total} 全部可用')
        print()
        return available, total
    except Exception as e:
        logger.debug(f'工具检查失败: {e}')
        return 0, 0


def get_local_ip():
    """获取本机局域网 IP 地址"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return '127.0.0.1'


def check_network_access(port, local_ip):
    """检查网络可访问性"""
    issues = []

    if not check_port_available(port):
        # 端口被占用，尝试自动清理
        print(f'  ⚠️ 端口 {port} 被占用，尝试自动清理...')
        try:
            result = subprocess.run(
                ['lsof', '-t', '-i', f':{port}'],
                capture_output=True, text=True, timeout=5
            )
            pids = result.stdout.strip().split('\n') if result.stdout.strip() else []
            for pid in pids:
                if pid and pid.isdigit() and int(pid) != os.getpid():
                    try:
                        os.kill(int(pid), signal.SIGKILL)
                        print(f'    已终止 PID={pid}')
                    except (ProcessLookupError, PermissionError):
                        pass
            import time
            time.sleep(1)
            if check_port_available(port):
                print(f'  ✅ 端口 {port} 已释放')
            else:
                issues.append(f'⚠️ 端口 {port} 仍被占用，尝试: fuser -k {port}/tcp 或使用 --port=8080')
        except Exception:
            issues.append(f'⚠️ 端口 {port} 已被占用，请使用 --port=其他端口')

    fw_ok, fw_msg = check_firewall(port)
    if fw_ok is False:
        issues.append(fw_msg)
    elif fw_ok is None:
        issues.append(fw_msg)

    try:
        test_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        test_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        test_sock.bind(('0.0.0.0', port))
        test_sock.close()
    except OSError as e:
        issues.append(f'❌ 无法绑定端口 {port}: {e}')

    return issues


def open_browser(host, port, delay=1.5):
    """延迟打开浏览器"""
    import time
    time.sleep(delay)
    url = f'http://{host}:{port}'
    try:
        import webbrowser
        webbrowser.open(url)
    except Exception:
        pass


def main():
    """主函数 — 启动 Web 服务器"""
    check_dependencies()

    host = '0.0.0.0'
    port = 7777

    for arg in sys.argv[1:]:
        if arg.startswith('--port='):
            try:
                port = int(arg.split('=')[1])
            except ValueError:
                print(f'无效端口号: {arg}')
                sys.exit(1)
        elif arg.startswith('--host='):
            host = arg.split('=')[1]
        elif arg in ('-h', '--help'):
            print('用法: python3 main.py [选项]')
            print()
            print('选项:')
            print('  --host=HOST      监听地址 (默认: 0.0.0.0)')
            print('  --port=PORT      监听端口 (默认: 7777)')
            print('  -h, --help       显示帮助')
            sys.exit(0)

    local_ip = get_local_ip()

    # 启动横幅
    print()
    print('  ███╗   ██╗███████╗███████╗██████╗     ██████╗ ██╗   ██╗███████╗███████╗██████╗  ██████╗ ████████╗██╗  ██╗███████╗')
    print('  ████╗  ██║██╔════╝██╔════╝██╔══██╗    ██╔═══██╗██║   ██║██╔════╝██╔════╝██╔══██╗██╔═══██╗╚══██╔══╝██║  ██║██╔════╝')
    print('  ██╔██╗ ██║█████╗  █████╗  ██████╔╝    ██║   ██║██║   ██║█████╗  █████╗  ██████╔╝██║   ██║   ██║   ███████║█████╗  ')
    print('  ██║╚██╗██║██╔══╝  ██╔══╝  ██╔═══╝     ██║   ██║╚██╗ ██╔╝██╔══╝  ██╔══╝  ██╔══██╗██║   ██║   ██║   ██╔══██║██╔══╝  ')
    print('  ██║ ╚████║███████╗███████╗██║         ╚██████╔╝ ╚████╔╝ ███████╗███████╗██║  ██║╚██████╔╝   ██║   ██║  ██║███████╗')
    print('  ╚═╝  ╚═══╝╚══════╝╚══════╝╚═╝          ╚═════╝   ╚═══╝  ╚══════╝╚══════╝╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚══════╝')
    print()
    print(f'  ╔═════════════════════════════════════════════════╗')
    print(f'  ║  NeuralStrike AI — 智能渗透测试平台            ║')
    print(f'  ╚═════════════════════════════════════════════════╝')
    print()

    # 验证代码是否完整
    print('  🔍 代码完整性检查...')
    check_code_version()

    # 网络诊断
    print('  🔍 网络诊断...')
    issues = check_network_access(port, local_ip)
    if issues:
        print()
        for issue in issues:
            print(f'    {issue}')
        print()
        if any('ufw' in i.lower() for i in issues):
            print('  🔧 尝试自动开放防火墙...')
            try:
                subprocess.run(['sudo', 'ufw', 'allow', f'{port}/tcp'],
                               capture_output=True, timeout=10)
                print(f'  ✅ 已执行: sudo ufw allow {port}/tcp')
            except Exception:
                print(f'  ❌ 自动开放失败，请手动执行: sudo ufw allow {port}/tcp')
            print()
    else:
        print('  ✅ 网络检查通过')
    print()

    print(f'  🖥️  本机访问:  http://localhost:{port}')
    if host == '0.0.0.0' and local_ip != '127.0.0.1':
        print(f'  🌐 局域网访问: http://{local_ip}:{port}')
        print()
        print('  📌 从 Windows 浏览器访问上面的局域网地址即可')
    print()

    # 检查工具
    check_tools()

    print('  💡 你可以直接在网页聊天栏输入命令与AI对话（无需开始扫描）')
    print('  🛑 按 Ctrl+C 停止服务器（端口自动释放）')
    print('  ⚠️  按 Ctrl+Z 将自动终止服务器（不支持挂起）')
    print('=' * 60)

    # 自动打开浏览器
    display_host = 'localhost' if host in ('0.0.0.0', '') else host
    if os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY'):
        threading.Thread(
            target=open_browser,
            args=(display_host, port),
            daemon=True
        ).start()

    # 启动 Flask 服务器
    try:
        global _SERVER_PORT
        _SERVER_PORT = port
        from web_server import app
        app.run(
            host=host,
            port=port,
            debug=False,
            threaded=True,
            use_reloader=False,
        )
    except ImportError as e:
        logger.error(f'导入 web_server 失败: {e}')
        print(f'  ❌ 无法加载 Web 服务器: {e}')
        print()
        print('  排查步骤:')
        print('    1. 确认在项目根目录运行: cd /home/kali/NeuralStrike')
        print('    2. 安装依赖: pip3 install flask requests beautifulsoup4 lxml')
        print('    3. 检查 web_server.py 是否存在且完整')
        sys.exit(1)
    except OSError as e:
        if 'Address already in use' in str(e):
            print(f'  ❌ 端口 {port} 已被占用')
            print(f'  💡 解决方法:')
            print(f'     - 查看占用进程: sudo lsof -i :{port}')
            print(f'     - 杀掉占用进程: sudo kill $(sudo lsof -t -i :{port})')
            print(f'     - 或使用其他端口: python3 main.py --port=8080')
        else:
            print(f'  ❌ 启动失败: {e}')
        sys.exit(1)
    except SystemExit:
        raise
    except Exception as e:
        logger.error(f'服务器运行错误: {e}', exc_info=True)
        print(f'  ❌ 服务器运行错误: {e}')
        print(f'  详细日志: logs/neuralstrike.log')
        sys.exit(1)
    finally:
        # 无论如何都清理端口
        _cleanup_port()


if __name__ == '__main__':
    main()
