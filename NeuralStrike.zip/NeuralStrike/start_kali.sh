#!/usr/bin/env bash
# HexStrike AI — 快速启动脚本
cd "$(dirname "$0")"
python3 main.py "$@"
