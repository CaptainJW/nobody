# agents/ai_client.py
# AI客户端统一模块 — OpenAI兼容客户端消除200+行重复代码
import json
import logging
import time
import threading
from typing import Dict, Any, Optional

try:
    import requests
except ImportError:
    requests = None  # 延迟导入保护：GUI仍然可用

from .utils import parse_json_response, mask_api_key

logger = logging.getLogger(__name__)

# ============================================================================
# 速率限制器
# ============================================================================

class RateLimiter:
    """AI调用速率限制器 — 防止API额度烧尽（线程安全）"""

    def __init__(self, calls_per_minute: int = 20, calls_per_hour: int = 200):
        self.min_interval = 60.0 / calls_per_minute
        self.hour_limit = calls_per_hour
        self._last_call_time = 0.0
        self._hour_calls = []
        self._lock = threading.Lock()

    def wait_if_needed(self):
        """如果调用过快，等待一下（线程安全）"""
        with self._lock:
            now = time.time()
            # 清理1小时前的记录
            self._hour_calls = [t for t in self._hour_calls if now - t < 3600]

            # 每小时限额检查
            if len(self._hour_calls) >= self.hour_limit:
                oldest = self._hour_calls[0]
                wait_time = 3600 - (now - oldest) + 1
                logger.warning("已达到每小时调用限额(%d)，等待 %.0f 秒", self.hour_limit, wait_time)
            else:
                # 每分钟限额检查
                elapsed = now - self._last_call_time
                if elapsed < self.min_interval:
                    wait_time = self.min_interval - elapsed
                    logger.debug("速率限制: 等待 %.1f 秒", wait_time)
                else:
                    wait_time = 0

        # 在锁外等待（不阻塞其他线程）
        if wait_time > 0:
            time.sleep(wait_time)

        with self._lock:
            self._last_call_time = time.time()
            self._hour_calls.append(self._last_call_time)


# 全局速率限制器
_rate_limiter = RateLimiter()


# ============================================================================
# 基类
# ============================================================================

class BaseAIClient:
    """AI客户端基类"""

    def __init__(self, config: Dict[str, Any]):
        self.api_key = config.get('api_key', '')
        self.base_url = config.get('base_url', 'https://api.openai.com/v1')
        self.model = config.get('model', 'gpt-3.5-turbo')
        self.timeout = config.get('timeout', 60)

    def chat(self, prompt: str, system_prompt: str = None) -> str:
        """聊天接口 — 子类必须实现"""
        raise NotImplementedError("子类必须实现chat方法")

    def _check_requests(self):
        """检查 requests 库是否可用"""
        if requests is None:
            raise ImportError("缺少 requests 库，请安装: pip install requests")

    def _rate_limit_wait(self):
        """速率限制检查"""
        _rate_limiter.wait_if_needed()


# ============================================================================
# OpenAI兼容客户端 — 统一处理6个供应商（消除200+行重复代码）
# ============================================================================

class OpenAICompatibleClient(BaseAIClient):
    """OpenAI兼容客户端 — 适用于所有遵循 /chat/completions 接口的供应商

    支持的供应商: OpenAI, DeepSeek, SiliconFlow, Qwen, Zhipu, Kimi
    不支持的: Claude（使用独立的ClaudeClient）
    """

    def chat(self, prompt: str, system_prompt: str = None) -> str:
        """通用聊天接口"""
        self._check_requests()
        self._rate_limit_wait()

        messages = []
        if system_prompt:
            messages.append({'role': 'system', 'content': system_prompt})
        messages.append({'role': 'user', 'content': prompt})

        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
        data = {
            'model': self.model,
            'messages': messages,
            'temperature': 0.7,
            'max_tokens': 2000
        }

        try:
            response = requests.post(
                f'{self.base_url}/chat/completions',
                headers=headers,
                json=data,
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()['choices'][0]['message']['content']
        except Exception as e:
            # 日志中脱敏API密钥
            logger.error("%s API调用失败: %s (key: %s)",
                         self.__class__.__name__, e, mask_api_key(self.api_key))
            return json.dumps({"status": "error", "message": str(e)})


# 具名子类 — 只需覆盖默认值，chat()全部继承OpenAICompatibleClient

class OpenAIClient(OpenAICompatibleClient):
    """OpenAI客户端"""
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get('base_url', 'https://api.openai.com/v1')

class DeepSeekClient(OpenAICompatibleClient):
    """DeepSeek客户端"""
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get('base_url', 'https://api.deepseek.com/v1')
        self.model = config.get('model', 'deepseek-chat')

class SiliconFlowClient(OpenAICompatibleClient):
    """硅基流动客户端"""
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get('base_url', 'https://api.siliconflow.cn/v1')
        self.model = config.get('model', 'Qwen/Qwen2.5-72B-Instruct-AWQ')

class QwenClient(OpenAICompatibleClient):
    """通义千问客户端"""
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get('base_url', 'https://dashscope.aliyuncs.com/compatible-mode/v1')
        self.model = config.get('model', 'qwen-turbo')

class ZhipuClient(OpenAICompatibleClient):
    """智谱AI客户端"""
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get('base_url', 'https://open.bigmodel.cn/api/paas/v4')
        self.model = config.get('model', 'glm-4-flash')

class KimiClient(OpenAICompatibleClient):
    """月之暗面Kimi客户端"""
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get('base_url', 'https://api.moonshot.cn/v1')
        self.model = config.get('model', 'moonshot-v1-8k')


# ============================================================================
# Claude客户端 — 独立实现（非OpenAI兼容格式）
# ============================================================================

class ClaudeClient(BaseAIClient):
    """Claude客户端 — Anthropic Messages API 格式"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get('base_url', 'https://api.anthropic.com/v1')
        self.model = config.get('model', 'claude-3-5-sonnet-20241022')

    def chat(self, prompt: str, system_prompt: str = None) -> str:
        """Claude聊天接口"""
        self._check_requests()
        self._rate_limit_wait()

        headers = {
            'x-api-key': self.api_key,
            'anthropic-version': '2023-06-01',
            'Content-Type': 'application/json'
        }
        data = {
            'model': self.model,
            'max_tokens': 2000,
            'messages': [{'role': 'user', 'content': prompt}]
        }
        if system_prompt:
            data['system'] = system_prompt

        try:
            response = requests.post(
                f'{self.base_url}/messages',
                headers=headers,
                json=data,
                timeout=self.timeout
            )
            response.raise_for_status()
            return response.json()['content'][0]['text']
        except Exception as e:
            logger.error("Claude API调用失败: %s (key: %s)", e, mask_api_key(self.api_key))
            return json.dumps({"status": "error", "message": str(e)})


# ============================================================================
# 模拟客户端
# ============================================================================

class MockAIClient(BaseAIClient):
    """模拟AI客户端 — 用于测试和无API Key时的降级"""

    def __init__(self, config: Dict[str, Any] = None):
        super().__init__(config or {})

    def chat(self, prompt: str, system_prompt: str = None) -> str:
        """模拟聊天接口"""
        if "初始分析" in prompt:
            return json.dumps({
                "target_type": "web_application",
                "tech_stack": ["Apache", "PHP"],
                "attack_surface": ["port_scan", "web_fingerprint"],
                "strategy": "先进行信息收集",
                "time_estimate": 300
            }, ensure_ascii=False)
        elif "制定策略" in prompt:
            return json.dumps({
                "phases": [{"name": "信息收集", "agents": [{"agent": "info_gathering", "tasks": ["port_scan", "fingerprint"], "parallel": False, "priority": "high", "timeout": 300}], "success_criteria": "发现开放端口和服务", "failure_action": "扩展扫描范围"}],
                "total_estimated_time": 300,
                "critical_path": ["信息收集"]
            }, ensure_ascii=False)
        elif "制定执行计划" in prompt:
            return json.dumps({
                "strategy": "端口扫描策略",
                "steps": [{"action": "port_scan", "params": {"tool": "nmap", "ports": "80,443"}, "reason": "检测Web服务"}],
                "priority": "high",
                "estimated_time": "60"
            }, ensure_ascii=False)
        elif "评估" in prompt or "结果" in prompt:
            return json.dumps({
                "key_findings": ["发现开放端口80和443", "识别出Apache Web服务器"],
                "security_issues": [{"type": "信息泄露", "severity": "medium", "description": "服务器版本信息暴露"}],
                "confidence": 0.8,
                "needs_verification": True,
                "verification_suggestions": ["验证服务版本是否存在已知漏洞"]
            }, ensure_ascii=False)
        elif "决定下一步" in prompt:
            return json.dumps({
                "next_agents": [{"agent": "info_gathering", "params": {"task": "web_fingerprint"}, "priority": "high", "reason": "需要进一步识别Web技术"}],
                "stop_if": "发现高危漏洞",
                "fallback": "扩展扫描范围"
            }, ensure_ascii=False)
        else:
            return json.dumps({"response": "这是模拟的AI响应", "prompt_analysis": "未识别的prompt类型"}, ensure_ascii=False)


# ============================================================================
# 供应商注册表
# ============================================================================

PROVIDER_REGISTRY = {
    "openai": {
        "name": "OpenAI",
        "client_class": OpenAIClient,
        "default_base_url": "https://api.openai.com/v1",
        "default_model": "gpt-4",
        "models": ["gpt-4", "gpt-4-turbo", "gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo"],
        "icon": "🟢",
        "description": "OpenAI GPT系列大模型",
        "api_key_placeholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxx",
        "models_endpoint": "/models",
        "supports_model_fetch": True,
    },
    "deepseek": {
        "name": "DeepSeek",
        "client_class": DeepSeekClient,
        "default_base_url": "https://api.deepseek.com/v1",
        "default_model": "deepseek-chat",
        "models": ["deepseek-chat", "deepseek-reasoner"],
        "icon": "🔵",
        "description": "DeepSeek深度求索大模型",
        "api_key_placeholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxx",
        "models_endpoint": "/models",
        "supports_model_fetch": True,
    },
    "siliconflow": {
        "name": "硅基流动 SiliconFlow",
        "client_class": SiliconFlowClient,
        "default_base_url": "https://api.siliconflow.cn/v1",
        "default_model": "Qwen/Qwen2.5-72B-Instruct-AWQ",
        "models": ["Qwen/Qwen2.5-72B-Instruct-AWQ", "Qwen/Qwen2.5-7B-Instruct", "deepseek-ai/DeepSeek-V3", "deepseek-ai/DeepSeek-R1", "THUDM/glm-4-9b-chat"],
        "icon": "🟣",
        "description": "硅基流动聚合多模型平台",
        "api_key_placeholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxx",
        "models_endpoint": "/models",
        "supports_model_fetch": True,
    },
    "qwen": {
        "name": "通义千问 Qwen",
        "client_class": QwenClient,
        "default_base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "default_model": "qwen-turbo",
        "models": ["qwen-turbo", "qwen-plus", "qwen-max", "qwen-long"],
        "icon": "🟠",
        "description": "阿里云通义千问大模型",
        "api_key_placeholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxx",
        "models_endpoint": "/models",
        "supports_model_fetch": True,
    },
    "zhipu": {
        "name": "智谱AI ChatGLM",
        "client_class": ZhipuClient,
        "default_base_url": "https://open.bigmodel.cn/api/paas/v4",
        "default_model": "glm-4-flash",
        "models": ["glm-4-flash", "glm-4-air", "glm-4", "glm-4-plus"],
        "icon": "🔷",
        "description": "智谱AI GLM系列大模型",
        "api_key_placeholder": "xxxxxxxxxxxxxxxxxxxxxxxx.xxxxxxxx",
        "models_endpoint": "/models",
        "supports_model_fetch": True,
    },
    "kimi": {
        "name": "月之暗面 Kimi",
        "client_class": KimiClient,
        "default_base_url": "https://api.moonshot.cn/v1",
        "default_model": "moonshot-v1-8k",
        "models": ["moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-128k"],
        "icon": "🌙",
        "description": "月之暗面Kimi大模型",
        "api_key_placeholder": "sk-xxxxxxxxxxxxxxxxxxxxxxxx",
        "models_endpoint": "/models",
        "supports_model_fetch": True,
    },
    "claude": {
        "name": "Anthropic Claude",
        "client_class": ClaudeClient,
        "default_base_url": "https://api.anthropic.com/v1",
        "default_model": "claude-3-5-sonnet-20241022",
        "models": ["claude-3-5-sonnet-20241022", "claude-3-5-haiku-20241022", "claude-3-opus-20240229"],
        "icon": "🟤",
        "description": "Anthropic Claude系列大模型",
        "api_key_placeholder": "sk-ant-xxxxxxxxxxxxxxxxxxxxxxxx",
        "models_endpoint": None,
        "supports_model_fetch": False,
    },
}


# ============================================================================
# 工厂 & 会话
# ============================================================================

class AIAgentFactory:
    """AI客户端工厂"""

    @staticmethod
    def create_client(provider: str, config: Dict[str, Any]) -> BaseAIClient:
        """创建AI客户端"""
        provider_info = PROVIDER_REGISTRY.get(provider.lower())
        if provider_info:
            return provider_info['client_class'](config)

        # 未知提供商使用OpenAI兼容模式
        logger.warning("未知的AI提供商: %s, 尝试OpenAI兼容模式", provider)
        return OpenAICompatibleClient(config)


class AISession:
    """AI会话管理器 — 支持多轮对话历史"""

    def __init__(self, client: BaseAIClient, system_prompt: str = None, max_history: int = 10):
        self.client = client
        self.system_prompt = system_prompt
        self.conversation_history = []  # 完整对话历史
        self.max_history = max_history  # 最大保留轮次

    def chat(self, user_message: str) -> str:
        """进行聊天 — 传递对话历史给AI"""
        try:
            # LOGIC-03修复: 传递多轮对话历史
            # 为了兼容 BaseAIClient.chat(prompt, system_prompt) 的接口，
            # 我们把历史拼接成上下文prompt
            context_prompt = user_message
            if self.conversation_history:
                history_parts = []
                # 只保留最近N轮（防止token超限）
                recent = self.conversation_history[-self.max_history:]
                for h in recent:
                    history_parts.append(f"用户: {h['user']}")
                    history_parts.append(f"助手: {h['assistant'][:500]}")  # 截断助手回复
                history_text = '\n'.join(history_parts)
                context_prompt = f"之前的对话:\n{history_text}\n\n当前问题: {user_message}"

            response = self.client.chat(context_prompt, self.system_prompt)
            self.conversation_history.append({
                'user': user_message,
                'assistant': response
            })
            return response
        except Exception as e:
            logger.error("AI会话出错: %s", e)
            raise

    def get_history(self) -> list:
        """获取对话历史"""
        return self.conversation_history

    def clear_history(self):
        """清空对话历史"""
        self.conversation_history.clear()
