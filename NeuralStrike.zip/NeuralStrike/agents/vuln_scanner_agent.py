#!/usr/bin/env python3
"""
HexStrike Multi-Agent - 漏洞扫描Agent（SmartAgent升级版）
继承SmartAgent，具备AI推理和动态决策能力
"""

import asyncio
import json
import os
import re
import shlex
from typing import Dict, List, Optional
from datetime import datetime

# SSL验证 — 从环境变量读取，生产环境设 VERIFY_SSL=1
_VERIFY_SSL = os.environ.get('VERIFY_SSL', '0') == '1'

from .base_agent import BaseAgent, TaskResult, SmartAgent
from .utils import parse_url_target


class VulnScannerAgent(BaseAgent):
    """漏洞扫描Agent - 传统模式（兼容性保留）"""

    def get_system_prompt(self) -> str:
        return """你是一个专业的漏洞扫描专家，负责渗透测试的漏洞发现阶段。

你的职责包括：
1. 使用自动化工具进行漏洞扫描（Nuclei, OpenVAS等）
2. 识别已知CVE漏洞
3. 检测配置错误和安全风险
4. 验证漏洞并提供PoC
5. 评估漏洞风险等级

请使用最佳实践进行分析，并提供结构化的结果。"""

    async def execute(self, target: str, options: Dict = None) -> TaskResult:
        """执行漏洞扫描任务"""
        options = options or {}
        result = TaskResult(
            agent_name=self.name,
            task_type="vuln_scan",
            status="running",
            metadata={"target": target, "options": options}
        )

        self.logger.info(f"开始漏洞扫描: {target}")

        try:
            if not target.startswith(('http://', 'https://')):
                target_url = f"http://{target}"
            else:
                target_url = target

            vulnerabilities = {"critical": [], "high": [], "medium": [], "low": [], "info": []}

            if options.get("use_nuclei", True):
                nuclei_results = await self._scan_with_nuclei(target_url, options)
                for k, v in nuclei_results.items():
                    if k in vulnerabilities and v:
                        vulnerabilities[k].extend(v)

            if options.get("check_sensitive_files", True):
                sensitive_results = await self._check_sensitive_files(target_url)
                vulnerabilities["info"].extend(sensitive_results)

            if options.get("check_cve", True):
                cve_results = await self._check_cve(target_url)
                vulnerabilities["high"].extend(cve_results)

            if options.get("ai_analysis", True) and vulnerabilities:
                analysis = await self._ai_analysis(vulnerabilities)
                result.metadata["ai_analysis"] = analysis

            result.result = vulnerabilities
            result.findings = [
                {"severity": k, "count": len(v), "vulnerabilities": v[:5]}
                for k, v in vulnerabilities.items() if v
            ]
            result.status = "success"
            self.logger.info(f"漏洞扫描完成: {target}, 发现 {sum(len(v) for v in vulnerabilities.values())} 个漏洞")

        except Exception as e:
            result.status = "failed"
            result.add_error(str(e))
            self.logger.error(f"漏洞扫描失败: {e}")

        return result

    async def _scan_with_nuclei(self, target: str, options: Dict) -> Dict:
        """使用Nuclei进行扫描"""
        self.logger.info(f"Nuclei扫描: {target}")
        vulnerabilities = {"critical": [], "high": [], "medium": [], "low": [], "info": []}

        from .tool_manager import get_tool_manager
        tm = get_tool_manager()

        if tm.is_available('nuclei'):
            severity = options.get("severity", "critical,high,medium")
            nuclei_cmd = tm.get_run_command('nuclei')
            cmd_list = nuclei_cmd + ['-u', target, '-severity', severity, '-json', '-nc', '-silent']

            self.logger.info(f"Nuclei命令: {' '.join(cmd_list)}")

            # 使用asyncio而非BaseAgent.run_command (shell=True有注入风险)
            try:
                process = await asyncio.create_subprocess_exec(
                    *cmd_list,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(), timeout=600
                )
                result = {
                    "success": process.returncode == 0,
                    "stdout": stdout_bytes.decode(errors='replace'),
                    "stderr": stderr_bytes.decode(errors='replace'),
                    "returncode": process.returncode
                }
            except asyncio.TimeoutError:
                result = {"success": False, "stdout": "", "stderr": "Nuclei扫描超时(600s)", "returncode": -1}
            except Exception as e:
                result = {"success": False, "stdout": "", "stderr": str(e), "returncode": -1}

            if result["success"] and result["stdout"]:
                try:
                    for line in result["stdout"].strip().split('\n'):
                        if line.strip():
                            try:
                                vuln_data = json.loads(line)
                                sev = vuln_data.get("info", {}).get("severity", "info").lower()

                                if sev in vulnerabilities:
                                    vulnerabilities[sev].append({
                                        "name": vuln_data.get("info", {}).get("name", "Unknown"),
                                        "description": vuln_data.get("info", {}, {}).get("description", ""),
                                        "matched_at": vuln_data.get("matched-at", ""),
                                        "cve_id": vuln_data.get("info", {}).get("cve_id", ""),
                                        "CVSS_score": vuln_data.get("info", {}).get("cvss-score", ""),
                                    })
                            except json.JSONDecodeError:
                                continue
                except Exception as e:
                    self.logger.error(f"Nuclei输出解析失败: {e}")
        else:
            basic_vulns = await self._basic_vuln_scan(target)
            vulnerabilities["medium"].extend(basic_vulns)

        return vulnerabilities

    async def _basic_vuln_scan(self, target: str) -> List[Dict]:
        """基础漏洞扫描"""
        vulns = []
        common_vulns = [
            {"path": "/phpinfo.php", "name": "PHPInfo信息泄露", "severity": "info"},
            {"path": "/.git/config", "name": "Git配置泄露", "severity": "high"},
            {"path": "/.env", "name": "环境变量泄露", "severity": "critical"},
            {"path": "/wp-config.php", "name": "WordPress配置泄露", "severity": "critical"},
            {"path": "/admin", "name": "管理后台发现", "severity": "info"},
            {"path": "/backup", "name": "备份文件泄露", "severity": "high"},
            {"path": "/.DS_Store", "name": "MacOS文件泄露", "severity": "low"},
            {"path": "/server-status", "name": "Apache状态页", "severity": "medium"},
        ]

        import requests
        for vuln in common_vulns:
            try:
                url = target.rstrip('/') + vuln["path"]
                resp = requests.get(url, timeout=5, verify=_VERIFY_SSL)
                if resp.status_code == 200 and len(resp.text) > 0:
                    vulns.append({
                        "name": vuln["name"], "path": vuln["path"],
                        "url": url, "found": True
                    })
            except Exception:
                pass

        return vulns

    async def _check_sensitive_files(self, target: str) -> List[Dict]:
        return await self._basic_vuln_scan(target)

    async def _check_cve(self, target: str) -> List[Dict]:
        cves = []
        import requests
        try:
            resp = requests.get(target, timeout=10, verify=_VERIFY_SSL)
            server = resp.headers.get("Server", "")
            if "Apache/2.4" in server:
                cves.append({"cve_id": "CVE-2021-41773", "name": "Apache路径遍历漏洞", "severity": "critical", "confidence": "medium"})
            if "nginx" in server.lower():
                cves.append({"cve_id": "CVE-2021-23017", "name": "Nginx解析漏洞", "severity": "high", "confidence": "low"})
        except Exception as e:
            self.logger.debug(f"CVE检测失败: {e}")
        return cves

    async def _ai_analysis(self, vulnerabilities: Dict) -> str:
        summary = json.dumps(vulnerabilities, ensure_ascii=False, indent=2)
        prompt = f"""请分析以下漏洞扫描结果，提供：
1. 风险评估总结
2. 优先修复建议
3. 进一步利用建议

漏洞数据:
{summary[:3000]}"""
        return self.ask_ai(prompt)


class SmartVulnScannerAgent(SmartAgent):
    """智能漏洞扫描Agent - AI驱动动态决策

    与传统VulnScannerAgent的区别：
    1. AI制定扫描策略（而非硬编码顺序）
    2. 扫描结果AI自动评估
    3. 能够根据前置Agent的上下文调整策略
    4. 工具失败时AI自动选择降级方案
    """

    display_name = "漏洞扫描"

    ACTION_ALIASES = {
        "nuclei_scan": "nuclei_scan",
        "nuclei": "nuclei_scan",
        "vulnerability_scan": "nuclei_scan",
        "vuln_scan": "nuclei_scan",
        "vulnscan": "nuclei_scan",
        "basic_vuln_scan": "basic_vuln_scan",
        "basic_scan": "basic_vuln_scan",
        "sensitive_file_check": "sensitive_file_check",
        "sensitive_files": "sensitive_file_check",
        "info_leak_check": "sensitive_file_check",
        "cve_detection": "cve_detection",
        "cve_scan": "cve_detection",
        "cve_check": "cve_detection",
        "ssl_scan": "ssl_scan",
        "ssl_check": "ssl_scan",
        "tls_scan": "ssl_scan",
    }

    def get_system_prompt(self) -> str:
        return """你是一个专业的漏洞扫描专家，负责渗透测试的漏洞发现阶段。

你的职责包括：
1. 根据目标特征和信息收集结果，选择最优的扫描策略
2. 使用自动化工具进行漏洞扫描（Nuclei等）
3. 识别已知CVE漏洞和配置错误
4. 验证漏洞并提供PoC
5. 评估漏洞风险等级和可利用性
6. 根据扫描结果决定下一步行动

原则：
- 优先扫描高风险服务
- 工具不可用时及时降级
- 发现重大漏洞时立即通知
- 避免无效的重复扫描"""

    def define_capabilities(self) -> Dict:
        return {
            "nuclei_scan": {
                "tools": ["nuclei"],
                "types": ["cve", "misconfig", "exposure", "vulnerability"],
                "speed": "medium",
                "accuracy": "high",
                "coverage": "comprehensive"
            },
            "basic_vuln_scan": {
                "tools": ["python_requests"],
                "types": ["exposure", "misconfig"],
                "speed": "fast",
                "accuracy": "medium",
                "coverage": "basic"
            },
            "cve_detection": {
                "tools": ["nuclei", "python_requests"],
                "types": ["cve"],
                "speed": "medium",
                "accuracy": "medium",
                "note": "基于版本检测"
            },
            "sensitive_file_check": {
                "tools": ["python_requests"],
                "types": ["exposure", "info_leak"],
                "speed": "fast",
                "accuracy": "high",
                "coverage": "common_paths"
            },
            "ssl_scan": {
                "tools": ["sslyze", "testssl", "nuclei"],
                "types": ["ssl", "tls"],
                "speed": "medium",
                "accuracy": "high"
            }
        }

    def _analyze_situation(self, target: str, context: Dict) -> Dict:
        """分析当前情况"""
        # 从上下文获取前置Agent的发现
        findings = context.get('findings', [])
        services = context.get('services', {})
        technologies = context.get('technologies', [])

        # 提取已知信息
        known_ports = []
        known_services = []
        known_vulns = []

        for finding in findings:
            if isinstance(finding, dict):
                if 'port' in finding:
                    known_ports.append(finding['port'])
                if 'service' in finding:
                    known_services.append(finding['service'])
                if finding.get('severity') in ('critical', 'high', 'medium'):
                    known_vulns.append(finding)

        for port, service in services.items():
            known_ports.append(port)
            if isinstance(service, dict):
                known_services.append(service.get('service', ''))

        return {
            "target": target,
            "target_type": self._detect_target_type(target),
            "known_ports": known_ports,
            "known_services": known_services,
            "known_vulnerabilities": known_vulns,
            "technologies": [str(t) for t in technologies[:10]],
            "time_budget": context.get('time_budget', 600),
            "stealth_mode": context.get('stealth_mode', False),
            "available_tools": self._check_available_tools(),
            "previous_findings": findings[-10:]
        }

    def _detect_target_type(self, target: str) -> str:
        """检测目标类型"""
        if target.startswith('http://') or target.startswith('https://'):
            return "web_application"
        import re
        if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', target):
            return "ip_address"
        return "domain"

    def _check_available_tools(self) -> Dict:
        """检查可用工具（使用ToolManager统一管理）"""
        from .tool_manager import get_tool_manager
        tm = get_tool_manager()
        tools = {}
        for tool in ['nuclei', 'sslyze', 'nmap', 'sqlmap']:
            tools[tool] = tm.is_available(tool)
        return tools

    async def _execute_plan(self, plan: Dict, target: str) -> List:
        """执行AI制定的漏洞扫描计划"""
        results = []

        for step in plan.get('steps', []):
            raw_action = step['action']
            params = step.get('params', {})
            # 使用别名解析
            action = self._resolve_action_name(raw_action)
            if action != raw_action:
                self.logger.info(f"[VulnScanner] 动作别名解析: {raw_action} → {action}")

            self.logger.info(f"[VulnScanner] 执行: {action} - 原因: {step.get('reason', '无')}")

            # 🧠 发送思考
            self._emit_thinking("action",
                "⚡ 执行: {} | 参数: {} | 原因: {}".format(
                    action,
                    json.dumps(params, ensure_ascii=False) if params else '默认',
                    step.get('reason', '编排器指定')
                ))

            # 动态调用方法
            if hasattr(self, f'_do_{action}'):
                method = getattr(self, f'_do_{action}')
                try:
                    if asyncio.iscoroutinefunction(method):
                        result = await method(target, params)
                    else:
                        result = method(target, params)
                    results.append({
                        'action': action,
                        'result': result,
                        'success': result.get('success', False) if isinstance(result, dict) else True
                    })
                except Exception as e:
                    self.logger.error(f"[VulnScanner] 执行 {action} 失败: {e}")
                    results.append({
                        'action': action,
                        'result': {'success': False, 'error': str(e)},
                        'success': False
                    })
            else:
                self.logger.warning(f"[VulnScanner] 未知动作: {action}, 降级到基础漏洞扫描")
                result = await self._do_basic_vuln_scan(target, params)
                results.append({
                    'action': action,
                    'result': result,
                    'success': result.get('success', False)
                })

        return results

    # ==========================================================================
    # 扫描动作实现
    # ==========================================================================

    async def _do_nuclei_scan(self, target: str, params: Dict) -> Dict:
        """Nuclei漏洞扫描（通过ToolManager定位可执行文件）"""
        if not target.startswith(('http://', 'https://')):
            target = f"http://{target}"

        from .tool_manager import get_tool_manager
        tm = get_tool_manager()

        if not tm.is_available('nuclei'):
            # nuclei不可用，降级到基础漏洞扫描
            self.logger.warning("nuclei不可用，降级到基础漏洞扫描")
            return await self._do_basic_vuln_scan(target, params)

        severity = params.get('severity', 'critical,high,medium')
        templates = params.get('templates', '')

        nuclei_cmd = tm.get_run_command('nuclei')
        try:
            cmd = nuclei_cmd + ['-u', target, '-severity', severity, '-json', '-nc', '-silent']
            if templates:
                cmd.extend(['-t', templates])

            self.logger.info(f"[VulnScanner] nuclei命令: {' '.join(cmd)}")

            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(
                process.communicate(), timeout=params.get('timeout', 600)
            )

            vulnerabilities = {"critical": [], "high": [], "medium": [], "low": [], "info": []}

            if process.returncode == 0 and stdout:
                for line in stdout.decode().strip().split('\n'):
                    if line.strip():
                        try:
                            vuln_data = json.loads(line)
                            sev = vuln_data.get("info", {}).get("severity", "info").lower()
                            if sev in vulnerabilities:
                                vulnerabilities[sev].append({
                                    "name": vuln_data.get("info", {}).get("name", "Unknown"),
                                    "description": vuln_data.get("info", {}, {}).get("description", ""),
                                    "matched_at": vuln_data.get("matched-at", ""),
                                    "cve_id": vuln_data.get("info", {}).get("cve_id", ""),
                                    "severity": sev,
                                })
                        except json.JSONDecodeError:
                            continue

                return {
                    'success': True, 'tool': 'nuclei',
                    'vulnerabilities': vulnerabilities,
                    'total': sum(len(v) for v in vulnerabilities.values())
                }
            else:
                return {'success': False, 'tool': 'nuclei', 'error': stderr.decode() if stderr else 'Unknown error'}
        except asyncio.TimeoutError:
            return {'success': False, 'tool': 'nuclei', 'error': '扫描超时(600s)'}
        except Exception as e:
            return {'success': False, 'tool': 'nuclei', 'error': str(e)}

    async def _do_basic_vuln_scan(self, target: str, params: Dict) -> Dict:
        """基础漏洞扫描（降级方案）"""
        if not target.startswith(('http://', 'https://')):
            target = f"http://{target}"

        import requests
        vulns = []
        common_vulns = [
            {"path": "/phpinfo.php", "name": "PHPInfo信息泄露", "severity": "info"},
            {"path": "/.git/config", "name": "Git配置泄露", "severity": "high"},
            {"path": "/.git/HEAD", "name": "Git HEAD泄露", "severity": "high"},
            {"path": "/.env", "name": "环境变量泄露", "severity": "critical"},
            {"path": "/.env.bak", "name": "环境变量备份泄露", "severity": "critical"},
            {"path": "/wp-config.php", "name": "WordPress配置泄露", "severity": "critical"},
            {"path": "/admin", "name": "管理后台发现", "severity": "info"},
            {"path": "/admin/login", "name": "管理员登录页面", "severity": "medium"},
            {"path": "/backup", "name": "备份文件泄露", "severity": "high"},
            {"path": "/backup.zip", "name": "备份压缩包", "severity": "critical"},
            {"path": "/backup.sql", "name": "数据库备份", "severity": "critical"},
            {"path": "/database.sql", "name": "数据库导出", "severity": "critical"},
            {"path": "/.DS_Store", "name": "MacOS文件泄露", "severity": "low"},
            {"path": "/server-status", "name": "Apache状态页", "severity": "medium"},
            {"path": "/server-info", "name": "Apache信息页", "severity": "medium"},
            {"path": "/.svn/entries", "name": "SVN信息泄露", "severity": "high"},
            {"path": "/crossdomain.xml", "name": "跨域策略文件", "severity": "low"},
            {"path": "/sitemap.xml", "name": "站点地图发现", "severity": "info"},
            {"path": "/swagger-ui.html", "name": "Swagger API文档", "severity": "medium"},
            {"path": "/swagger-ui/", "name": "Swagger API文档(v2)", "severity": "medium"},
            {"path": "/api-docs", "name": "API文档泄露", "severity": "medium"},
            {"path": "/actuator", "name": "Spring Actuator", "severity": "high"},
            {"path": "/actuator/env", "name": "Spring环境变量", "severity": "critical"},
            {"path": "/actuator/health", "name": "Spring健康检查", "severity": "info"},
            {"path": "/actuator/heapdump", "name": "Spring堆转储", "severity": "critical"},
            {"path": "/actuator/configprops", "name": "Spring配置属性", "severity": "high"},
            {"path": "/.well-known/security.txt", "name": "安全策略文件", "severity": "info"},
            {"path": "/robots.txt", "name": "Robots文件", "severity": "info"},
            {"path": "/WEB-INF/web.xml", "name": "Java Web配置", "severity": "high"},
            {"path": "/web.config", "name": "IIS配置文件", "severity": "high"},
            {"path": "/config.json", "name": "JSON配置文件", "severity": "high"},
            {"path": "/config.yml", "name": "YAML配置文件", "severity": "high"},
            {"path": "/debug", "name": "调试页面", "severity": "medium"},
            {"path": "/trace", "name": "请求追踪", "severity": "medium"},
            {"path": "/console", "name": "管理控制台", "severity": "high"},
            {"path": "/shell", "name": "Web Shell路径", "severity": "critical"},
            {"path": "/phpmyadmin/", "name": "phpMyAdmin", "severity": "medium"},
            {"path": "/manager/html", "name": "Tomcat管理器", "severity": "high"},
        ]

        for vuln in common_vulns:
            try:
                url = target.rstrip('/') + vuln["path"]
                resp = requests.get(url, timeout=5, verify=_VERIFY_SSL)
                if resp.status_code == 200 and len(resp.text) > 0:
                    vulns.append({
                        "name": vuln["name"], "path": vuln["path"],
                        "url": url, "found": True, "severity": vuln["severity"],
                        "type": "sensitive_file" if "泄露" in vuln["name"] or "发现" in vuln["name"] else "misconfig"
                    })
            except Exception:
                pass

        return {
            'success': True, 'tool': 'python_requests',
            'vulnerabilities': vulns, 'total': len(vulns)
        }

    async def _do_cve_detection(self, target: str, params: Dict) -> Dict:
        """CVE检测 — 本地规则库+在线NVD API查询"""
        if not target.startswith(('http://', 'https://')):
            target = f"http://{target}"

        import requests as _requests
        cves = []
        try:
            resp = _requests.get(target, timeout=10, verify=_VERIFY_SSL)
            server = resp.headers.get("Server", "")
            powered = resp.headers.get("X-Powered-By", "")
            html = resp.text

            # ===== 本地CVE规则库 — 覆盖常见服务 =====
            cve_rules = [
                # Apache
                {"match": "Apache/2.4.49", "cve": "CVE-2021-41773", "name": "Apache路径遍历", "severity": "critical"},
                {"match": "Apache/2.4.50", "cve": "CVE-2021-42013", "name": "Apache路径遍历(RCE)", "severity": "critical"},
                {"match": "Apache/2.4", "cve": "CVE-2021-41773", "name": "Apache路径遍历(可能)", "severity": "high", "confidence": "medium"},
                {"match": "Apache/2.2", "cve": "CVE-2017-7679", "name": "Apache HTTP DoS", "severity": "medium"},
                {"match": "Apache/2.2.34", "cve": "CVE-2017-9798", "name": "Apache Optionbleed", "severity": "medium"},
                # Nginx
                {"match": "nginx/", "cve": "CVE-2021-23017", "name": "Nginx DNS解析漏洞", "severity": "high"},
                {"match": "nginx/1.", "cve": "CVE-2019-20372", "name": "Nginx请求走私", "severity": "medium"},
                # PHP
                {"match": "PHP/", "cve": "CVE-2019-11043", "name": "PHP-FPM RCE", "severity": "critical"},
                {"match": "PHP/7.", "cve": "CVE-2019-11043", "name": "PHP-FPM RCE(可能)", "severity": "high", "confidence": "medium"},
                {"match": "PHP/5.", "cve": "CVE-2014-6271", "name": "PHP旧版本漏洞", "severity": "high"},
                # IIS
                {"match": "Microsoft-IIS/6.0", "cve": "CVE-2017-7269", "name": "IIS 6.0 WebDAV缓冲区溢出", "severity": "critical"},
                {"match": "Microsoft-IIS/7.", "cve": "CVE-2015-1635", "name": "IIS HTTP.sys远程代码执行", "severity": "critical"},
                {"match": "Microsoft-IIS/", "cve": "CVE-2009-1535", "name": "IIS认证绕过", "severity": "medium"},
                # OpenSSH
                {"match": "OpenSSH_7.2", "cve": "CVE-2016-0777", "name": "OpenSSH信息泄露", "severity": "medium"},
                {"match": "OpenSSH_7.5", "cve": "CVE-2016-10708", "name": "OpenSSH用户枚举", "severity": "medium"},
                {"match": "OpenSSH_8.", "cve": "CVE-2019-16905", "name": "OpenSSH权限提升", "severity": "high"},
                # Tomcat
                {"match": "Apache-Coyote", "cve": "CVE-2020-1938", "name": "Tomcat AJP文件读取", "severity": "critical"},
                {"match": "Apache Tomcat", "cve": "CVE-2019-0232", "name": "Tomcat CGI RCE", "severity": "critical"},
                # Spring
                {"match": "spring", "cve": "CVE-2022-22965", "name": "Spring4Shell RCE", "severity": "critical"},
                # WordPress
                {"match": "WordPress", "cve": "CVE-2019-9978", "name": "WordPress XSS", "severity": "medium"},
                # Redis
                {"match": "Redis", "cve": "CVE-2022-0543", "name": "Redis Lua沙箱逃逸", "severity": "critical"},
                # OpenSSL
                {"match": "OpenSSL/1.0.1", "cve": "CVE-2014-0160", "name": "Heartbleed", "severity": "critical"},
                {"match": "OpenSSL/1.0.2", "cve": "CVE-2016-0800", "name": "DROWN攻击", "severity": "high"},
            ]

            # 提取版本信息
            headers_text = f"{server} {powered}".lower()
            body_techs = re.findall(r'(?i)(wordpress|joomla|drupal|django|flask|laravel|rails|express)', html)

            for rule in cve_rules:
                if rule["match"].lower() in headers_text or rule["match"].lower() in ' '.join(body_techs).lower():
                    cve_entry = {
                        "cve_id": rule["cve"],
                        "name": rule["name"],
                        "severity": rule["severity"],
                        "confidence": rule.get("confidence", "low"),
                        "matched_by": rule["match"]
                    }
                    cves.append(cve_entry)

            # ===== 在线NVD API查询 — 提取版本号精确查询 =====
            version_patterns = [
                (r'Apache/([\d.]+)', 'apache_http_server'),
                (r'nginx/([\d.]+)', 'nginx'),
                (r'PHP/([\d.]+)', 'php'),
                (r'OpenSSH_([\d.p]+)', 'openssh'),
                (r'OpenSSL/([\d.a-z]+)', 'openssl'),
                (r'Microsoft-IIS/([\d.]+)', 'iis'),
            ]
            for pattern, keyword in version_patterns:
                match = re.search(pattern, headers_text, re.IGNORECASE)
                if match:
                    version = match.group(1)
                    try:
                        nvd_url = f"https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch={keyword}%20{version}&resultsPerPage=5"
                        nvd_resp = _requests.get(nvd_url, timeout=10, verify=False)
                        if nvd_resp.status_code == 200:
                            nvd_data = nvd_resp.json()
                            for vuln in nvd_data.get('vulnerabilities', [])[:3]:
                                cve_id = vuln.get('cve', {}).get('id', '')
                                descriptions = vuln.get('cve', {}).get('descriptions', [])
                                desc = next((d['value'] for d in descriptions if d['lang'] == 'en'), '')
                                # 检查是否已在本地规则中
                                if not any(c['cve_id'] == cve_id for c in cves):
                                    cves.append({
                                        "cve_id": cve_id,
                                        "name": desc[:100] if desc else cve_id,
                                        "severity": "high",
                                        "confidence": "medium",
                                        "source": "NVD_API",
                                        "matched_by": f"{keyword} {version}"
                                    })
                    except Exception:
                        pass

        except Exception as e:
            self.logger.debug(f"CVE检测失败: {e}")

        return {'success': True, 'tool': 'cve_detection', 'cves': cves, 'total': len(cves)}

    async def _do_sensitive_file_check(self, target: str, params: Dict) -> Dict:
        """敏感文件检查"""
        return await self._do_basic_vuln_scan(target, params)

    async def _do_ssl_scan(self, target: str, params: Dict) -> Dict:
        """SSL/TLS扫描"""
        # 🔧 从URL中提取hostname
        parsed = parse_url_target(target)
        hostname = parsed['host_for_nmap']

        # 如果不是https且端口不是443，检查是否仍可扫描
        if parsed['scheme'] != 'https' and parsed['port'] != 443:
            return {'success': False, 'error': '目标不是HTTPS，SSL扫描跳过'}

        import ssl
        import socket
        issues = []

        try:
            context = ssl.create_default_context()
            with socket.create_connection((hostname, 443), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    protocol = ssock.version()
                    cipher = ssock.cipher()
                    cert = ssock.getpeercert()

                    # 检查协议版本
                    if protocol in ('TLSv1', 'TLSv1.1', 'SSLv3'):
                        issues.append({
                            'name': f'弱TLS协议: {protocol}',
                            'severity': 'high'
                        })

                    # 检查证书过期
                    if cert:
                        import datetime as dt
                        expiry = dt.datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
                        if expiry < dt.datetime.now():
                            issues.append({'name': '证书已过期', 'severity': 'high'})

        except Exception as e:
            return {'success': False, 'error': str(e)}

        return {'success': True, 'tool': 'ssl_scan', 'issues': issues, 'total': len(issues)}


if __name__ == "__main__":
    print("漏洞扫描Agent模块已加载（含SmartAgent升级版）")
