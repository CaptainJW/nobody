# agents/knowledge_graph.py
# 渗透测试知识图谱 - Agent根据图谱推理下一步行动
import logging
from typing import Dict, List, Any

logger = logging.getLogger(__name__)


class PentestKnowledgeGraph:
    """渗透测试知识图谱
    
    根据当前发现推荐下一步动作，用于：
    1. AI不可用时的降级决策
    2. 加速AI决策（提供先验知识）
    3. 验证AI决策的合理性
    """

    def __init__(self):
        self.nodes = self._build_nodes()
        self.edges = self._build_edges()

    def _build_nodes(self) -> Dict[str, Dict]:
        """构建知识图谱节点"""
        return {
            # ========== 端口/服务发现 ==========
            "open_port_80": {
                "type": "finding",
                "category": "port",
                "description": "HTTP服务端口开放",
                "implies": ["web_service", "http_protocol"],
                "next_actions": ["web_fingerprint", "directory_scan", "vulnerability_scan", "sqli_test", "xss_test"],
                "severity": "info"
            },
            "open_port_443": {
                "type": "finding",
                "category": "port",
                "description": "HTTPS服务端口开放",
                "implies": ["web_service", "https_protocol", "tls_service"],
                "next_actions": ["web_fingerprint", "ssl_scan", "directory_scan", "vulnerability_scan"],
                "severity": "info"
            },
            "open_port_22": {
                "type": "finding",
                "category": "port",
                "description": "SSH服务端口开放",
                "implies": ["ssh_service"],
                "next_actions": ["ssh_banner_grab", "ssh_auth_test", "ssh_vuln_scan", "brute_force_ssh"],
                "severity": "info"
            },
            "open_port_21": {
                "type": "finding",
                "category": "port",
                "description": "FTP服务端口开放",
                "implies": ["ftp_service"],
                "next_actions": ["ftp_banner_grab", "ftp_anonymous_test", "ftp_vuln_scan"],
                "severity": "low"
            },
            "open_port_3306": {
                "type": "finding",
                "category": "port",
                "description": "MySQL数据库端口开放",
                "implies": ["mysql_service", "database"],
                "next_actions": ["mysql_auth_test", "mysql_vuln_scan", "brute_force_mysql"],
                "severity": "medium"
            },
            "open_port_6379": {
                "type": "finding",
                "category": "port",
                "description": "Redis数据库端口开放",
                "implies": ["redis_service", "database", "nosql"],
                "next_actions": ["redis_unauth_test", "redis_vuln_scan"],
                "severity": "medium"
            },
            "open_port_27017": {
                "type": "finding",
                "category": "port",
                "description": "MongoDB数据库端口开放",
                "implies": ["mongodb_service", "database", "nosql"],
                "next_actions": ["mongodb_unauth_test", "mongodb_vuln_scan"],
                "severity": "medium"
            },
            "open_port_3389": {
                "type": "finding",
                "category": "port",
                "description": "RDP远程桌面端口开放",
                "implies": ["rdp_service", "windows"],
                "next_actions": ["rdp_banner_grab", "brute_force_rdp", "rdp_vuln_scan"],
                "severity": "medium"
            },
            "open_port_8080": {
                "type": "finding",
                "category": "port",
                "description": "HTTP代理/备用Web端口",
                "implies": ["web_service", "http_proxy", "tomcat", "jenkins"],
                "next_actions": ["web_fingerprint", "directory_scan", "vulnerability_scan"],
                "severity": "info"
            },
            "open_port_8443": {
                "type": "finding",
                "category": "port",
                "description": "HTTPS备用端口",
                "implies": ["web_service", "https_alt"],
                "next_actions": ["web_fingerprint", "ssl_scan", "vulnerability_scan"],
                "severity": "info"
            },

            # ========== 技术栈识别 ==========
            "wordpress_detected": {
                "type": "technology",
                "category": "cms",
                "description": "WordPress内容管理系统",
                "implies": ["php", "mysql", "cms"],
                "next_actions": ["wpscan", "plugin_enum", "theme_enum", "user_enum", "wp_config_check"],
                "severity": "info"
            },
            "apache_detected": {
                "type": "technology",
                "category": "web_server",
                "description": "Apache Web服务器",
                "implies": ["htaccess", "mod_rewrite"],
                "next_actions": ["apache_vuln_scan", "server_status_check", "server_info_check"],
                "severity": "info"
            },
            "nginx_detected": {
                "type": "technology",
                "category": "web_server",
                "description": "Nginx Web服务器",
                "implies": ["reverse_proxy"],
                "next_actions": ["nginx_vuln_scan", "nginx_misconfig_check"],
                "severity": "info"
            },
            "iis_detected": {
                "type": "technology",
                "category": "web_server",
                "description": "IIS Web服务器",
                "implies": ["asp_net", "windows"],
                "next_actions": ["iis_vuln_scan", "asp_error_test", "web_config_check"],
                "severity": "info"
            },
            "php_detected": {
                "type": "technology",
                "category": "language",
                "description": "PHP后端语言",
                "implies": ["lfi_possible", "rfi_possible"],
                "next_actions": ["phpinfo_check", "lfi_test", "rfi_test"],
                "severity": "info"
            },
            "asp_net_detected": {
                "type": "technology",
                "category": "language",
                "description": "ASP.NET后端框架",
                "implies": ["windows", "iis"],
                "next_actions": ["ViewState_decode", "path_traversal_test", "web_config_check"],
                "severity": "info"
            },
            "nodejs_detected": {
                "type": "technology",
                "category": "language",
                "description": "Node.js后端环境",
                "implies": ["javascript", "express_possible"],
                "next_actions": ["nodejs_vuln_scan", "prototype_pollution_test", "ssrf_test"],
                "severity": "info"
            },
            "spring_detected": {
                "type": "technology",
                "category": "framework",
                "description": "Spring框架",
                "implies": ["java", "tomcat"],
                "next_actions": ["spring_actuator_check", "spring_env_check", "spel_injection_test"],
                "severity": "info"
            },

            # ========== 漏洞发现 ==========
            "sql_injection_found": {
                "type": "vulnerability",
                "category": "injection",
                "description": "SQL注入漏洞",
                "severity": "critical",
                "implies": ["database_accessible", "data_exfiltration"],
                "next_actions": ["sqlmap_exploit", "database_enum", "data_extraction", "os_shell_test"],
                "severity_boost": 10
            },
            "xss_found": {
                "type": "vulnerability",
                "category": "injection",
                "description": "跨站脚本漏洞",
                "severity": "high",
                "implies": ["client_side_attack", "session_hijack"],
                "next_actions": ["xss_verify", "cookie_steal_test", "csrf_test"],
                "severity_boost": 7
            },
            "lfi_found": {
                "type": "vulnerability",
                "category": "file_inclusion",
                "description": "本地文件包含漏洞",
                "severity": "high",
                "implies": ["file_read", "source_code_access"],
                "next_actions": ["lfi_exploit", "log_poisoning", "wrapper_exploit"],
                "severity_boost": 7
            },
            "rfi_found": {
                "type": "vulnerability",
                "category": "file_inclusion",
                "description": "远程文件包含漏洞",
                "severity": "critical",
                "implies": ["rce_possible", "shell_upload"],
                "next_actions": ["rfi_exploit", "webshell_upload", "rce_verify"],
                "severity_boost": 10
            },
            "ssrf_found": {
                "type": "vulnerability",
                "category": "request_forgery",
                "description": "服务端请求伪造漏洞",
                "severity": "high",
                "implies": ["internal_access", "cloud_metadata"],
                "next_actions": ["ssrf_exploit", "internal_scan", "metadata_extract"],
                "severity_boost": 8
            },
            "rce_found": {
                "type": "vulnerability",
                "category": "execution",
                "description": "远程代码执行漏洞",
                "severity": "critical",
                "implies": ["full_compromise", "system_access"],
                "next_actions": ["rce_stable_shell", "privilege_escalation", "persistence_setup", "lateral_movement"],
                "severity_boost": 10
            },
            "xxe_found": {
                "type": "vulnerability",
                "category": "injection",
                "description": "XML外部实体注入",
                "severity": "high",
                "implies": ["file_read", "ssrf_possible"],
                "next_actions": ["xxe_exploit", "file_extraction", "ssrf_via_xxe"],
                "severity_boost": 8
            },
            "file_upload_found": {
                "type": "vulnerability",
                "category": "upload",
                "description": "不安全的文件上传",
                "severity": "high",
                "implies": ["webshell_upload", "rce_possible"],
                "next_actions": ["upload_webshell", "bypass_filter", "rce_verify"],
                "severity_boost": 8
            },
            "csrf_found": {
                "type": "vulnerability",
                "category": "request_forgery",
                "description": "跨站请求伪造",
                "severity": "medium",
                "implies": ["state_changing_action"],
                "next_actions": ["csrf_poc_generate", "csrf_verify"],
                "severity_boost": 5
            },
            "info_disclosure_found": {
                "type": "vulnerability",
                "category": "disclosure",
                "description": "信息泄露",
                "severity": "medium",
                "implies": ["sensitive_data_exposed"],
                "next_actions": ["data_extraction", "credential_analysis", "deep_scan"],
                "severity_boost": 4
            },
            "unauth_access_found": {
                "type": "vulnerability",
                "category": "auth",
                "description": "未授权访问",
                "severity": "high",
                "implies": ["data_breach", "privilege_escalation"],
                "next_actions": ["access_verify", "data_extraction", "admin_function_test"],
                "severity_boost": 8
            },
            "weak_credential_found": {
                "type": "vulnerability",
                "category": "auth",
                "description": "弱口令/默认凭据",
                "severity": "critical",
                "implies": ["unauthorized_access", "system_compromise"],
                "next_actions": ["credential_verify", "privilege_escalation", "lateral_movement"],
                "severity_boost": 9
            },

            # ========== 配置发现 ==========
            "git_exposure": {
                "type": "finding",
                "category": "misconfig",
                "description": "Git仓库泄露",
                "severity": "high",
                "implies": ["source_code_access"],
                "next_actions": ["git_dump", "source_code_analysis", "hardcoded_secret_search"],
                "severity_boost": 8
            },
            "env_exposure": {
                "type": "finding",
                "category": "misconfig",
                "description": "环境变量文件泄露",
                "severity": "critical",
                "implies": ["credential_leak", "config_access"],
                "next_actions": ["credential_extract", "database_connect", "api_key_verify"],
                "severity_boost": 10
            },
            "debug_mode": {
                "type": "finding",
                "category": "misconfig",
                "description": "调试模式开启",
                "severity": "medium",
                "implies": ["sensitive_info_exposed", "error_detail"],
                "next_actions": ["error_analysis", "source_code_extract", "config_extract"],
                "severity_boost": 5
            },
            "cors_misconfig": {
                "type": "finding",
                "category": "misconfig",
                "description": "CORS配置错误",
                "severity": "medium",
                "implies": ["cross_origin_access"],
                "next_actions": ["cors_exploit", "data_steal_test"],
                "severity_boost": 5
            },
            "directory_listing": {
                "type": "finding",
                "category": "misconfig",
                "description": "目录列表开启",
                "severity": "low",
                "implies": ["file_discovery"],
                "next_actions": ["sensitive_file_search", "backup_file_download"],
                "severity_boost": 3
            }
        }

    def _build_edges(self) -> List[Dict]:
        """构建知识图谱边（关系）"""
        return [
            # 端口 → 服务
            {"source": "open_port_80", "target": "web_service", "relation": "indicates"},
            {"source": "open_port_443", "target": "web_service", "relation": "indicates"},
            {"source": "open_port_3306", "target": "mysql_service", "relation": "indicates"},
            {"source": "open_port_6379", "target": "redis_service", "relation": "indicates"},
            # 服务 → 推荐动作
            {"source": "web_service", "target": "web_fingerprint", "relation": "requires"},
            {"source": "web_service", "target": "vulnerability_scan", "relation": "suggests"},
            {"source": "ssh_service", "target": "ssh_auth_test", "relation": "suggests"},
            # 技术栈 → 推荐动作
            {"source": "wordpress_detected", "target": "wpscan", "relation": "suggests"},
            {"source": "wordpress_detected", "target": "plugin_enum", "relation": "suggests"},
            # 漏洞 → 利用
            {"source": "sql_injection_found", "target": "sqlmap_exploit", "relation": "enables"},
            {"source": "rce_found", "target": "privilege_escalation", "relation": "enables"},
            {"source": "file_upload_found", "target": "webshell_upload", "relation": "enables"},
            {"source": "weak_credential_found", "target": "lateral_movement", "relation": "enables"},
            # 漏洞 → 进一步利用
            {"source": "lfi_found", "target": "log_poisoning", "relation": "enables"},
            {"source": "ssrf_found", "target": "internal_scan", "relation": "enables"},
            {"source": "xxe_found", "target": "file_extraction", "relation": "enables"},
            # 配置问题 → 后果
            {"source": "git_exposure", "target": "source_code_access", "relation": "enables"},
            {"source": "env_exposure", "target": "credential_leak", "relation": "enables"},
        ]

    def get_next_actions(self, current_findings: List[Dict]) -> List[Dict]:
        """根据当前发现推荐下一步动作

        Args:
            current_findings: 当前发现列表，每个发现是包含type/key字段的字典

        Returns:
            推荐动作列表，按优先级排序
        """
        recommended_actions = []

        for finding in current_findings:
            finding_type = self._classify_finding(finding)

            if finding_type in self.nodes:
                node = self.nodes[finding_type]
                actions = node.get('next_actions', [])

                for action in actions:
                    recommended_actions.append({
                        'action': action,
                        'reason': f"因为发现了 {finding_type}: {node.get('description', '')}",
                        'priority': self._calculate_priority(finding, action),
                        'source_finding': finding_type,
                        'category': node.get('category', 'unknown')
                    })

        # 去重和排序
        return self._deduplicate_and_sort(recommended_actions)

    def get_implied_findings(self, finding_key: str) -> List[str]:
        """获取某个发现所暗示的其他发现

        Args:
            finding_key: 发现的键名

        Returns:
            暗示的发现列表
        """
        node = self.nodes.get(finding_key, {})
        return node.get('implies', [])

    def get_chain_actions(self, finding_keys: List[str], max_depth: int = 2) -> List[Dict]:
        """获取发现链的推荐动作（深度推理）

        Args:
            finding_keys: 发现键名列表
            max_depth: 推理深度（默认2层）

        Returns:
            链式推荐动作列表
        """
        all_actions = []
        visited = set()

        def _traverse(keys, depth):
            if depth > max_depth:
                return
            for key in keys:
                if key in visited:
                    continue
                visited.add(key)

                node = self.nodes.get(key)
                if not node:
                    continue

                # 添加直接推荐的动作
                for action in node.get('next_actions', []):
                    all_actions.append({
                        'action': action,
                        'depth': depth,
                        'reason': f"推理深度{depth}: 由 {key} 推导",
                        'priority': self._calculate_priority({'severity': node.get('severity', 'low')}, action)
                    })

                # 递归推理暗示的发现
                implied = node.get('implies', [])
                _traverse(implied, depth + 1)

        _traverse(finding_keys, 1)

        return self._deduplicate_and_sort(all_actions)

    def classify_and_recommend(self, raw_findings: List[Dict]) -> Dict:
        """分类发现并推荐下一步动作（综合接口）

        Args:
            raw_findings: 原始发现列表

        Returns:
            包含分类结果和推荐动作的字典
        """
        classified = {
            'ports': [],
            'services': [],
            'technologies': [],
            'vulnerabilities': [],
            'misconfigurations': [],
            'other': []
        }

        for finding in raw_findings:
            finding_key = self._classify_finding(finding)
            node = self.nodes.get(finding_key)

            if node:
                category = node.get('category', 'other')
                if category in ('port',):
                    classified['ports'].append(finding)
                elif category in ('web_server', 'language', 'framework', 'cms'):
                    classified['technologies'].append(finding)
                elif category in ('injection', 'execution', 'upload', 'request_forgery',
                                  'file_inclusion', 'auth', 'disclosure'):
                    classified['vulnerabilities'].append(finding)
                elif category in ('misconfig',):
                    classified['misconfigurations'].append(finding)
                else:
                    classified['other'].append(finding)
            else:
                classified['other'].append(finding)

        # 获取推荐动作
        immediate_actions = self.get_next_actions(raw_findings)
        chain_actions = self.get_chain_actions(
            [self._classify_finding(f) for f in raw_findings],
            max_depth=2
        )

        return {
            'classified_findings': classified,
            'immediate_actions': immediate_actions[:10],
            'chain_actions': chain_actions[:5],
            'total_findings': len(raw_findings),
            'critical_count': len(classified['vulnerabilities']),
            'recommendation': self._generate_overall_recommendation(classified)
        }

    def _classify_finding(self, finding: Dict) -> str:
        """将原始发现分类为知识图谱中的节点键名"""
        if isinstance(finding, str):
            return finding

        finding_type = finding.get('type', '')
        finding_key = finding.get('key', '')
        port = finding.get('port', '')
        service = finding.get('service', '')
        severity = finding.get('severity', '')
        name = finding.get('name', '')

        # 端口发现
        if port:
            return f"open_port_{port}"

        # SQL注入
        if any(kw in finding_type.lower() + name.lower() for kw in ['sql', 'sqli']):
            return "sql_injection_found"

        # XSS
        if 'xss' in finding_type.lower() + name.lower():
            return "xss_found"

        # LFI
        if any(kw in finding_type.lower() + name.lower() for kw in ['lfi', 'local_file']):
            return "lfi_found"

        # RFI
        if any(kw in finding_type.lower() + name.lower() for kw in ['rfi', 'remote_file']):
            return "rfi_found"

        # SSRF
        if 'ssrf' in finding_type.lower() + name.lower():
            return "ssrf_found"

        # RCE
        if any(kw in finding_type.lower() + name.lower() for kw in ['rce', 'command_exec', 'code_exec']):
            return "rce_found"

        # 文件上传
        if any(kw in finding_type.lower() + name.lower() for kw in ['upload', 'file_upload']):
            return "file_upload_found"

        # 信息泄露
        if any(kw in finding_type.lower() + name.lower() for kw in ['info_disc', 'disclosure', '泄露']):
            return "info_disclosure_found"

        # Git泄露
        if any(kw in finding_type.lower() + name.lower() + finding_key.lower() for kw in ['git']):
            return "git_exposure"

        # .env
        if any(kw in finding_type.lower() + name.lower() + finding_key.lower() for kw in ['env', '.env', '环境变量']):
            return "env_exposure"

        # 弱口令
        if any(kw in finding_type.lower() + name.lower() for kw in ['weak_pass', 'default_pass', '弱口令', 'brute']):
            return "weak_credential_found"

        # 未授权访问
        if any(kw in finding_type.lower() + name.lower() for kw in ['unauth', 'unauthorized', '未授权']):
            return "unauth_access_found"

        # WordPress
        if any(kw in finding_type.lower() + name.lower() + service.lower() for kw in ['wordpress', 'wp-']):
            return "wordpress_detected"

        # Apache
        if 'apache' in service.lower() + name.lower():
            return "apache_detected"

        # Nginx
        if 'nginx' in service.lower() + name.lower():
            return "nginx_detected"

        # IIS
        if 'iis' in service.lower() + name.lower():
            return "iis_detected"

        # PHP
        if 'php' in service.lower() + name.lower():
            return "php_detected"

        # 服务名匹配
        service_lower = service.lower()
        if 'http' in service_lower:
            return "open_port_80"
        if 'ssh' in service_lower:
            return "open_port_22"
        if 'ftp' in service_lower:
            return "open_port_21"
        if 'mysql' in service_lower:
            return "open_port_3306"
        if 'redis' in service_lower:
            return "open_port_6379"
        if 'mongodb' in service_lower or 'mongo' in service_lower:
            return "open_port_27017"
        if 'rdp' in service_lower or 'ms-wbt' in service_lower:
            return "open_port_3389"

        return finding_key or finding_type or "unknown"

    def _calculate_priority(self, finding: Dict, action: str) -> float:
        """计算优先级

        基于严重程度、可利用性等因素
        """
        severity_score = {
            'critical': 10, 'high': 7, 'medium': 5, 'low': 3, 'info': 1
        }
        base_score = severity_score.get(
            finding.get('severity', 'low'), 3
        )

        # 某些动作天然优先级更高
        action_boost = {
            'exploit': 3, 'sqlmap_exploit': 3, 'rce_stable_shell': 3,
            'privilege_escalation': 3, 'lateral_movement': 2,
            'data_extraction': 2, 'database_enum': 2,
            'vulnerability_scan': 1, 'web_fingerprint': 1,
            'directory_scan': 1,
            # 利用类动作
            'rfi_exploit': 3, 'ssrf_exploit': 3, 'xxe_exploit': 2,
            'webshell_upload': 3, 'credential_extract': 2,
            # 验证类动作
            'xss_verify': 1, 'csrf_verify': 1, 'access_verify': 1,
        }

        boost = action_boost.get(action, 0)
        return base_score + boost

    def _deduplicate_and_sort(self, actions: List[Dict]) -> List[Dict]:
        """去重并按优先级排序"""
        seen = set()
        unique = []

        for action in actions:
            key = action.get('action', '')
            if key not in seen:
                seen.add(key)
                unique.append(action)

        # 按优先级降序排序
        unique.sort(key=lambda x: x.get('priority', 0), reverse=True)
        return unique

    def _generate_overall_recommendation(self, classified: Dict) -> str:
        """生成整体建议"""
        vuln_count = len(classified['vulnerabilities'])
        misconfig_count = len(classified['misconfigurations'])

        if vuln_count > 0:
            return f"发现{vuln_count}个漏洞，建议优先验证和利用关键漏洞，深入渗透测试"
        elif misconfig_count > 0:
            return f"发现{misconfig_count}个配置问题，建议先修复安全问题，同时深入扫描"
        elif classified['ports'] or classified['technologies']:
            return "信息收集阶段完成，建议进行漏洞扫描和Web渗透测试"
        else:
            return "未发现明显风险，建议扩大扫描范围或调整测试策略"
