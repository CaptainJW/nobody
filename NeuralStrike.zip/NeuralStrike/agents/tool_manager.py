#!/usr/bin/env python3
"""
HexStrike 工具管理器 — Kali/Linux 系统工具检测

功能：
1. 自动检测系统 PATH 中已安装的渗透测试工具
2. Kali Linux 特殊路径支持
3. 按优先级选择最佳可用工具
4. 字典文件发现（/usr/share/wordlists 等）
5. 工具安装指引（apt/pip/go install）
"""

import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"

# Kali 系统字典标准路径
KALI_WORDLIST_DIRS = [
    '/usr/share/wordlists',
    '/usr/share/seclists',
    '/usr/share/dirb',
    '/usr/share/dirbuster',
    '/usr/share/wfuzz',
    '/usr/share/amass',
]


class ToolManager:
    """工具管理器 — 检测系统已安装的渗透测试工具"""

    # 工具注册表：名称 → 分类 + 安装方式
    TOOL_REGISTRY = {
        # ============================================================
        # 端口扫描
        # ============================================================
        'nmap':       {'category': 'port_scan',   'apt': 'nmap',     'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'masscan':    {'category': 'port_scan',   'apt': 'masscan',  'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'python-nmap':{'category': 'port_scan',   'apt': None,       'go': None, 'pip': 'python-nmap', 'pip_check': 'nmap',  'aliases': []},
        # ============================================================
        # 漏洞扫描
        # ============================================================
        'nuclei':     {'category': 'vuln_scan',   'apt': 'nuclei',   'go': 'github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest', 'pip': None, 'pip_check': None, 'aliases': []},
        'nikto':      {'category': 'vuln_scan',   'apt': 'nikto',    'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'wpscan':     {'category': 'vuln_scan',   'apt': 'wpscan',   'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'openvas':    {'category': 'vuln_scan',   'apt': 'openvas',  'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        # ============================================================
        # 指纹识别
        # ============================================================
        'whatweb':    {'category': 'fingerprint', 'apt': 'whatweb',  'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        # ============================================================
        # 目录扫描
        # ============================================================
        'dirsearch':  {'category': 'dir_scan',    'apt': 'dirsearch', 'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'gobuster':   {'category': 'dir_scan',    'apt': 'gobuster',  'go': 'github.com/OJ/gobuster/v3@latest', 'pip': None, 'pip_check': None, 'aliases': []},
        'feroxbuster': {'category': 'dir_scan',   'apt': 'feroxbuster', 'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'dirb':       {'category': 'dir_scan',    'apt': 'dirb',      'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'ffuf':       {'category': 'dir_scan',    'apt': 'ffuf',      'go': 'github.com/ffuf/ffuf/v2@latest', 'pip': None, 'pip_check': None, 'aliases': []},
        # ============================================================
        # 子域名枚举
        # ============================================================
        'amass':      {'category': 'subdomain',   'apt': 'amass',    'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'subfinder':  {'category': 'subdomain',   'apt': 'subfinder', 'go': 'github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest', 'pip': None, 'pip_check': None, 'aliases': []},
        # ============================================================
        # SQL注入
        # ============================================================
        'sqlmap':     {'category': 'sqli_scan',   'apt': 'sqlmap',   'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        # ============================================================
        # XSS扫描
        # ============================================================
        'dalfox':     {'category': 'xss_scan',    'apt': 'dalfox',   'go': 'github.com/hahwul/dalfox/v2@latest', 'pip': None, 'pip_check': None, 'aliases': []},
        # ============================================================
        # SSL/TLS扫描
        # ============================================================
        'sslyze':     {'category': 'ssl_scan',    'apt': None,       'go': None, 'pip': 'sslyze', 'pip_check': 'sslyze', 'aliases': []},
        'testssl':    {'category': 'ssl_scan',    'apt': 'testssl.sh', 'go': None, 'pip': None, 'pip_check': None, 'aliases': ['testssl.sh']},
        # ============================================================
        # DNS工具
        # ============================================================
        'dig':        {'category': 'dns',         'apt': 'dnsutils',  'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'dnsrecon':   {'category': 'dns',         'apt': 'dnsrecon',  'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        # ============================================================
        # Web扫描
        # ============================================================
        'beautifulsoup4': {'category': 'web_scan', 'apt': None,     'go': None, 'pip': 'beautifulsoup4', 'pip_check': 'bs4',  'aliases': ['bs4']},
        # ============================================================
        # 暴力破解
        # ============================================================
        'hydra':      {'category': 'brute_force', 'apt': 'hydra',     'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'medusa':     {'category': 'brute_force', 'apt': 'medusa',    'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'ncrack':     {'category': 'brute_force', 'apt': 'ncrack',    'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'john':       {'category': 'brute_force', 'apt': 'john',      'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'hashcat':    {'category': 'brute_force', 'apt': 'hashcat',   'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'crowbar':    {'category': 'brute_force', 'apt': 'crowbar',   'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'patator':    {'category': 'brute_force', 'apt': 'patator',   'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'pymysql':    {'category': 'brute_force', 'apt': None,       'go': None, 'pip': 'pymysql',    'pip_check': 'pymysql',    'aliases': []},
        'psycopg2':   {'category': 'brute_force', 'apt': None,       'go': None, 'pip': 'psycopg2-binary', 'pip_check': 'psycopg2', 'aliases': []},
        'pymssql':    {'category': 'brute_force', 'apt': None,       'go': None, 'pip': 'pymssql',   'pip_check': 'pymssql',   'aliases': []},
        'paramiko':   {'category': 'brute_force', 'apt': None,       'go': None, 'pip': 'paramiko',  'pip_check': 'paramiko',  'aliases': []},
        # ============================================================
        # 后渗透
        # ============================================================
        'linpeas':    {'category': 'post_exploit', 'apt': 'peass-ng', 'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'winpeas':    {'category': 'post_exploit', 'apt': 'peass-ng', 'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'crackmapexec': {'category': 'post_exploit', 'apt': 'crackmapexec', 'go': None, 'pip': 'crackmapexec', 'pip_check': 'crackmapexec', 'aliases': ['cme', 'nxc', 'netexec']},
        'chisel':     {'category': 'post_exploit', 'apt': None,       'go': 'github.com/jpillora/chisel@latest', 'pip': None, 'pip_check': None, 'aliases': []},
        'socat':      {'category': 'post_exploit', 'apt': 'socat',    'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'proxychains': {'category': 'post_exploit', 'apt': 'proxychains4', 'go': None, 'pip': None, 'pip_check': None, 'aliases': ['proxychains4']},
        'msfvenom':   {'category': 'post_exploit', 'apt': 'metasploit-framework', 'go': None, 'pip': None, 'pip_check': None, 'aliases': ['msfconsole']},
        'impacket':   {'category': 'post_exploit', 'apt': None,      'go': None, 'pip': 'impacket',   'pip_check': 'impacket',  'aliases': []},
        'impacket-smbexec': {'category': 'post_exploit', 'apt': 'impacket-scripts', 'go': None, 'pip': None, 'pip_check': None, 'aliases': ['smbexec.py']},
        'impacket-wmiexec': {'category': 'post_exploit', 'apt': 'impacket-scripts', 'go': None, 'pip': None, 'pip_check': None, 'aliases': ['wmiexec.py']},
        'impacket-psexec':  {'category': 'post_exploit', 'apt': 'impacket-scripts', 'go': None, 'pip': None, 'pip_check': None, 'aliases': ['psexec.py']},
        'bloodhound': {'category': 'post_exploit', 'apt': 'bloodhound-ce', 'go': None, 'pip': 'bloodhound-ce', 'pip_check': 'bloodhound', 'aliases': ['bloodhound-ce', 'bloodhound-python']},
        'mimikatz':   {'category': 'post_exploit', 'apt': None,       'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'responder':  {'category': 'post_exploit', 'apt': 'responder', 'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'smbclient':  {'category': 'post_exploit', 'apt': 'samba',    'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'enum4linux': {'category': 'post_exploit', 'apt': 'enum4linux', 'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        # ============================================================
        # 网络工具
        # ============================================================
        'arp-scan':   {'category': 'network',     'apt': 'arp-scan', 'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'traceroute': {'category': 'network',     'apt': 'traceroute', 'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'whois':      {'category': 'network',     'apt': 'whois',    'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'curl':       {'category': 'network',     'apt': 'curl',     'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'wget':       {'category': 'network',     'apt': 'wget',    'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'netcat':     {'category': 'network',     'apt': 'netcat',   'go': None, 'pip': None, 'pip_check': None, 'aliases': ['nc']},
        'nbtscan':    {'category': 'network',     'apt': 'nbtscan',  'go': None, 'pip': None, 'pip_check': None, 'aliases': []},
        'scapy':      {'category': 'network',     'apt': None,      'go': None, 'pip': 'scapy',      'pip_check': 'scapy',     'aliases': []},
    }

    def __init__(self):
        self._tool_cache: Dict[str, Dict] = {}
        self._scan_tools()

    def _is_kali(self) -> bool:
        """检测是否在 Kali Linux 上运行"""
        try:
            if os.path.exists('/etc/os-release'):
                with open('/etc/os-release', 'r') as f:
                    if 'kali' in f.read().lower():
                        return True
        except Exception:
            pass
        return False

    def _scan_tools(self):
        """扫描所有可用工具"""
        self._tool_cache = {}

        # 确保 ~/.local/bin 在 PATH 中（GitHub 安装的路径）
        local_bin = os.path.expanduser('~/.local/bin')
        if local_bin not in os.environ.get('PATH', '') and os.path.isdir(local_bin):
            os.environ['PATH'] = local_bin + os.pathsep + os.environ.get('PATH', '')

        for tool_name, registry_info in self.TOOL_REGISTRY.items():
            path = None
            source = 'none'
            pip_name = registry_info.get('pip')
            pip_check = registry_info.get('pip_check')
            aliases = registry_info.get('aliases', [])

            # ── 1. shutil.which 精确匹配 ──
            path = shutil.which(tool_name)

            # ── 2. 别名检测（testssl→testssl.sh, crackmapexec→nxc 等）──
            if not path:
                for alias in aliases:
                    path = shutil.which(alias)
                    if path:
                        break

            # ── 3. Kali 特殊路径检测 ──
            if not path and self._is_kali():
                path = self._check_kali_path(tool_name)
                # 也检查别名的 Kali 路径
                if not path:
                    for alias in aliases:
                        path = self._check_kali_path(alias)
                        if path:
                            break

            # ── 4. 特殊工具：sqlmap ──
            if tool_name == 'sqlmap' and not path:
                try:
                    r = subprocess.run(['sqlmap', '--version'], capture_output=True, timeout=5,
                               stdin=subprocess.DEVNULL)
                    if r.returncode == 0:
                        path = 'sqlmap'
                except Exception:
                    pass
                if not path:
                    path = shutil.which('sqlmap')

            # ── 5. 特殊工具：sslyze（python -m sslyze）──
            if tool_name == 'sslyze' and not path:
                try:
                    r = subprocess.run([sys.executable, '-m', 'sslyze', '--version'],
                                       capture_output=True, timeout=5,
                                       stdin=subprocess.DEVNULL)
                    if r.returncode == 0:
                        path = 'python -m sslyze'
                        source = 'pip'
                except Exception:
                    pass

            # ── 6. Python 模块检测（pip_check 字段）──
            # 用 python -c "import xxx" 检测 pip 安装的包是否可用
            if not path and pip_check:
                try:
                    r = subprocess.run(
                        [sys.executable, '-c', f'import {pip_check}'],
                        capture_output=True, timeout=5, text=True,
                        stdin=subprocess.DEVNULL
                    )
                    if r.returncode == 0:
                        path = f'pip:{pip_name or pip_check}'
                        source = 'pip'
                except Exception:
                    pass

            # ── 7. crackmapexec 特殊：检查 nxc（Kali 新版改名）──
            if tool_name == 'crackmapexec' and not path:
                for cmd in ['nxc', 'netexec', 'cme']:
                    found = shutil.which(cmd)
                    if found:
                        path = found
                        break

            if path and source == 'none':
                source = 'system'

            self._tool_cache[tool_name] = {
                'available': path is not None,
                'path': path,
                'source': source,
                'category': registry_info['category'],
            }

        available = sum(1 for t in self._tool_cache.values() if t['available'])
        total = len(self._tool_cache)
        logger.info(f"工具扫描完成: {available}/{total} 可用")

    def _check_kali_path(self, tool_name: str) -> Optional[str]:
        """Kali Linux 的特殊工具路径 + ~/.local/bin"""
        # 优先检查 ~/.local/bin（GitHub 安装路径）
        local_bin = os.path.expanduser(f'~/.local/bin/{tool_name}')
        if os.path.isfile(local_bin) and os.access(local_bin, os.X_OK):
            return local_bin

        kali_paths = {
            'nmap': '/usr/bin/nmap',
            'masscan': '/usr/bin/masscan',
            'nuclei': '/usr/bin/nuclei',
            'whatweb': '/usr/bin/whatweb',
            'nikto': '/usr/bin/nikto',
            'dirsearch': '/usr/bin/dirsearch',
            'gobuster': '/usr/bin/gobuster',
            'feroxbuster': '/usr/bin/feroxbuster',
            'dirb': '/usr/bin/dirb',
            'ffuf': '/usr/bin/ffuf',
            'amass': '/usr/bin/amass',
            'subfinder': '/usr/bin/subfinder',
            'sqlmap': '/usr/bin/sqlmap',
            'dalfox': '/usr/bin/dalfox',
            'dnsrecon': '/usr/bin/dnsrecon',
            'wpscan': '/usr/bin/wpscan',
            'hydra': '/usr/bin/hydra',
            'medusa': '/usr/bin/medusa',
            'john': '/usr/bin/john',
            'hashcat': '/usr/bin/hashcat',
            'crowbar': '/usr/bin/crowbar',
            'patator': '/usr/bin/patator',
            'socat': '/usr/bin/socat',
            'dig': '/usr/bin/dig',
            'curl': '/usr/bin/curl',
            'wget': '/usr/bin/wget',
            'nc': '/bin/nc',
            'netcat': '/bin/nc',
            'whois': '/usr/bin/whois',
            'traceroute': '/usr/bin/traceroute',
            'arp-scan': '/usr/bin/arp-scan',
            'smbclient': '/usr/bin/smbclient',
            'enum4linux': '/usr/bin/enum4linux',
            'responder': '/usr/bin/responder',
            'proxychains': '/usr/bin/proxychains4',
            'proxychains4': '/usr/bin/proxychains4',
            'msfvenom': '/usr/bin/msfvenom',
            'msfconsole': '/usr/bin/msfconsole',
            'bloodhound': '/usr/bin/bloodhound',
            'bloodhound-ce': '/usr/bin/bloodhound-ce',
            'bloodhound-python': '/usr/bin/bloodhound-python',
            'crackmapexec': '/usr/bin/crackmapexec',
            'cme': '/usr/bin/cme',
            'nxc': '/usr/bin/nxc',
            'netexec': '/usr/bin/netexec',
        'crackmapexec': '/usr/bin/crackmapexec',
            'testssl': '/usr/bin/testssl',
            'testssl.sh': '/usr/bin/testssl.sh',
            'smbexec.py': '/usr/bin/smbexec.py',
            'wmiexec.py': '/usr/bin/wmiexec.py',
            'psexec.py': '/usr/bin/psexec.py',
        }
        kali_path = kali_paths.get(tool_name)
        if kali_path and os.path.isfile(kali_path) and os.access(kali_path, os.X_OK):
            return kali_path
        return None

    # =========================================================================
    # 公共 API
    # =========================================================================

    def is_available(self, tool_name: str) -> bool:
        info = self._tool_cache.get(tool_name, {})
        return info.get('available', False)

    def get_tool_path(self, tool_name: str) -> Optional[str]:
        info = self._tool_cache.get(tool_name, {})
        return info.get('path')

    def get_run_command(self, tool_name: str) -> Optional[List[str]]:
        """获取工具运行命令（可直接传给 subprocess）"""
        info = self._tool_cache.get(tool_name, {})
        if not info.get('available'):
            return None

        path = info.get('path')

        # sslyze 走 python 模块
        if tool_name == 'sslyze' and path == 'python -m sslyze':
            return [sys.executable, '-m', 'sslyze']

        # sqlmap 走系统命令
        if tool_name == 'sqlmap' and path:
            return [path]

        # 其他系统工具直接用可执行文件路径或名称
        if path:
            return [path]

        return None

    def get_available_tools(self) -> Dict[str, Dict]:
        return {k: v for k, v in self._tool_cache.items() if v.get('available')}

    def get_all_tools(self) -> Dict[str, Dict]:
        return self._tool_cache.copy()

    def get_tools_by_category(self, category: str) -> Dict[str, Dict]:
        return {k: v for k, v in self._tool_cache.items() if v.get('category') == category}

    def get_tool_info(self, tool_name: str) -> Dict:
        return self._tool_cache.get(tool_name, {})

    def get_best_tool(self, category: str) -> Optional[str]:
        """获取某类别中最佳可用工具"""
        priority = {
            'port_scan': ['nmap', 'masscan', 'python-nmap'],
            'vuln_scan': ['nuclei', 'nikto', 'wpscan', 'openvas'],
            'fingerprint': ['whatweb', 'nikto'],
            'dir_scan': ['feroxbuster', 'gobuster', 'dirsearch', 'dirb', 'ffuf'],
            'subdomain': ['subfinder', 'amass'],
            'sqli_scan': ['sqlmap'],
            'xss_scan': ['dalfox'],
            'ssl_scan': ['sslyze', 'testssl'],
            'dns': ['dig', 'dnsrecon'],
            'web_scan': ['wpscan', 'beautifulsoup4'],
            'brute_force': ['hydra', 'medusa', 'ncrack', 'john', 'hashcat', 'crowbar', 'patator'],
            'post_exploit': ['msfvenom', 'crackmapexec', 'impacket', 'bloodhound', 'chisel', 'responder', 'socat'],
            'network': ['curl', 'wget', 'arp-scan', 'traceroute', 'whois', 'netcat', 'nbtscan', 'scapy'],
        }
        for tool in priority.get(category, []):
            if self.is_available(tool):
                return tool
        # 兜底：该类别第一个可用的
        for name, info in self.get_tools_by_category(category).items():
            if info.get('available'):
                return name
        return None

    def find_wordlist(self, name: str = 'common') -> Optional[str]:
        """查找字典文件"""
        search_paths = [
            # Kali 标准路径
            Path(f'/usr/share/wordlists/dirb/{name}.txt'),
            Path(f'/usr/share/wordlists/dirbuster/{name}.txt'),
            Path('/usr/share/wordlists/dirb/common.txt'),
            Path('/usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt'),
            Path('/usr/share/seclists/Discovery/Web-Content/common.txt'),
            Path('/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt'),
            # 项目本地
            DATA_DIR / 'wordlists' / f'{name}.txt',
            DATA_DIR / f'{name}.txt',
        ]

        for p in search_paths:
            if p.exists():
                return str(p)

        # 在系统字典目录中递归查找
        for wdir in KALI_WORDLIST_DIRS:
            wp = Path(wdir)
            if wp.is_dir():
                for candidate in wp.rglob(f'{name}.txt'):
                    return str(candidate)

        return None

    def get_install_hint(self, tool_name: str) -> str:
        """获取工具安装提示"""
        info = self._tool_cache.get(tool_name, {})
        if info.get('available'):
            return f"✅ {tool_name} 已安装 (路径: {info.get('path', '_unknown')})"

        registry = self.TOOL_REGISTRY.get(tool_name, {})
        apt_pkg = registry.get('apt')
        go_pkg = registry.get('go')
        pip_pkg = registry.get('pip')

        hints = []
        if apt_pkg:
            hints.append(f"  apt install {apt_pkg}")
        if pip_pkg:
            hints.append(f"  pip install {pip_pkg}")
        if go_pkg:
            hints.append(f"  go install {go_pkg}")

        if hints:
            return f"📥 安装 {tool_name}:\n" + "\n".join(hints)

        return f"📥 未知工具: {tool_name}"

    def get_status_report(self) -> str:
        """获取所有工具状态的文本报告"""
        categories = {
            'port_scan': '📡 端口扫描',
            'vuln_scan': '🔍 漏洞扫描',
            'fingerprint': '🖐 指纹识别',
            'dir_scan': '📂 目录扫描',
            'subdomain': '🌐 子域名枚举',
            'sqli_scan': '💉 SQL注入',
            'xss_scan': '✖️ XSS扫描',
            'ssl_scan': '🔒 SSL/TLS扫描',
            'dns': '📋 DNS工具',
            'web_scan': '🌍 Web扫描',
            'brute_force': '🗝️ 暴力破解',
            'post_exploit': '⚔️ 后渗透',
            'network': '🔌 网络工具',
        }

        lines = ["=" * 60, "🔧 HexStrike 工具状态报告", "=" * 60, ""]

        for cat_id, cat_name in categories.items():
            tools = self.get_tools_by_category(cat_id)
            if not tools:
                continue
            lines.append(f"  {cat_name}")
            for tool_name, info in tools.items():
                status = "✅" if info.get('available') else "❌"
                path = info.get('path', '')
                if info.get('available'):
                    lines.append(f"    {status} {tool_name} ({path})")
                else:
                    lines.append(f"    {status} {tool_name}")
            lines.append("")

        unavailable = {k: v for k, v in self._tool_cache.items() if not v.get('available')}
        if unavailable:
            lines.append("📝 未安装工具安装指引:")
            lines.append("-" * 40)
            for tool_name in unavailable:
                lines.append(self.get_install_hint(tool_name))
                lines.append("")

        return "\n".join(lines)

    def refresh(self):
        """重新扫描工具"""
        self._scan_tools()


# 全局单例
_tool_manager_instance: Optional[ToolManager] = None


def get_tool_manager() -> ToolManager:
    global _tool_manager_instance
    if _tool_manager_instance is None:
        _tool_manager_instance = ToolManager()
    return _tool_manager_instance


def is_tool_available(tool_name: str) -> bool:
    return get_tool_manager().is_available(tool_name)


def get_tool_command(tool_name: str) -> Optional[List[str]]:
    return get_tool_manager().get_run_command(tool_name)


def find_wordlist(name: str = 'common') -> Optional[str]:
    return get_tool_manager().find_wordlist(name)
