# agents/base_agent.py
# 包含两套Agent体系：BaseAgent（传统任务型）和 SmartAgent（AI推理型）
import json
import logging
import os
import shutil
import subprocess
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
import asyncio

from .ai_client import AIAgentFactory, AISession, BaseAIClient
from .utils import parse_json_response


class TaskResult:
    """任务结果数据类"""

    def __init__(self, agent_name: str, task_type: str, status: str = "pending",
                 result: Any = None, findings: List = None, metadata: Dict = None):
        self.agent_name = agent_name
        self.task_type = task_type
        self.status = status
        self.result = result
        self.findings = findings or []
        self.metadata = metadata or {}
        self.errors: List[str] = []
        self.start_time = time.time()
        self.end_time: Optional[float] = None

    def add_error(self, error: str):
        """添加错误信息"""
        self.errors.append(error)

    def mark_complete(self, status: str = "success"):
        """标记完成"""
        self.status = status
        self.end_time = time.time()

    @property
    def duration(self) -> Optional[float]:
        """任务耗时（秒）"""
        if self.end_time:
            return self.end_time - self.start_time
        return None

    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "agent_name": self.agent_name,
            "task_type": self.task_type,
            "status": self.status,
            "result": self.result,
            "findings": self.findings,
            "metadata": self.metadata,
            "errors": self.errors,
            "duration": self.duration
        }


class BaseAgent(ABC):
    """传统Agent基类 - 用于任务型Agent（漏洞扫描、Web渗透、报告生成等）"""

    def __init__(self, name: str, workspace: str = "workspace", ai_config: Dict = None):
        self.name = name
        self.workspace = Path(workspace)
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.ai_config = ai_config or {}
        self.logger = logging.getLogger(f"Agent.{name}")
        self._ai_client = None

    @abstractmethod
    def get_system_prompt(self) -> str:
        """获取系统提示词"""
        pass

    @abstractmethod
    async def execute(self, target: str, options: Dict = None) -> TaskResult:
        """执行任务"""
        pass

    def run_command(self, cmd: str, timeout: int = 300) -> Dict:
        """执行系统命令 - 使用shlex防止命令注入"""
        import shlex
        try:
            # 检查命令中的工具是否已安装
            cmd_parts = shlex.split(cmd)
            if cmd_parts:
                tool_name = os.path.basename(cmd_parts[0])
                if not shutil.which(tool_name) and not os.path.isfile(cmd_parts[0]):
                    return {
                        "success": False, 
                        "stdout": "", 
                        "stderr": f"工具 {tool_name} 未安装，请前往工具管理页面安装",
                        "returncode": -1,
                        "tool_missing": True
                    }
            process = subprocess.run(
                cmd_parts,  # 安全替代 shell=True
                capture_output=True, text=True, timeout=timeout,
                stdin=subprocess.DEVNULL  # 防止子进程抢占tty导致suspended
            )
            return {
                "success": process.returncode == 0,
                "stdout": process.stdout,
                "stderr": process.stderr,
                "returncode": process.returncode
            }
        except FileNotFoundError as e:
            return {"success": False, "stdout": "", "stderr": f"命令未找到: {e}", "returncode": -1, "tool_missing": True}
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": "Command timed out", "returncode": -1}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "returncode": -1}

    def run_tool_command(self, tool_name: str, cmd: str, purpose: str = '', timeout: int = 300) -> Dict:
        """执行工具命令 — 自动发出工具调用和命令语法思考事件
        
        Args:
            tool_name: 工具名称（如 nmap, nuclei, sqlmap）
            cmd: 完整命令
            purpose: 用途说明
            timeout: 超时时间
        """
        # 🧠 发送工具调用思考
        self._emit_thinking("action",  # 用 action 类型触发 tool_call 检测
            "🔧 调用工具: {} | 用途: {}\n"
            "   命令: {}".format(tool_name, purpose or '扫描', cmd))
        
        # 🧠 发送命令语法思考（代码块样式）
        self._emit_thinking("command", cmd)
        
        result = self.run_command(cmd, timeout)
        
        # 🧠 发送结果思考
        if result.get('success'):
            stdout_preview = (result.get('stdout', '') or '')[:500]
            self._emit_thinking("evaluate",
                "📤 {} 执行完成 (耗时≤{}秒)\n"
                "   输出预览: {}".format(
                    tool_name, timeout,
                    stdout_preview.replace('\n', ' ')[:200] if stdout_preview else '(无输出)'
                ))
        else:
            stderr_preview = (result.get('stderr', '') or '')[:200]
            self._emit_thinking("error",
                "❌ {} 执行失败\n"
                "   错误: {}".format(tool_name, stderr_preview or '未知错误'))
        
        return result

    def ask_ai(self, prompt: str) -> str:
        """向AI提问 - 如果有AI客户端则调用，否则返回模拟响应"""
        if self._ai_client:
            try:
                return self._ai_client.chat(prompt, self.get_system_prompt())
            except Exception as e:
                self.logger.warning(f"AI调用失败: {e}")

        # 模拟响应
        self.logger.warning("AI客户端未配置，返回模拟响应")
        return json.dumps({
            "status": "模拟响应",
            "message": f"来自 {self.name} 的模拟AI响应"
        })


class SmartAgent(ABC):
    """智能Agent基类 - 具备推理和决策能力，AI驱动动态工作流"""

    # 子类可覆盖：agent显示名称（中文）
    display_name: str = ""

    # action名称别名映射 — 处理AI返回的不同命名
    ACTION_ALIASES: Dict[str, str] = {}

    def __init__(self, name: str, ai_config: Dict[str, Any], workspace: str):
        self.name = name
        self.ai_config = ai_config
        self.workspace = workspace
        self.logger = logging.getLogger(f"SmartAgent.{name}")
        self.context = {}  # 全局上下文
        self.capabilities = self.define_capabilities()
        self._ai_client: Optional[BaseAIClient] = None
        self._ai_session: Optional[AISession] = None
        self._knowledge_graph = None  # 延迟加载，缓存实例避免重复创建
        self._assigned_tasks: List[str] = []  # 编排器分配的指定任务
        self._thinking_callback = None  # AI思考过程回调函数
        self._init_ai_client()

    def _init_ai_client(self):
        """初始化AI客户端"""
        try:
            if self.ai_config and isinstance(self.ai_config, dict):
                provider = self.ai_config.get('provider', 'mock')
                config = self.ai_config.get('config', {})
                self._ai_client = AIAgentFactory.create_client(provider, config)
                self._ai_session = AISession(self._ai_client, self.get_system_prompt())
                self.logger.info(f"AI客户端初始化成功: {provider}")
        except Exception as e:
            self.logger.warning(f"AI客户端初始化失败: {e}, 将使用模拟模式")
            # 降级到MockAI
            try:
                self._ai_client = AIAgentFactory.create_client('mock', {})
                self._ai_session = AISession(self._ai_client, self.get_system_prompt())
            except Exception:
                self._ai_client = None
                self._ai_session = None

    @property
    def ai_session(self):
        """兼容属性：返回 _ai_session"""
        return self._ai_session

    @ai_session.setter
    def ai_session(self, value):
        self._ai_session = value

    def set_thinking_callback(self, callback):
        """设置AI思考过程回调 — 回调签名: callback(thinking_type: str, content: str, agent_name: str)

        thinking_type 类型:
            - "analyze"  : 情况分析
            - "plan"     : 制定计划
            - "action"   : 执行动作
            - "evaluate" : 结果评估
            - "decide"   : 决策下一步
            - "command"  : 命令语法（自动提取到前端代码块展示）
        """
        self._thinking_callback = callback

    def _emit_thinking(self, thinking_type: str, content: str):
        """发送AI思考过程"""
        if self._thinking_callback:
            try:
                display = self.display_name or self.name
                self._thinking_callback(thinking_type, content, display)
            except Exception as e:
                self.logger.debug(f"思考回调异常: {e}")

    def _run_tool(self, cmd_list, tool_name: str = '', purpose: str = '', timeout: int = 300) -> Dict:
        """运行工具命令 — 自动发出工具调用+命令语法+结果 思考事件
        
        Args:
            cmd_list: 命令列表 (如 ['nmap', '-sV', '-T4', 'target']) 或字符串
            tool_name: 工具名称
            purpose: 用途
            timeout: 超时时间
        """
        import shlex
        # 统一转换为列表
        if isinstance(cmd_list, str):
            cmd_str = cmd_list
            cmd_list = shlex.split(cmd_str)
        else:
            cmd_str = ' '.join(str(x) for x in cmd_list)
        
        # 提取工具名
        if not tool_name and cmd_list:
            tool_name = str(cmd_list[0]).split('/')[-1]  # 去掉路径
        
        # 🔧 调用前检查工具是否已安装
        if cmd_list and not shutil.which(tool_name) and not os.path.isfile(str(cmd_list[0])):
            self._emit_thinking("error",
                f"❌ 工具 {tool_name} 未安装！请前往 🔧 工具管理 页面安装\n"
                f"   提示：点击「⬇️ 一键安装」或「🐙 GitHub 拉取安装」")
            return {
                "success": False,
                "stdout": "",
                "stderr": f"工具 {tool_name} 未安装",
                "returncode": -1,
                "tool_missing": True
            }
        
        # 🧠 发出工具调用事件
        self._emit_thinking("action",
            "🔧 调用工具: {} | 用途: {}\n"
            "   参数: {}".format(
                tool_name,
                purpose or '扫描',
                ' '.join(str(x) for x in cmd_list[1:]) if len(cmd_list) > 1 else '默认'
            ))
        
        # 🧠 发出命令语法事件（前端将以代码块样式展示）
        self._emit_thinking("command", cmd_str)
        
        # 执行命令
        t0 = time.time()
        try:
            process = subprocess.run(
                cmd_list,
                capture_output=True, text=True, timeout=timeout,
                stdin=subprocess.DEVNULL  # 防止子进程抢占tty导致suspended
            )
            elapsed = time.time() - t0
            result = {
                "success": process.returncode == 0,
                "stdout": process.stdout,
                "stderr": process.stderr,
                "returncode": process.returncode
            }
        except subprocess.TimeoutExpired:
            elapsed = time.time() - t0
            result = {"success": False, "stdout": "", "stderr": f"命令超时 ({timeout}s)", "returncode": -1}
        except FileNotFoundError:
            elapsed = time.time() - t0
            result = {"success": False, "stdout": "", "stderr": f"工具未找到: {tool_name}", "returncode": -1, "tool_missing": True}
        except Exception as e:
            elapsed = time.time() - t0
            result = {"success": False, "stdout": "", "stderr": str(e), "returncode": -1}
        
        # 🧠 发出结果事件
        if result.get('success'):
            stdout_preview = (result.get('stdout', '') or '')[:300].replace('\n', ' ')
            self._emit_thinking("evaluate",
                "📤 {} 执行完成 ({:.1f}秒)\n"
                "   状态: 成功 | 输出: {}".format(
                    tool_name, elapsed,
                    stdout_preview[:150] if stdout_preview else '(无输出)'
                ))
        else:
            stderr_preview = (result.get('stderr', '') or '')[:200]
            self._emit_thinking("error",
                "❌ {} 执行失败 ({:.1f}秒)\n"
                "   错误: {}".format(tool_name, elapsed, stderr_preview or '未知错误'))
        
        return result

    async def _run_tool_async(self, cmd_list, tool_name: str = '', purpose: str = '', timeout: int = 300) -> Dict:
        """异步运行工具命令 — 自动发出工具调用+命令语法+结果 思考事件
        
        Args:
            cmd_list: 命令列表或字符串
            tool_name: 工具名称
            purpose: 用途
            timeout: 超时时间
        """
        import shlex
        if isinstance(cmd_list, str):
            cmd_str = cmd_list
            cmd_list = shlex.split(cmd_str)
        else:
            cmd_str = ' '.join(str(x) for x in cmd_list)
        
        if not tool_name and cmd_list:
            tool_name = str(cmd_list[0]).split('/')[-1]
        
        # 🔧 调用前检查工具是否已安装
        if cmd_list and not shutil.which(tool_name) and not os.path.isfile(str(cmd_list[0])):
            self._emit_thinking("error",
                f"❌ 工具 {tool_name} 未安装！请前往 🔧 工具管理 页面安装\n"
                f"   提示：点击「⬇️ 一键安装」或「🐙 GitHub 拉取安装」")
            return {
                "success": False,
                "stdout": "",
                "stderr": f"工具 {tool_name} 未安装",
                "returncode": -1,
                "tool_missing": True
            }
        
        # 🧠 思考事件
        self._emit_thinking("action",
            "🔧 调用工具: {} | 用途: {}\n"
            "   参数: {}".format(
                tool_name, purpose or '扫描',
                ' '.join(str(x) for x in cmd_list[1:]) if len(cmd_list) > 1 else '默认'
            ))
        self._emit_thinking("command", cmd_str)
        
        # 异步执行
        t0 = time.time()
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd_list,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                stdin=asyncio.subprocess.DEVNULL  # 防止子进程抢占tty导致suspended
            )
            try:
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                process.kill()
                elapsed = time.time() - t0
                self._emit_thinking("error", f"❌ {tool_name} 执行超时 ({timeout}s)")
                return {"success": False, "stdout": "", "stderr": f"超时 ({timeout}s)", "returncode": -1}
            
            elapsed = time.time() - t0
            stdout_str = stdout.decode('utf-8', errors='replace') if stdout else ''
            stderr_str = stderr.decode('utf-8', errors='replace') if stderr else ''
            result = {
                "success": process.returncode == 0,
                "stdout": stdout_str,
                "stderr": stderr_str,
                "returncode": process.returncode
            }
            
            if result['success']:
                preview = stdout_str[:300].replace('\n', ' ')
                self._emit_thinking("evaluate",
                    "📤 {} 执行完成 ({:.1f}秒)\n"
                    "   状态: 成功 | 输出: {}".format(
                        tool_name, elapsed, preview[:150] if preview else '(无输出)'))
            else:
                self._emit_thinking("error",
                    "❌ {} 执行失败 ({:.1f}秒)\n"
                    "   错误: {}".format(tool_name, elapsed, stderr_str[:200] or '未知错误'))
            
            return result
            
        except FileNotFoundError:
            elapsed = time.time() - t0
            self._emit_thinking("error", f"❌ 工具未找到: {tool_name}")
            return {"success": False, "stdout": "", "stderr": f"工具未找到: {tool_name}", "returncode": -1}
        except Exception as e:
            elapsed = time.time() - t0
            self._emit_thinking("error", f"❌ {tool_name} 执行异常: {e}")
            return {"success": False, "stdout": "", "stderr": str(e), "returncode": -1}

    @abstractmethod
    def define_capabilities(self) -> Dict:
        """定义Agent的能力"""
        pass

    @abstractmethod
    def get_system_prompt(self) -> str:
        """获取系统提示词"""
        pass

    @abstractmethod
    def _analyze_situation(self, target: str, context: Dict) -> Dict:
        """分析当前情况"""
        pass

    async def _execute_plan(self, plan: Dict, target: str) -> List:
        """执行计划 — 由子类实现，基类提供通用逻辑"""
        results = []
        for step in plan.get('steps', []):
            action = step.get('action', '')
            params = step.get('params', {})
            reason = step.get('reason', '')
            # 🧠 发送思考：正在执行动作
            self._emit_thinking("action",
                "⚡ 执行: {} | 参数: {} | 原因: {}".format(
                    action,
                    json.dumps(params, ensure_ascii=False) if params else '默认',
                    reason or '编排器指定'
                ))
            if hasattr(self, f'_do_{action}'):
                method = getattr(self, f'_do_{action}')
                result = await method(target, params)
                results.append({
                    'action': action,
                    'result': result,
                    'success': result.get('success', False) if isinstance(result, dict) else True
                })
            else:
                self.logger.warning(f"未知动作: {action}")
                results.append({'action': action, 'result': {'error': f'未知动作: {action}'}, 'success': False})
        return results

    async def execute_with_reasoning(self, target: str, context: Dict, options: Dict) -> Dict:
        """带推理的执行 - AI驱动的动态决策

        Args:
            target: 目标地址
            context: 全局上下文（来自SharedMemory）
            options: 编排器传入的选项（含 assigned_tasks, stealth_mode 等）
        """

        self.logger.info(f"[{self.name}] 开始AI推理执行: {target}")

        # 提取编排器分配的指定任务
        if options and isinstance(options, dict):
            assigned_tasks = options.get('tasks', [])
            if assigned_tasks:
                self._assigned_tasks = assigned_tasks
                self.logger.info(f"[{self.name}] 编排器指定任务: {assigned_tasks}")

        # 1. 分析当前情况（传入options）
        situation = self._analyze_situation(target, context)
        if options and isinstance(options, dict):
            situation['assigned_tasks'] = self._assigned_tasks
            situation['stealth_mode'] = options.get('stealth_mode', False)
            situation['deep_scan'] = options.get('deep_scan', False)
        self.logger.info(f"[{self.name}] 情况分析完成: 目标类型={situation.get('target_type', 'unknown')}")
        # 🧠 发送思考：情况分析
        self._emit_thinking("analyze",
            "🧩 目标类型: {} | 目标: {}\n"
            "   可用工具: {}\n"
            "   隐蔽模式: {} | 深度扫描: {}".format(
                situation.get('target_type', '未知'),
                target,
                ', '.join(situation.get('available_tools', ['默认工具集'])),
                '是' if situation.get('stealth_mode') else '否',
                '是' if situation.get('deep_scan') else '否'
            ))

        # 2. AI决策：制定执行计划
        if self._assigned_tasks:
            plan = self._build_plan_from_tasks(self._assigned_tasks, situation)
            self.logger.info(f"[{self.name}] 使用编排器指定任务: {len(plan.get('steps', []))} 步")
            self._emit_thinking("plan",
                "📋 策略: {} (编排器指定)\n"
                "   步骤: {}".format(
                    plan.get('strategy', '指定策略'),
                    ' → '.join(s.get('action', '?') for s in plan.get('steps', []))
                ))
        else:
            plan = await self._ai_plan(situation)
            self.logger.info(f"[{self.name}] AI计划制定完成: 策略={plan.get('strategy', 'unknown')}, "
                             f"步骤数={len(plan.get('steps', []))}")
            # 🧠 发送思考：AI制定的计划
            steps_desc = []
            for s in plan.get('steps', []):
                reason = s.get('reason', '')
                steps_desc.append("   • {} — 原因: {}".format(s.get('action', '?'), reason))
            self._emit_thinking("plan",
                "📋 AI制定策略: {}\n"
                "   优先级: {} | 预计时间: {}秒\n"
                "   步骤:\n{}".format(
                    plan.get('strategy', '未知'),
                    plan.get('priority', '中'),
                    plan.get('estimated_time', '?'),
                    '\n'.join(steps_desc) if steps_desc else '   (无步骤)'
                ))

        # 3. 执行计划
        results = await self._execute_plan(plan, target)
        self.logger.info(f"[{self.name}] 计划执行完成: {len(results)} 个结果")

        # 4. AI评估结果
        evaluation = await self._ai_evaluate(results)
        self.logger.info(f"[{self.name}] AI评估完成: 可信度={evaluation.get('confidence', 0)}, "
                         f"关键发现={len(evaluation.get('key_findings', []))}")
        # 🧠 发送思考：AI评估
        findings_str = '\n'.join("   • " + str(f) for f in evaluation.get('key_findings', [])[:5])
        issues_str = '\n'.join("   • [{}] {}".format(
            i.get('severity', '?'), i.get('description', i.get('type', '')))
            for i in evaluation.get('security_issues', [])[:5])
        self._emit_thinking("evaluate",
            "🔍 AI评估结果:\n"
            "   可信度: {:.0%}\n"
            "   需要验证: {}\n"
            "   关键发现:\n{}\n"
            "   安全问题:\n{}".format(
                evaluation.get('confidence', 0),
                '是' if evaluation.get('needs_verification') else '否',
                findings_str if findings_str else '   (无)',
                issues_str if issues_str else '   (无)'
            ))

        # 5. 决定下一步
        next_actions = await self._ai_decide_next(evaluation, context)
        self.logger.info(f"[{self.name}] AI决策完成: 下一步Agent={len(next_actions.get('next_agents', []))}")
        # 🧠 发送思考：AI决策
        agents_str = '\n'.join("   • {} [{}] — 原因: {}".format(
            a.get('agent', '?'), a.get('priority', '?'), a.get('reason', ''))
            for a in next_actions.get('next_agents', [])[:5])
        self._emit_thinking("decide",
            "➡️ AI决策下一步:\n"
            "   建议Agent:\n{}\n"
            "   停止条件: {}\n"
            "   备选方案: {}".format(
                agents_str if agents_str else '   (无)',
                next_actions.get('stop_if', '无'),
                next_actions.get('fallback', '无')
            ))

        return {
            'agent_name': self.name,
            'display_name': self.display_name or self.name,
            'results': results,
            'evaluation': evaluation,
            'next_actions': next_actions,
            'context_updates': self._extract_context(results, evaluation)
        }

    def _build_plan_from_tasks(self, tasks: List[str], situation: Dict) -> Dict:
        """根据编排器指定的tasks构建执行计划（而非让AI重新规划）"""
        steps = []
        for task in tasks:
            # 标准化task名称
            action = self._resolve_action_name(task)
            params = {}
            # 智能推断默认参数
            if 'scan' in action:
                params = {'tool': 'auto'}
            if 'port' in action:
                params['ports'] = '1-1000'
            steps.append({
                'action': action,
                'params': params,
                'reason': '编排器指定任务'
            })
        return {
            'strategy': '编排器指定策略',
            'steps': steps,
            'priority': 'high',
            'estimated_time': str(len(steps) * 60)
        }

    def _resolve_action_name(self, raw_name: str) -> str:
        """解析action名称 — 处理别名、大小写、下划线/连字符"""
        # 1. 直接匹配
        if hasattr(self, f'_do_{raw_name}'):
            return raw_name

        # 2. 标准化：小写 + 替换空格/连字符为下划线
        normalized = raw_name.lower().replace(' ', '_').replace('-', '_')

        # 3. 别名映射
        resolved = self.ACTION_ALIASES.get(normalized, normalized)

        # 4. 检查解析后的名称是否有效
        if hasattr(self, f'_do_{resolved}'):
            return resolved

        # 5. 模糊匹配：尝试在所有 _do_ 方法中查找包含关键词的
        all_actions = [m[4:] for m in dir(self) if m.startswith('_do_') and callable(getattr(self, m))]
        for action in all_actions:
            if normalized in action or action in normalized:
                return action

        # 6. 返回原始名称（将由 _execute_plan 的降级处理）
        return raw_name

    async def _ai_plan(self, situation: Dict) -> Dict:
        """让AI制定执行计划"""
        prompt = f"""
你是一个专业的{self.name}专家。

当前情况:
{json.dumps(situation, indent=2, ensure_ascii=False)}

你的能力:
{json.dumps(self.capabilities, indent=2, ensure_ascii=False)}

请制定一个高效的执行计划，返回JSON格式:
{{
    "strategy": "选择的策略",
    "steps": [
        {{"action": "动作名称", "params": {{}}, "reason": "原因"}},
        ...
    ],
    "priority": "high/medium/low",
    "estimated_time": "预计时间"
}}
"""
        response = self.ask_ai(prompt)
        plan = self._parse_json_response(response)
        # 确保plan有基本结构
        plan.setdefault('strategy', '默认策略')
        plan.setdefault('steps', [])
        plan.setdefault('priority', 'medium')
        plan.setdefault('estimated_time', '60')
        return plan

    async def _ai_evaluate(self, results: List) -> Dict:
        """让AI评估结果"""
        prompt = f"""
执行结果:
{json.dumps(results, indent=2, ensure_ascii=False)[:3000]}

请评估:
1. 发现了什么关键信息？
2. 有哪些潜在的安全问题？
3. 结果的可信度如何？
4. 是否需要进一步验证？

返回JSON格式:
{{
    "key_findings": ["发现1", "发现2"],
    "security_issues": [{{"type": "类型", "severity": "严重程度", "description": "描述"}}],
    "confidence": 0.0-1.0,
    "needs_verification": true,
    "verification_suggestions": ["建议1", "建议2"]
}}
"""
        response = self.ask_ai(prompt)
        evaluation = self._parse_json_response(response)
        evaluation.setdefault('key_findings', [])
        evaluation.setdefault('security_issues', [])
        evaluation.setdefault('confidence', 0.5)
        evaluation.setdefault('needs_verification', False)
        evaluation.setdefault('verification_suggestions', [])
        return evaluation

    async def _ai_decide_next(self, evaluation: Dict, context: Dict) -> Dict:
        """让AI决定下一步"""
        prompt = f"""
当前评估:
{json.dumps(evaluation, indent=2, ensure_ascii=False)[:2000]}

全局上下文:
{json.dumps(context, indent=2, ensure_ascii=False)[:2000]}

基于以上信息，决定下一步应该:
1. 调用哪个Agent？
2. 传递什么参数？
3. 优先级如何？

返回JSON格式:
{{
    "next_agents": [
        {{"agent": "agent_name", "params": {{}}, "priority": "high/medium/low", "reason": "原因"}}
    ],
    "stop_if": "停止条件",
    "fallback": "备选方案"
}}
"""
        response = self.ask_ai(prompt)
        decision = self._parse_json_response(response)
        decision.setdefault('next_agents', [])
        decision.setdefault('stop_if', '')
        decision.setdefault('fallback', '')
        return decision

    def ask_ai(self, prompt: str) -> str:
        """向AI提问 - 使用AI客户端或降级到模拟"""
        if self._ai_session:
            try:
                return self._ai_session.chat(prompt)
            except Exception as e:
                self.logger.warning(f"AI会话调用失败: {e}")

        # 尝试直接使用AI客户端
        if self._ai_client:
            try:
                return self._ai_client.chat(prompt, self.get_system_prompt())
            except Exception as e:
                self.logger.warning(f"AI客户端调用失败: {e}")

        # 降级：返回基于prompt内容的智能默认响应
        self.logger.warning("AI不可用，返回智能默认响应")
        return self._generate_default_response(prompt)

    def _get_knowledge_graph(self):
        """获取知识图谱实例（缓存，避免重复创建30+节点20+边）"""
        if self._knowledge_graph is None:
            from .knowledge_graph import PentestKnowledgeGraph
            self._knowledge_graph = PentestKnowledgeGraph()
        return self._knowledge_graph

    def _generate_default_response(self, prompt: str) -> str:
        """基于prompt内容生成智能默认响应（无AI时的降级策略）"""
        kg = self._get_knowledge_graph()

        if "制定执行计划" in prompt or "计划" in prompt:
            # 基于知识图谱推荐动作
            current_findings = self.context.get('findings', [])
            if current_findings:
                recommended = kg.get_next_actions(current_findings)
                return json.dumps({
                    "strategy": "基于知识图谱的默认策略",
                    "steps": [
                        {"action": a['action'], "params": {}, "reason": a['reason']}
                        for a in recommended[:5]
                    ],
                    "priority": "medium",
                    "estimated_time": "300"
                }, ensure_ascii=False)

            # 目标类型推断
            target_type = "web_application"
            if "IP" in prompt or "ip_address" in prompt:
                target_type = "ip_address"

            if target_type == "web_application":
                return json.dumps({
                    "strategy": "Web应用扫描策略",
                    "steps": [
                        {"action": "port_scan", "params": {"tool": "auto", "ports": "80,443,8080,8443"}, "reason": "检测Web服务端口"},
                        {"action": "fingerprint", "params": {"tool": "http_headers"}, "reason": "识别Web技术栈"},
                        {"action": "directory_scan", "params": {}, "reason": "发现隐藏路径"}
                    ],
                    "priority": "high",
                    "estimated_time": "180"
                }, ensure_ascii=False)
            else:
                return json.dumps({
                    "strategy": "基础设施扫描策略",
                    "steps": [
                        {"action": "port_scan", "params": {"tool": "auto", "ports": "1-1000"}, "reason": "全面端口扫描"},
                        {"action": "service_detect", "params": {}, "reason": "服务版本检测"}
                    ],
                    "priority": "high",
                    "estimated_time": "300"
                }, ensure_ascii=False)

        elif "评估" in prompt or "结果" in prompt:
            return json.dumps({
                "key_findings": ["执行完成，请查看结果详情"],
                "security_issues": [],
                "confidence": 0.6,
                "needs_verification": True,
                "verification_suggestions": ["建议启用AI服务获取更精准的评估"]
            }, ensure_ascii=False)

        elif "决定下一步" in prompt or "下一步" in prompt:
            return json.dumps({
                "next_agents": [
                    {"agent": "vuln_scanner", "params": {}, "priority": "high", "reason": "信息收集后应进行漏洞扫描"}
                ],
                "stop_if": "发现高危漏洞",
                "fallback": "执行完整扫描"
            }, ensure_ascii=False)

        return json.dumps({"status": "默认响应", "message": "请启用AI服务获取智能决策"}, ensure_ascii=False)

    def _ai_chat_with_timeout(self, prompt: str, timeout: int = 60) -> str:
        """AI 调用带超时保护"""
        import threading
        result = [None]
        error = [None]

        def _call():
            try:
                result[0] = self.ask_ai(prompt)
            except Exception as e:
                error[0] = e

        t = threading.Thread(target=_call, daemon=True)
        t.start()
        t.join(timeout=timeout)
        if t.is_alive():
            self.logger.warning(f"AI 调用超时 ({timeout}s)")
            return json.dumps({"error": "AI调用超时"}, ensure_ascii=False)
        if error[0]:
            raise error[0]
        return result[0] or ""

    def _parse_json_response(self, response: str) -> Dict:
        """解析JSON响应 — 委托给公共函数"""
        return parse_json_response(response)

    def _extract_context(self, results: List, evaluation: Dict = None) -> Dict:
        """从结果中提取上下文更新 — 深度提取端口/漏洞/技术/子域名"""
        context_updates = {
            'agent': self.name,
            'timestamp': time.time(),
            'findings': [],
            'vulnerabilities': [],
            'services': [],
            'technologies': [],
            'subdomains': []
        }

        # 从结果中提取
        for result in results:
            if isinstance(result, dict):
                result_data = result.get('result', {})
                if not isinstance(result_data, dict):
                    continue

                # 端口信息
                for port_info in result_data.get('ports', []):
                    context_updates['services'].append(port_info)

                # 子域名信息
                if 'subdomains' in result_data:
                    for sub_info in result_data['subdomains']:
                        context_updates['subdomains'].append(sub_info)

                # 技术栈信息
                if 'technologies' in result_data:
                    for tech in result_data['technologies']:
                        context_updates['technologies'].append(
                            {'name': tech} if isinstance(tech, str) else tech
                        )
                if result_data.get('server'):
                    context_updates['technologies'].append(
                        {'name': result_data['server'], 'type': 'web_server'}
                    )

                # 漏洞信息
                vulns = result_data.get('vulnerabilities', {})
                if isinstance(vulns, dict):
                    for severity, vuln_list in vulns.items():
                        if isinstance(vuln_list, list):
                            for v in vuln_list:
                                if isinstance(v, dict):
                                    v['severity'] = severity
                                    context_updates['vulnerabilities'].append(v)
                elif isinstance(vulns, list):
                    for v in vulns:
                        if isinstance(v, dict):
                            context_updates['vulnerabilities'].append(v)

                # CVE信息
                for cve in result_data.get('cves', []):
                    if isinstance(cve, dict):
                        context_updates['vulnerabilities'].append(cve)

                # SSL信息
                for issue in result_data.get('issues', []):
                    if isinstance(issue, dict):
                        context_updates['vulnerabilities'].append(issue)

                # 路径/目录信息
                for path_info in result_data.get('found_paths', []):
                    if isinstance(path_info, dict):
                        context_updates['findings'].append({
                            'type': 'path_discovery',
                            'path': path_info.get('path', ''),
                            'status': path_info.get('status', 0)
                        })

                # 通用发现
                if 'findings' in result_data:
                    context_updates['findings'].extend(result_data['findings'])

        # 从评估中提取
        if evaluation:
            for finding in evaluation.get('key_findings', []):
                if isinstance(finding, str):
                    context_updates['findings'].append({
                        'type': 'ai_finding',
                        'description': finding
                    })
                elif isinstance(finding, dict):
                    context_updates['findings'].append(finding)
            for issue in evaluation.get('security_issues', []):
                if isinstance(issue, dict):
                    context_updates['vulnerabilities'].append(issue)

        return context_updates
