# agents/shared_memory.py
# Agent间共享上下文 - 支持发布-订阅模式的信息传递
import asyncio
import logging
import time
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger(__name__)


class SharedMemory:
    """共享内存 - Agent之间共享信息

    功能:
    1. 全局上下文管理：所有Agent共享发现、漏洞、攻击面等数据
    2. 发布-订阅模式：Agent发现新信息时自动通知相关Agent
    3. 线程安全：异步锁保护共享数据
    4. 执行历史：记录所有Agent的执行结果
    """

    def __init__(self):
        self._lock = asyncio.Lock()
        self._context: Dict[str, Any] = {
            'findings': [],
            'vulnerabilities': [],
            'attack_surface': {},
            'services': {},
            'technologies': [],
            'credentials': [],
            'execution_history': [],
            'key_findings': [],
            'config_issues': [],
        }
        self._subscribers: Dict[str, List[Callable]] = defaultdict(list)
        self._agent_results: Dict[str, List[Dict]] = defaultdict(list)
        self._statistics = {
            'total_findings': 0,
            'total_vulnerabilities': 0,
            'agents_executed': 0,
            'start_time': None,
            'phases_completed': 0,
        }

    async def add_finding(self, agent_name: str, finding: Dict) -> None:
        """添加发现

        Args:
            agent_name: 发现该信息的Agent名称
            finding: 发现内容字典
        """
        async with self._lock:
            finding['discovered_by'] = agent_name
            finding['timestamp'] = time.time()
            finding['datetime'] = datetime.now().isoformat()

            self._context['findings'].append(finding)
            self._statistics['total_findings'] += 1

            # 自动分类
            self._classify_finding(finding)

        # 通知订阅者（在锁外执行，避免死锁）
        await self._notify_subscribers('finding', finding)

        logger.debug(f"[SharedMemory] {agent_name} 添加发现: "
                      f"{finding.get('type', 'unknown')}")

    async def add_vulnerability(self, agent_name: str, vulnerability: Dict) -> None:
        """添加漏洞

        Args:
            agent_name: 发现该漏洞的Agent名称
            vulnerability: 漏洞内容字典
        """
        async with self._lock:
            vulnerability['discovered_by'] = agent_name
            vulnerability['timestamp'] = time.time()
            vulnerability['datetime'] = datetime.now().isoformat()

            self._context['vulnerabilities'].append(vulnerability)
            self._statistics['total_vulnerabilities'] += 1

            # 关键漏洞添加到key_findings
            severity = vulnerability.get('severity', 'info')
            if severity in ('critical', 'high'):
                self._context['key_findings'].append(vulnerability)

        # 通知订阅者（高危漏洞立即通知）
        await self._notify_subscribers('vulnerability', vulnerability)

        logger.info(f"[SharedMemory] {agent_name} 发现漏洞: "
                     f"severity={severity}, type={vulnerability.get('type', 'unknown')}")

    async def add_service(self, agent_name: str, service_info: Dict) -> None:
        """添加服务信息

        Args:
            agent_name: 发现该服务的Agent名称
            service_info: 服务信息字典（包含port, service, banner等）
        """
        async with self._lock:
            service_info['discovered_by'] = agent_name
            service_info['timestamp'] = time.time()

            port = str(service_info.get('port', 'unknown'))
            self._context['services'][port] = service_info

            # 更新攻击面
            self._update_attack_surface(service_info)

        await self._notify_subscribers('service', service_info)

        logger.debug(f"[SharedMemory] {agent_name} 发现服务: "
                      f"port={port}, service={service_info.get('service', 'unknown')}")

    async def add_technology(self, agent_name: str, tech_info: Dict) -> None:
        """添加技术栈信息

        Args:
            agent_name: 发现该技术的Agent名称
            tech_info: 技术信息字典
        """
        async with self._lock:
            tech_info['discovered_by'] = agent_name
            tech_info['timestamp'] = time.time()
            self._context['technologies'].append(tech_info)

        await self._notify_subscribers('technology', tech_info)

    async def add_credential(self, agent_name: str, credential: Dict) -> None:
        """添加凭据信息

        Args:
            agent_name: 发现该凭据的Agent名称
            credential: 凭据信息
        """
        async with self._lock:
            credential['discovered_by'] = agent_name
            credential['timestamp'] = time.time()
            self._context['credentials'].append(credential)

        await self._notify_subscribers('credential', credential)

        logger.info(f"[SharedMemory] {agent_name} 发现凭据: "
                     f"type={credential.get('type', 'unknown')}")

    async def add_agent_result(self, agent_name: str, result: Dict) -> None:
        """添加Agent执行结果

        Args:
            agent_name: Agent名称
            result: 执行结果字典
        """
        async with self._lock:
            result['timestamp'] = time.time()
            self._agent_results[agent_name].append(result)
            self._statistics['agents_executed'] += 1

            # 记录到执行历史
            self._context['execution_history'].append({
                'agent': agent_name,
                'timestamp': time.time(),
                'datetime': datetime.now().isoformat(),
                'result_summary': {
                    'status': result.get('status', 'unknown'),
                    'findings_count': len(result.get('findings', [])),
                }
            })

    async def get_context(self) -> Dict:
        """获取当前全局上下文（深拷贝，隔离修改）"""
        import copy
        async with self._lock:
            return copy.deepcopy(self._context)

    async def get_findings(self, agent_filter: str = None) -> List[Dict]:
        """获取发现列表

        Args:
            agent_filter: 只获取指定Agent的发现（可选）

        Returns:
            发现列表
        """
        async with self._lock:
            if agent_filter:
                return [f for f in self._context['findings']
                        if f.get('discovered_by') == agent_filter]
            return list(self._context['findings'])

    async def get_vulnerabilities(self, severity_filter: str = None) -> List[Dict]:
        """获取漏洞列表

        Args:
            severity_filter: 只获取指定严重程度的漏洞（可选）

        Returns:
            漏洞列表
        """
        async with self._lock:
            vulns = list(self._context['vulnerabilities'])
            if severity_filter:
                return [v for v in vulns
                        if v.get('severity') == severity_filter]
            return vulns

    async def get_services(self) -> Dict:
        """获取服务信息"""
        async with self._lock:
            return dict(self._context['services'])

    async def get_attack_surface(self) -> Dict:
        """获取攻击面信息"""
        async with self._lock:
            return dict(self._context['attack_surface'])

    async def get_agent_results(self, agent_name: str = None) -> Dict:
        """获取Agent执行结果"""
        async with self._lock:
            if agent_name:
                return {agent_name: list(self._agent_results.get(agent_name, []))}
            return dict(self._agent_results)

    async def get_statistics(self) -> Dict:
        """获取统计信息"""
        async with self._lock:
            stats = dict(self._statistics)
            if stats['start_time']:
                stats['elapsed_time'] = time.time() - stats['start_time']
            return stats

    async def update_from_agent_output(self, agent_name: str,
                                        output: Dict) -> None:
        """从Agent输出中批量更新上下文

        智能解析Agent的输出，自动提取发现、漏洞、服务等信息

        Args:
            agent_name: Agent名称
            output: Agent执行输出
        """
        # 提取上下文更新
        context_updates = output.get('context_updates', {})

        # 添加发现
        for finding in context_updates.get('findings', []):
            if isinstance(finding, dict):
                await self.add_finding(agent_name, finding)

        # 添加漏洞
        for vuln in context_updates.get('vulnerabilities', []):
            if isinstance(vuln, dict):
                await self.add_vulnerability(agent_name, vuln)

        # 添加服务
        for service in context_updates.get('services', []):
            if isinstance(service, dict):
                await self.add_service(agent_name, service)

        # 添加技术栈
        for tech in context_updates.get('technologies', []):
            if isinstance(tech, dict):
                await self.add_technology(agent_name, tech)
            elif isinstance(tech, str):
                await self.add_technology(agent_name, {'name': tech})

        # 添加子域名（记录为finding）
        for sub in context_updates.get('subdomains', []):
            if isinstance(sub, dict):
                await self.add_finding(agent_name, {
                    'type': 'subdomain',
                    'subdomain': sub.get('subdomain', ''),
                    'ip': sub.get('ip', ''),
                })

        # 评估结果中的漏洞
        evaluation = output.get('evaluation', {})
        if isinstance(evaluation, dict):
            for issue in evaluation.get('security_issues', []):
                if isinstance(issue, dict):
                    await self.add_vulnerability(agent_name, issue)

            for finding in evaluation.get('key_findings', []):
                if isinstance(finding, dict):
                    await self.add_finding(agent_name, finding)
                elif isinstance(finding, str):
                    await self.add_finding(agent_name, {
                        'type': 'key_finding',
                        'description': finding
                    })

        # 直接结果中的漏洞
        results = output.get('results', [])
        if isinstance(results, list):
            for result in results:
                if isinstance(result, dict):
                    result_data = result.get('result', {})
                    if isinstance(result_data, dict):
                        # 端口信息
                        for port_info in result_data.get('ports', []):
                            await self.add_service(agent_name, port_info)

        # 记录Agent结果
        await self.add_agent_result(agent_name, output)

    def subscribe(self, event_type: str, callback: Callable) -> None:
        """订阅事件

        Args:
            event_type: 事件类型（'finding', 'vulnerability', 'service', 'technology', 'credential'）
            callback: 回调函数，接收(event_type, data)参数
        """
        self._subscribers[event_type].append(callback)
        logger.debug(f"[SharedMemory] 订阅事件: {event_type}")

    def unsubscribe(self, event_type: str, callback: Callable) -> None:
        """取消订阅"""
        if callback in self._subscribers.get(event_type, []):
            self._subscribers[event_type].remove(callback)

    async def _notify_subscribers(self, event_type: str, data: Dict) -> None:
        """通知订阅者"""
        for callback in self._subscribers.get(event_type, []):
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(event_type, data)
                else:
                    callback(event_type, data)
            except Exception as e:
                logger.warning(f"[SharedMemory] 通知订阅者失败: {e}")

    def _classify_finding(self, finding: Dict) -> None:
        """自动分类发现"""
        finding_type = finding.get('type', '').lower()

        if 'sql' in finding_type or 'sqli' in finding_type:
            finding['_category'] = 'injection'
        elif 'xss' in finding_type:
            finding['_category'] = 'injection'
        elif 'config' in finding_type or 'misconfig' in finding_type:
            self._context['config_issues'].append(finding)
        elif 'port' in finding_type or 'service' in finding_type:
            finding['_category'] = 'service'

    def _update_attack_surface(self, service_info: Dict) -> None:
        """根据新发现的服务更新攻击面"""
        port = service_info.get('port', '')
        service = service_info.get('service', '').lower()

        attack_entry = {
            'port': port,
            'service': service,
            'potential_attacks': []
        }

        # 基于服务类型推荐攻击面
        attack_map = {
            'http': ['web_fingerprint', 'directory_scan', 'sqli_test', 'xss_test'],
            'https': ['ssl_scan', 'web_fingerprint', 'directory_scan'],
            'ssh': ['brute_force', 'banner_grab', 'auth_test'],
            'ftp': ['anonymous_test', 'brute_force', 'banner_grab'],
            'mysql': ['brute_force', 'sql_injection', 'unauth_test'],
            'redis': ['unauth_test', 'info_leak'],
            'mongodb': ['unauth_test', 'info_leak'],
            'rdp': ['brute_force', 'bluekeep_check'],
            'smtp': ['open_relay_test', 'user_enum'],
            'dns': ['zone_transfer', 'dns_cache_poison'],
            'smb': ['smb_vuln_scan', 'null_session_test'],
        }

        for keyword, attacks in attack_map.items():
            if keyword in service:
                attack_entry['potential_attacks'] = attacks
                break

        if attack_entry['potential_attacks']:
            self._context['attack_surface'][port] = attack_entry

    def start_timer(self) -> None:
        """启动计时器"""
        self._statistics['start_time'] = time.time()

    def increment_phase(self) -> None:
        """增加已完成阶段计数"""
        self._statistics['phases_completed'] += 1

    def get_summary(self) -> Dict:
        """获取上下文摘要（用于AI决策）— 同步方法，读取原子数据无需锁"""
        # 所有读取操作都是原子的（len(), 列表推导），无需加锁
        return {
            'total_findings': len(self._context['findings']),
            'total_vulnerabilities': len(self._context['vulnerabilities']),
            'critical_vulns': len([v for v in self._context['vulnerabilities']
                                    if v.get('severity') == 'critical']),
            'high_vulns': len([v for v in self._context['vulnerabilities']
                                if v.get('severity') == 'high']),
            'discovered_services': len(self._context['services']),
            'technologies': [t.get('name', str(t))
                             for t in self._context['technologies'][:10]],
            'attack_surface_size': len(self._context['attack_surface']),
            'elapsed_time': (time.time() - self._statistics['start_time']
                             if self._statistics['start_time'] else 0),
            'phases_completed': self._statistics['phases_completed'],
            'key_findings': self._context['key_findings'][:5],
        }
