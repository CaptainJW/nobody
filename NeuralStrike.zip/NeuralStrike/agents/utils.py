# agents/utils.py
# Agent公共工具函数 — 消除各模块间的重复实现
import json
import re
import logging
from typing import Dict, Any, Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


def parse_url_target(target: str) -> dict:
    """解析目标URL，提取 hostname / port / path / query 等信息。

    支持格式:
      - http://ctf.eagleslab.com:41138/vul/sqli/sqli_str.php?name=lili&submit=查询
      - https://example.com/path
      - example.com
      - 192.168.1.1

    Returns:
        dict: {
            'original': 原始输入,
            'scheme': 'http' 或 'https',
            'hostname': 主机名/IP,
            'port': 端口号(整数),
            'path': 路径(含查询字符串),
            'full_url': 完整URL(如果没有scheme则补http://),
            'host_for_nmap': nmap可用的目标(hostname, 不含端口路径),
            'is_url': 是否为完整URL(含路径/查询参数)
        }
    """
    original = target.strip()

    # 补全 scheme
    if not original.startswith(('http://', 'https://')):
        url_to_parse = 'http://' + original
    else:
        url_to_parse = original

    try:
        parsed = urlparse(url_to_parse)
        scheme = parsed.scheme or 'http'
        hostname = parsed.hostname or original
        port = parsed.port
        path = parsed.path or ''
        query = parsed.query or ''

        # 默认端口
        if port is None:
            port = 443 if scheme == 'https' else 80

        full_path = path
        if query:
            full_path += '?' + query

        # 重构完整URL
        full_url = f'{scheme}://{hostname}:{port}{full_path}'

        # nmap/masscan 只接受 hostname 或 IP，不接受URL
        host_for_nmap = hostname

        is_url = bool(path and path != '/')

        return {
            'original': original,
            'scheme': scheme,
            'hostname': hostname,
            'port': port,
            'path': full_path,
            'full_url': full_url,
            'host_for_nmap': host_for_nmap,
            'is_url': is_url,
        }
    except Exception:
        # 解析失败，返回基本结构
        return {
            'original': original,
            'scheme': 'http',
            'hostname': original.split('/')[0].split(':')[0],
            'port': 80,
            'path': '/',
            'full_url': original if original.startswith('http') else f'http://{original}',
            'host_for_nmap': original.split('/')[0].split(':')[0],
            'is_url': '/' in original.split('://')[-1] if '://' in original else '/' in original,
        }


def parse_json_response(response: str) -> Dict:
    """解析JSON响应 — 支持多种格式的AI返回

    尝试顺序:
    1. 直接解析纯JSON
    2. 从Markdown代码块 ```json ... ``` 中提取
    3. 查找最外层 { } 
    4. 全部失败返回空字典

    此函数替代 base_agent.py / workflow_orchestrator.py / ai_manager.py 中的重复实现。
    """
    if not response:
        return {}

    # 尝试1: 直接解析
    try:
        result = json.loads(response)
        if isinstance(result, dict):
            return result
    except (json.JSONDecodeError, TypeError):
        pass

    # 尝试2: 从Markdown代码块中提取
    json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', response, re.DOTALL)
    if json_match:
        try:
            result = json.loads(json_match.group(1))
            if isinstance(result, dict):
                return result
        except json.JSONDecodeError:
            pass

    # 尝试3: 查找最外层的 { }
    brace_match = re.search(r'\{.*\}', response, re.DOTALL)
    if brace_match:
        try:
            result = json.loads(brace_match.group(0))
            if isinstance(result, dict):
                return result
        except json.JSONDecodeError:
            pass

    # 解析失败
    logger.warning("JSON解析失败，返回空字典。响应前100字: %s", response[:100])
    return {}


def sanitize_output(text: str) -> str:
    """消毒输出文本 — 防止XSS

    移除可能被执行的HTML/JS标签，保留安全文本用于GUI显示。
    """
    if not text:
        return ""
    # 移除<script>标签
    text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.IGNORECASE | re.DOTALL)
    # 移除事件处理器
    text = re.sub(r'\s*on\w+\s*=\s*["\'][^"\']*["\']', '', text, flags=re.IGNORECASE)
    # 转义剩余HTML
    text = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    return text


def mask_api_key(api_key: str) -> str:
    """脱敏API密钥 — 日志和GUI显示时使用

    >>> mask_api_key("sk-abc123456789xyz")
    'sk-a********xyz'
    """
    if not api_key or len(api_key) <= 8:
        return "****"
    return api_key[:4] + "*" * (len(api_key) - 8) + api_key[-4:]


def validate_config_value(key: str, value: Any, expected_type: type, default: Any = None) -> Any:
    """校验配置值类型

    >>> validate_config_value("port", "abc", int, 8888)
    8888
    >>> validate_config_value("port", 9090, int, 8888)
    9090
    """
    if isinstance(value, expected_type):
        return value
    logger.warning("配置项 '%s' 类型错误: 期望 %s, 实际 %s, 使用默认值 %s",
                   key, expected_type.__name__, type(value).__name__, default)
    return default
