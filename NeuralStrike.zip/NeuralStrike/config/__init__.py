"""
AI 配置模块
"""

try:
    from .ai_manager import AIConfigManager
except ImportError:
    AIConfigManager = None
