# config/ai_manager.py
import json
import os
import logging
from typing import Dict, Any, List
from datetime import datetime

logger = logging.getLogger(__name__)


class AIConfigManager:
    """AI配置管理器"""

    def __init__(self, config_file: str = None):
        if config_file is None:
            config_file = os.path.join(os.path.dirname(__file__), 'ai_config.json')
        self.config_file = config_file
        self.config = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                # 创建默认配置
                default_config = {
                    "default_provider": "openai",
                    "providers": {
                        "openai": {
                            "api_key": "your-openai-api-key-here",
                            "model": "gpt-3.5-turbo",
                            "base_url": "https://api.openai.com/v1"
                        }
                    },
                    "orchestrator": {
                        "max_execution_time": 3600,
                        "agent_timeout": 300,
                        "retry_attempts": 3
                    }
                }
                self._save_config(default_config)
                return default_config
        except Exception as e:
            logger.error(f"加载AI配置失败: {e}")
            return {}

    def _save_config(self, config: Dict[str, Any]):
        """保存配置文件"""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"保存AI配置失败: {e}")

    def get_active_provider(self) -> str:
        """获取当前可用的供应商：优先默认，否则第一个有key的"""
        default = self.config.get('default_provider', 'openai')
        if self._is_provider_configured(default):
            return default
        for pid in self.config.get('providers', {}):
            if self._is_provider_configured(pid):
                return pid
        return default

    def _is_provider_configured(self, provider_name: str) -> bool:
        """检查指定供应商是否已配置有效密钥"""
        api_key = self.config.get('providers', {}).get(provider_name, {}).get('api_key', '')
        return bool(api_key and api_key.strip()
                     and not api_key.startswith('your-')
                     and not api_key.startswith('sk-your'))

    def get_ai_config(self) -> Dict[str, Any]:
        """获取AI配置（自动找到有key的供应商）"""
        provider_name = self.get_active_provider()
        provider_config = self.config.get('providers', {}).get(provider_name, {})

        return {
            'provider': provider_name,
            'config': provider_config,
            'orchestrator': self.config.get('orchestrator', {})
        }

    def update_provider_config(self, provider_name: str, config: Dict[str, Any]):
        """更新提供者配置"""
        if 'providers' not in self.config:
            self.config['providers'] = {}
        self.config['providers'][provider_name] = config
        self._save_config(self.config)

    def set_default_provider(self, provider_name: str):
        """设置默认提供者"""
        self.config['default_provider'] = provider_name
        self._save_config(self.config)

    def get_orchestrator_config(self) -> Dict[str, Any]:
        """获取编排器配置"""
        return self.config.get('orchestrator', {})

    # ===== 兼容 agent_gui.py 的便捷方法 =====

    def get_config(self) -> Dict[str, Any]:
        """获取AI配置（兼容接口）"""
        return self.get_ai_config()

    def get_provider(self) -> str:
        """获取当前可用的服务商名（自动找到有key的）"""
        return self.get_active_provider()

    def get_api_key(self) -> str:
        """获取当前可用服务商的API密钥"""
        provider_name = self.get_active_provider()
        return self.config.get('providers', {}).get(provider_name, {}).get('api_key', '')

    def is_configured(self) -> bool:
        """检查AI服务是否已正确配置（检查所有供应商，不仅看默认）"""
        # 先检查默认
        if self._is_provider_configured(self.get_provider()):
            return True
        # 再检查所有供应商
        for pid in self.config.get('providers', {}):
            if self._is_provider_configured(pid):
                return True
        return False

    def get_agents_config(self) -> Dict[str, Any]:
        """获取Agent配置"""
        return self.config.get('agents', {})

    def get_workspace(self) -> str:
        """获取工作空间路径"""
        return self.config.get('workspace', 'pentest_results')

    # ===== 供应商注册表接口 =====

    @staticmethod
    def get_provider_registry() -> Dict[str, Any]:
        """获取供应商注册表"""
        try:
            from agents.ai_client import PROVIDER_REGISTRY
            return PROVIDER_REGISTRY
        except ImportError:
            logger.warning("无法导入PROVIDER_REGISTRY，返回空字典")
            return {}

    @staticmethod
    def get_provider_list() -> List[Dict[str, str]]:
        """获取供应商列表（供GUI下拉框使用）"""
        registry = AIConfigManager.get_provider_registry()
        result = []
        for key, info in registry.items():
            result.append({
                'id': key,
                'name': info.get('name', key),
                'icon': info.get('icon', '⚪'),
                'description': info.get('description', ''),
            })
        return result

    def get_provider_models(self, provider_name: str) -> List[str]:
        """获取指定供应商的模型列表"""
        registry = self.get_provider_registry()
        provider_info = registry.get(provider_name, {})
        return provider_info.get('models', [])

    def get_provider_defaults(self, provider_name: str) -> Dict[str, Any]:
        """获取指定供应商的默认配置"""
        registry = self.get_provider_registry()
        provider_info = registry.get(provider_name, {})
        return {
            'base_url': provider_info.get('default_base_url', ''),
            'model': provider_info.get('default_model', ''),
        }

    def save_provider(self, provider_name: str, api_key: str = None,
                      model: str = None, base_url: str = None,
                      temperature: float = None, max_tokens: int = None):
        """保存指定供应商的配置"""
        if 'providers' not in self.config:
            self.config['providers'] = {}

        if provider_name not in self.config['providers']:
            self.config['providers'][provider_name] = {}

        provider = self.config['providers'][provider_name]

        if api_key is not None:
            provider['api_key'] = api_key
        if model is not None:
            provider['model'] = model
        if base_url is not None:
            provider['base_url'] = base_url
        if temperature is not None:
            provider['temperature'] = temperature
        if max_tokens is not None:
            provider['max_tokens'] = max_tokens

        self._save_config(self.config)
        logger.info(f"供应商 {provider_name} 配置已保存")

    def test_connection(self, provider_name: str = None) -> Dict[str, Any]:
        """测试AI服务连接"""
        try:
            import requests as req
        except ImportError:
            return {
                'success': False,
                'message': '缺少 requests 库，请安装: pip install requests',
                'provider': provider_name or self.get_provider(),
            }

        if provider_name is None:
            provider_name = self.get_provider()

        provider_config = self.config.get('providers', {}).get(provider_name, {})
        api_key = provider_config.get('api_key', '')

        if not api_key or api_key.startswith('your-') or api_key.startswith('sk-your'):
            return {
                'success': False,
                'message': f'供应商 {provider_name} 的API密钥未配置',
                'provider': provider_name,
            }

        # 从注册表获取基本信息
        registry = self.get_provider_registry()
        provider_info = registry.get(provider_name, {})
        base_url = provider_config.get('base_url', provider_info.get('default_base_url', ''))
        model = provider_config.get('model', provider_info.get('default_model', ''))

        # 构建测试请求
        try:
            # OpenAI兼容接口测试
            headers = {
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json'
            }
            # Claude使用不同的header
            if provider_name == 'claude':
                headers = {
                    'x-api-key': api_key,
                    'anthropic-version': '2023-06-01',
                    'Content-Type': 'application/json'
                }
                test_data = {
                    'model': model,
                    'max_tokens': 10,
                    'messages': [{'role': 'user', 'content': 'Hi'}]
                }
                test_url = f"{base_url}/messages"
            else:
                test_data = {
                    'model': model,
                    'messages': [{'role': 'user', 'content': 'Hi'}],
                    'max_tokens': 10,
                }
                test_url = f"{base_url}/chat/completions"

            start_time = datetime.now()
            response = req.post(test_url, headers=headers, json=test_data, timeout=30)
            elapsed = (datetime.now() - start_time).total_seconds()

            if response.status_code == 200:
                return {
                    'success': True,
                    'message': f'连接成功！延迟: {elapsed:.2f}s',
                    'provider': provider_name,
                    'model': model,
                    'latency': elapsed,
                }
            elif response.status_code == 401:
                return {
                    'success': False,
                    'message': 'API密钥无效或已过期',
                    'provider': provider_name,
                }
            elif response.status_code == 429:
                return {
                    'success': False,
                    'message': 'API调用频率超限，请稍后重试',
                    'provider': provider_name,
                }
            else:
                return {
                    'success': False,
                    'message': f'HTTP {response.status_code}: {response.text[:200]}',
                    'provider': provider_name,
                }

        except req.exceptions.Timeout:
            return {
                'success': False,
                'message': '连接超时（30秒），请检查网络或base_url',
                'provider': provider_name,
            }
        except req.exceptions.ConnectionError:
            return {
                'success': False,
                'message': f'无法连接到 {base_url}，请检查网络或base_url',
                'provider': provider_name,
            }
        except Exception as e:
            return {
                'success': False,
                'message': f'连接测试失败: {str(e)}',
                'provider': provider_name,
            }

    def get_all_provider_status(self) -> Dict[str, Dict[str, Any]]:
        """获取所有供应商的配置状态"""
        registry = self.get_provider_registry()
        result = {}

        for provider_id, provider_info in registry.items():
            provider_config = self.config.get('providers', {}).get(provider_id, {})
            api_key = provider_config.get('api_key', '')
            is_configured = bool(api_key and not api_key.startswith('your-') and not api_key.startswith('sk-your'))
            is_default = (provider_id == self.get_provider())

            result[provider_id] = {
                'name': provider_info.get('name', provider_id),
                'icon': provider_info.get('icon', '⚪'),
                'description': provider_info.get('description', ''),
                'is_configured': is_configured,
                'is_default': is_default,
                'model': provider_config.get('model', provider_info.get('default_model', '')),
                'base_url': provider_config.get('base_url', provider_info.get('default_base_url', '')),
            }

        return result