"""
Core模块初始化文件
导出所有需要的函数
"""

# 尝试从hexstrike_mcp导入函数
try:
    from .hexstrike_mcp import (
        HexStrikeClient,
        HexStrikeColors,
        analyze_memory,
        analyze_network,
        analyze_process,
        scan_ports,
        get_system_info
    )
    print("✓ 成功从hexstrike_mcp导入系统分析函数")
except ImportError as e:
    print(f"✗ 从hexstrike_mcp导入失败: {e}")

    # 尝试导入基本MCP函数
    try:
        from .hexstrike_mcp import HexStrikeClient, HexStrikeColors
    except:
        HexStrikeClient = None
        HexStrikeColors = None

    # 创建占位函数（如果从hexstrike_mcp导入失败）
    def analyze_memory(pid=None):
        return {"status": "error", "error": "功能未实现"}

    def analyze_network(interface=None):
        return {"status": "error", "error": "功能未实现"}

    def analyze_process(pid=None):
        return {"status": "error", "error": "功能未实现"}

    def scan_ports(host="127.0.0.1", start_port=1, end_port=1024):
        return {"status": "error", "error": "功能未实现"}

    def get_system_info():
        return {"status": "error", "error": "功能未实现"}

# 尝试从hexstrike_server导入函数
try:
    from .hexstrike_server import start_server, stop_server, get_server_status
    print("✓ 成功导入服务器函数")
except ImportError as e:
    print(f"✗ 导入服务器函数失败: {e}")

    def start_server():
        return {"success": False, "error": "服务器模块未找到"}

    def stop_server():
        return {"success": False, "error": "服务器模块未找到"}

    def get_server_status():
        return {"status": "not_found", "error": "服务器模块未找到"}

# 定义所有导出的符号
__all__ = [
    'HexStrikeClient',
    'HexStrikeColors',
    'analyze_memory',
    'analyze_network',
    'analyze_process',
    'scan_ports',
    'get_system_info',
    'start_server',
    'stop_server',
    'get_server_status'
]

print("✓ Core模块初始化完成")