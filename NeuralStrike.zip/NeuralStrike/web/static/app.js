/**
 * NeuralStrike AI — app.js
 * 多会话管理 + AI思考为主展示 + 工具调用实时展示 + 报告常驻 + 独立AI对话
 */
'use strict';

// ═══ 全局状态 ═══
const state = {
  currentTab: 'thinking',
  currentProvider: 'siliconflow',
  selectedModel: null,
  scanning: false,
  providers: {},
  config: {},
  toolsData: {},
  // 多会话管理
  sessions: {},        // sessionId -> { scanId, target, status, thinking: [], tools: [], stats, scanFinished }
  activeSession: null, // 当前激活的sessionId
  eventSource: null,
};

let sessionCounter = 0;

// ═══ AI 思考类型配置 ═══
const THINK_COLORS = {
  analyze: '#58a6ff', plan: '#d2a8ff', action: '#3fb950',
  evaluate: '#f0883e', decide: '#f778ba',
  tool:    '#ff9900', command: '#80ff60', result: '#60c0ff',
  error:   '#ff4444', info: '#ede8b0',
};
const THINK_ICONS = {
  analyze: '🧩', plan: '📋', action: '⚡',
  evaluate: '🔍', decide: '➡️',
  tool: '🔧', command: '💻', result: '📤',
  error: '❌', info: 'ℹ️',
};
const THINK_LABELS = {
  analyze: '分析', plan: '规划', action: '执行',
  evaluate: '评估', decide: '决策',
  tool: '工具调用', command: '命令执行', result: '结果输出',
  error: '错误', info: '信息',
};

const TARGET_RE = /^(https?:\/\/)?(([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}|\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(:\d{1,5})?(\/[^\s]*)?(\?[^\s]*)?$/;
const DANGEROUS_CHARS = new Set([';', '|', '`', '$', '\n', '\r']);

// ═══ 工具函数 ═══
function $(id) { return document.getElementById(id); }
function now() { return new Date().toTimeString().slice(0, 8); }
function escHtml(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

function appendEl(parent, html) {
  const d = document.createElement('div');
  d.innerHTML = html;
  parent.appendChild(d);
  parent.scrollTop = parent.scrollHeight;
}

// ═══ 会话管理 ═══
function createSession(target) {
  const sid = 'sess_' + (++sessionCounter) + '_' + Date.now();
  state.sessions[sid] = {
    scanId: null, target, status: 'idle',
    thinking: [], tools: [], phaseHtml: '',
    stats: { ports: 0, subdomains: 0, vulns: 0, paths: 0 },
    scanFinished: false,
  };
  state.activeSession = sid;
  renderSessionList();
  clearThinkingUI();
  return sid;
}

function switchSession(sid) {
  if (!state.sessions[sid]) return;
  // 先保存当前会话
  saveCurrentSession();
  // 关闭当前SSE
  if (state.eventSource) { state.eventSource.close(); state.eventSource = null; }
  // 切换
  state.activeSession = sid;
  const sess = state.sessions[sid];
  // 恢复UI
  restoreSessionUI(sess);
  renderSessionList();
  // 如果正在扫描，重新连接SSE
  if (sess.scanId && sess.status === 'running') {
    state.scanning = true;
    connectSSE(sess.scanId);
  } else {
    state.scanning = false;
  }
  updateSessionUI();
}

function saveCurrentSession() {
  const sid = state.activeSession;
  if (!sid || !state.sessions[sid]) return;
  const sess = state.sessions[sid];
  sess.thinking = $('thinking-stream').innerHTML;
  sess.tools = $('tool-calls').innerHTML;
  sess.phaseHtml = $('phase-steps').innerHTML;
  sess.stats = { ...state.stats };
}

function restoreSessionUI(sess) {
  $('thinking-stream').innerHTML = sess.thinking || '';
  $('tool-calls').innerHTML = sess.tools || '';
  $('phase-steps').innerHTML = sess.phaseHtml || '';
  state.stats = { ...(sess.stats || { ports:0, subdomains:0, vulns:0, paths:0 }) };
  ['qs-ports','qs-subdomains','qs-vulns','qs-paths'].forEach(id => { if ($(id)) $(id).textContent = state.stats[id.replace('qs-','')] || 0; });
}

function deleteSession(sid, ev) {
  if (ev) ev.stopPropagation();
  const sess = state.sessions[sid];
  if (sess && sess.scanId) {
    fetch(`/api/scan/${sess.scanId}`, { method: 'DELETE' }).catch(() => {});
  }
  delete state.sessions[sid];
  if (state.activeSession === sid) {
    const keys = Object.keys(state.sessions);
    if (keys.length) {
      switchSession(keys[keys.length - 1]);
    } else {
      state.activeSession = null;
      clearThinkingUI();
      state.scanning = false;
    }
  }
  renderSessionList();
}

function renderSessionList() {
  const list = $('session-list');
  list.innerHTML = '';
  Object.entries(state.sessions).forEach(([sid, sess]) => {
    const isActive = (sid === state.activeSession);
    const statusIcon = sess.status === 'running' ? '🟢' : sess.scanFinished ? '✅' : '⬜';
    const targetShort = (sess.target || '新对话').length > 18 ? sess.target.slice(0, 18) + '...' : (sess.target || '新对话');
    const item = document.createElement('div');
    item.className = 'session-item' + (isActive ? ' active' : '');
    item.innerHTML = `<span class="session-status">${statusIcon}</span><span class="session-target">${escHtml(targetShort)}</span><button class="session-del" title="关闭">×</button>`;
    item.querySelector('.session-del').addEventListener('click', (e) => deleteSession(sid, e));
    item.addEventListener('click', (e) => { if (!e.target.classList.contains('session-del')) switchSession(sid); });
    list.appendChild(item);
  });
}

function updateSessionUI() {
  const sid = state.activeSession;
  const sess = sid ? state.sessions[sid] : null;
  const scanId = sess ? sess.scanId : null;
  const isScanning = sess ? sess.status === 'running' : false;
  const isFinished = sess ? sess.scanFinished : false;

  $('btn-start').disabled = isScanning;
  $('btn-stop').disabled = !isScanning;
  $('btn-pause').disabled = !isScanning;
  $('btn-resume').disabled = !isScanning;
  // 聊天发送按钮和输入框始终可用 — 即使没有开始扫描也能与AI对话
  // $('btn-chat-send') 和 $('chat-input') 不设 disabled

  // 报告按钮 — 始终可点击，点击时根据状态给出提示
  // 不再设置 disabled

  // 状态标记
  if (isScanning) {
    $('thinking-status').textContent = '运行中'; $('thinking-status').className = 'status-badge running';
    $('terminal-badge').textContent = '运行中'; $('terminal-badge').className = 'status-badge running';
  } else if (isFinished) {
    $('thinking-status').textContent = '完成'; $('thinking-status').className = 'status-badge done';
    $('terminal-badge').textContent = '完成'; $('terminal-badge').className = 'status-badge done';
  } else {
    $('thinking-status').textContent = '待机'; $('thinking-status').className = 'status-badge idle';
    $('terminal-badge').textContent = '待机'; $('terminal-badge').className = 'status-badge idle';
  }
}

function clearThinkingUI() {
  $('thinking-stream').innerHTML = '';
  $('tool-calls').innerHTML = '';
  $('phase-steps').innerHTML = '';
  $('report-summary').innerHTML = '<div style="color:var(--text-dim);font-size:12px">⚠️ 无报告 — 尚未进行扫描</div>';
  $('report-files').innerHTML = '';
  state.stats = { ports: 0, subdomains: 0, vulns: 0, paths: 0 };
  ['qs-ports','qs-subdomains','qs-vulns','qs-paths'].forEach(id => { if ($(id)) $(id).textContent = '0'; });
  setProgress(0, '等待开始...');
}

// ═══ 思考面板 ═══
function appendThinking(type, content, agent) {
  const el = $('thinking-stream');
  const color = THINK_COLORS[type] || '#c9d1d9';
  const icon = THINK_ICONS[type] || '💭';
  const label = THINK_LABELS[type] || '思考';
  let html = '';
  const escaped = escHtml(content).replace(/\n/g, '<br>');

  if (type === 'command') {
    html = `<div class="think-block think-command">
      <div class="think-header" style="color:${color}">
        <span class="think-time">${now()}</span> ${icon} [${escHtml(agent)}] ${label}
      </div>
      <pre class="think-cmd-code">${escaped}</pre>
    </div>`;
  } else if (type === 'tool') {
    html = `<div class="think-block think-tool">
      <div class="think-header" style="color:${color}">
        <span class="think-time">${now()}</span> ${icon} [${escHtml(agent)}] ${label}
      </div>
      <div class="think-tool-body">${escaped}</div>
    </div>`;
    appendToolCall(content);
  } else if (type === 'result') {
    html = `<div class="think-block think-result">
      <div class="think-header" style="color:${color}">
        <span class="think-time">${now()}</span> ${icon} [${escHtml(agent)}] ${label}
      </div>
      <div class="think-result-body">${escaped}</div>
    </div>`;
  } else if (type === 'error') {
    html = `<div class="think-block think-error">
      <div class="think-header" style="color:${color}">
        <span class="think-time">${now()}</span> ${icon} [${escHtml(agent)}] ${label}
      </div>
      <div class="think-error-body">${escaped}</div>
    </div>`;
  } else {
    html = `<div class="think-block think-default">
      <div class="think-header" style="color:${color}">
        <span class="think-time">${now()}</span> ${icon} [${escHtml(agent)}] ${label}
      </div>
      <div class="think-body" style="color:${color}">${escaped}</div>
    </div>`;
  }
  appendEl(el, html);
}

function appendToolCall(content) {
  const el = $('tool-calls');
  const escaped = escHtml(content).replace(/\n/g, '<br>');
  const html = `<div class="tool-call-item">
    <span class="tool-call-time">${now()}</span>
    <div class="tool-call-body">${escaped}</div>
  </div>`;
  appendEl(el, html);
}

function logBoth(msg) {
  const line = `<span style="color:#554433">[${now()}]</span> ${escHtml(msg)}`;
  appendEl($('control-log'), line);
}

function showMsg(id, text, type) {
  const el = $(id);
  el.innerHTML = text.replace(/\n/g, '<br>');
  el.className = `config-msg ${type}`;
  const dur = type === 'success' ? 6000 : (type === 'error' ? 8000 : 4000);
  setTimeout(() => { el.className = 'config-msg hidden'; }, dur);
}

function setProgress(value, msg) {
  const fill = $('progress-fill');
  fill.style.width = value + '%';
  $('progress-label').textContent = msg || '';
  fill.classList.toggle('running', value > 0 && value < 100);
}

function updateStats(key, delta) {
  state.stats[key] = (state.stats[key] || 0) + delta;
  const el = $('qs-' + key);
  if (el) el.textContent = state.stats[key];
  const sid = state.activeSession;
  if (sid && state.sessions[sid]) state.sessions[sid].stats = { ...state.stats };
}

// ═══ Tab 导航 ═══
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.tab-panel').forEach(p => {
    p.classList.toggle('active', p.id === 'tab-' + tab);
    p.classList.toggle('hidden', p.id !== 'tab-' + tab);
  });
  state.currentTab = tab;
}

// ═══ 扫描：开始/停止/清除 ═══
function startScan() {
  const target = $('target-input').value.trim();
  const err = validateTarget(target);
  if (err) { alert(err); return; }
  const agents = ['info', 'vuln', 'web', 'report'].filter(id => $('agent-' + id) && $('agent-' + id).checked);
  if (!agents.length) { alert('请至少选择一个测试模块'); return; }

  const payload = {
    target, mode: $('mode-select').value,
    port_scan: $('opt-port-scan').checked, vuln_scan: $('opt-vuln-scan').checked,
    web_scan: $('opt-web-scan').checked, stealth_mode: $('opt-stealth').checked,
    deep_scan: $('opt-deep-scan').checked, selected_agents: agents,
  };

  fetch('/api/scan/start', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) })
    .then(r => r.json())
    .then(data => {
      if (data.error) { alert('启动失败: ' + data.error); return; }
      // 创建新会话
      const sid = createSession(target);
      const sess = state.sessions[sid];
      sess.scanId = data.scan_id;
      sess.status = 'running';
      state.scanning = true;
      updateSessionUI();
      setProgress(3, '准备中...');
      logBoth('扫描已启动，目标: ' + target);
      switchTab('thinking');
      appendThinking('info', `🎯 开始渗透测试 | 目标: ${target} | 模式: ${payload.mode}`, '📌 系统');
      connectSSE(data.scan_id);
      renderSessionList();
    })
    .catch(e => { alert('请求失败: ' + e.message); });
}

function stopScan() {
  const sid = state.activeSession;
  const sess = sid ? state.sessions[sid] : null;
  if (!sess || !sess.scanId) return;
  fetch(`/api/scan/${sess.scanId}/stop`, { method: 'POST' }).then(() => { logBoth('正在停止...'); });
}

function clearResults() {
  $('control-log').innerHTML = '';
  clearThinkingUI();
  if (state.activeSession && state.sessions[state.activeSession]) {
    delete state.sessions[state.activeSession];
  }
  state.activeSession = null;
  state.scanning = false;
  renderSessionList();
  updateSessionUI();
}

// ═══ SSE 连接 ═══
function connectSSE(scanId) {
  if (state.eventSource) state.eventSource.close();
  const es = new EventSource(`/api/scan/${scanId}/stream`);
  state.eventSource = es;

  es.addEventListener('log', e => { const d = JSON.parse(e.data); logBoth(d.message); });
  es.addEventListener('progress', e => { const d = JSON.parse(e.data); setProgress(d.value, d.message); });
  es.addEventListener('thinking', e => { const d = JSON.parse(e.data); handleThinking(d); });
  es.addEventListener('tool_call', e => { const d = JSON.parse(e.data); handleToolCall(d); });
  es.addEventListener('command', e => { const d = JSON.parse(e.data); handleCommand(d); });
  es.addEventListener('scan_result', e => { const d = JSON.parse(e.data); handleScanResult(d); });
  es.addEventListener('result', e => { const d = JSON.parse(e.data); handleResult(d.data); });
  es.addEventListener('error', e => { const d = JSON.parse(e.data); appendThinking('error', d.message, '❌ 系统'); });
  es.addEventListener('finished', e => { handleFinished(JSON.parse(e.data)); });
  es.addEventListener('phase', e => { handlePhase(JSON.parse(e.data)); });
  es.addEventListener('ping', () => {});
  es.onerror = () => { if (state.scanning) logBoth('SSE 连接中断'); };
}

// ═══ SSE 事件处理 ═══
function handleThinking(d) {
  appendThinking(d.thinking_type, d.content, d.agent);
  const progMap = { analyze: 20, plan: 35, action: 50, evaluate: 75, decide: 80 };
  const p = progMap[d.thinking_type] || 0;
  if (p) { const fill = $('progress-fill'); if (parseInt(fill.style.width) < p) setProgress(p, THINK_LABELS[d.thinking_type] + '...'); }
}

function handleToolCall(d) {
  appendThinking('tool', `${d.tool_name} | 用途: ${d.purpose || '扫描'}\n参数: ${d.params || '默认'}`, d.agent);
}

function handleCommand(d) {
  appendThinking('command', d.command, d.agent);
}

function handleScanResult(d) {
  const summary = d.summary || d.content || '完成';
  appendThinking('result', summary, d.agent);
  if (d.stats) { Object.entries(d.stats).forEach(([k, v]) => { if (v) updateStats(k, v); }); }
}

function handlePhase(d) {
  const stepsEl = $('phase-steps');
  const phaseHtml = `<div class="phase-step ${d.status || 'active'}">
    <span class="phase-icon">${d.status === 'done' ? '✅' : d.status === 'active' ? '⏳' : '⬜'}</span>
    <span class="phase-name">${escHtml(d.name)}</span>
  </div>`;
  appendEl(stepsEl, phaseHtml);
}

function handleResult(result) {
  if (!result) return;
  const ports = [], vulns = [], subs = [], paths = [];
  (result.results || []).forEach(phase => {
    if (!phase || typeof phase !== 'object') return;
    (phase.results || []).forEach(step => {
      const sr = (step.result || {});
      if (sr.ports) ports.push(...sr.ports);
      if (sr.subdomains) subs.push(...sr.subdomains);
      if (sr.found_paths) paths.push(...sr.found_paths);
      const vd = sr.vulnerabilities || {};
      if (typeof vd === 'object') Object.values(vd).flat().forEach(v => vulns.push(v));
      if (sr.cves) vulns.push(...sr.cves);
    });
  });
  updateStats('ports', ports.length);
  updateStats('subdomains', subs.length);
  updateStats('vulns', vulns.length);
  updateStats('paths', paths.length);
}

function handleFinished(d) {
  state.scanning = false;
  if (state.eventSource) { state.eventSource.close(); state.eventSource = null; }
  const sid = state.activeSession;
  if (sid && state.sessions[sid]) {
    state.sessions[sid].status = d.success ? 'finished' : 'stopped';
    state.sessions[sid].scanFinished = d.success;
  }
  if (d.success) {
    appendThinking('info', '✅ 渗透测试完成！可点击右侧"详细报告"按钮获取完整报告', '📌 系统');
    setProgress(100, '完成!');
  } else {
    appendThinking('error', d.message || '已停止', '📌 系统');
  }
  $('progress-fill').classList.remove('running');
  updateSessionUI();
  renderSessionList();
}

// ═══ 工具页面 ═══
function loadTools() {
  fetch('/api/tools').then(r => r.json()).then(data => {
    state.toolsData = data;
    renderToolsGrid(data);
    renderBestTools(data);
    const report = data.report || '';
    const match = report.match(/(\d+)\/(\d+)/);
    if (match) {
      const avail = parseInt(match[1]), total = parseInt(match[2]);
      $('header-tool-badge').textContent = `🔧 ${avail}/${total} 工具`;
      $('header-tool-badge').className = 'tool-badge ' + (avail === total ? 'all-ok' : (avail > total/2 ? 'partial' : 'low'));
    }
  }).catch(() => { $('header-tool-badge').textContent = '🔧 工具检测失败'; });
}

function renderToolsGrid(data) {
  const grid = $('tools-grid'); grid.innerHTML = '';
  const tools = data.tools || {};
  const categories = { port_scan: '📡 端口扫描', vuln_scan: '🔍 漏洞扫描', fingerprint: '🖥 指纹识别',
    dir_scan: '📂 目录扫描', subdomain: '🌐 子域名', sqli_scan: '💉 SQL注入',
    xss_scan: '🪲 XSS扫描', ssl_scan: '🔒 SSL检测', web_scan: '🌍 Web扫描', dns: '🔗 DNS' };
  Object.entries(tools).forEach(([name, info]) => {
    const cat = categories[info.category] || info.category;
    const ok = info.available;
    const card = document.createElement('div');
    card.className = 'tool-card' + (ok ? ' tool-ok' : ' tool-missing');
    card.innerHTML = `
      <div class="tool-icon">${ok ? '✅' : '❌'}</div>
      <div class="tool-info">
        <div class="tool-name">${escHtml(name)}</div>
        <div class="tool-cat">${cat}</div>
        ${ok ? `<div class="tool-src">${escHtml(info.source)}</div>` : `<div class="tool-install">${escHtml(info.install_hint || '未安装')}</div>`}
      </div>`;
    grid.appendChild(card);
  });
}

function renderBestTools(data) {
  const grid = $('best-tools-grid'); grid.innerHTML = '';
  const best = data.best_tools || {};
  const labels = { port_scan: '📡 端口扫描', vuln_scan: '🔍 漏洞扫描', fingerprint: '🖥 指纹识别',
    dir_scan: '📂 目录扫描', subdomain: '🌐 子域名', sqli_scan: '💉 SQL注入',
    xss_scan: '🪲 XSS扫描', ssl_scan: '🔒 SSL检测', web_scan: '🌍 Web扫描' };
  Object.entries(best).forEach(([cat, tool]) => {
    const item = document.createElement('div');
    item.className = 'best-tool-item';
    item.innerHTML = `<span class="best-cat">${labels[cat] || cat}</span><span class="best-tool-name">${tool || '❌ 无可用'}</span>`;
    grid.appendChild(item);
  });
}

function installTools(mode) {
  const installLog = $('install-log'); installLog.innerHTML = '<div style="color:#58a6ff">⏳ 正在安装，请稍候（可能需要数分钟）...</div>';
  const modeBtns = { all: $('btn-install-tools'), apt: $('btn-install-apt'), pip: $('btn-install-pip'), github: $('btn-install-github') };
  const btn = modeBtns[mode] || modeBtns.all;
  const origText = btn.textContent;
  btn.disabled = true; btn.textContent = '⏳ 安装中...';
  fetch(`/api/tools/install?mode=${mode}`, { method: 'POST' })
    .then(r => {
      if (!r.ok) return r.text().then(t => { try { return JSON.parse(t); } catch(_) { return { success: false, message: `HTTP ${r.status}: ${t.substring(0, 200)}` }; } });
      return r.json();
    })
    .then(data => {
      const msg = data.message || data.error || '未知结果';
      if (data.success) { showMsg('install-msg', `✅ ${msg}`, 'success'); } 
      else { showMsg('install-msg', `❌ ${msg}`, 'error'); }
      if (data.log) installLog.innerHTML = escHtml(data.log).replace(/\n/g, '<br>');
      else installLog.innerHTML = '<div style="color:var(--text-dim)">安装完成</div>';
      setTimeout(loadTools, 3000);
    })
    .catch(e => { showMsg('install-msg', '❌ 网络错误: ' + e.message, 'error'); installLog.innerHTML = ''; })
    .finally(() => { btn.disabled = false; btn.textContent = origText; });
}

// ═══ API 设置 ═══
function validateTarget(t) {
  if (!t || !t.trim()) return '目标地址不能为空';
  for (const c of t) if (DANGEROUS_CHARS.has(c)) return '目标地址包含非法字符';
  if (!TARGET_RE.test(t.trim())) return '请输入有效的 IP、域名或 URL';
  return null;
}

function loadProviders() {
  fetch('/api/providers').then(r => r.json()).then(data => { state.providers = data.providers || {}; renderProviderCards(); }).catch(e => console.error('loadProviders:', e));
}

function renderProviderCards() {
  const container = $('provider-cards'); container.innerHTML = '';
  const provs = state.config.providers || {}; const active = state.config.active_provider;
  Object.entries(state.providers).forEach(([id, info]) => {
    const pdata = provs[id] || {};
    const isCfg = pdata.is_configured; const isDef = (id === active); const isActive = (id === state.currentProvider);
    let cls = 'prov-card'; if (isActive) cls += ' active'; if (isCfg) cls += ' prov-configured'; if (isDef && isCfg) cls += ' prov-default';
    const badge = isDef && isCfg ? '<span class="prov-badge default">⭐</span>' : isCfg ? '<span class="prov-badge configured">✅</span>' : '';
    const card = document.createElement('div');
    card.className = cls;
    card.innerHTML = `<span class="prov-icon">${info.icon}</span><div class="prov-info"><div class="prov-name">${escHtml(info.name)} ${badge}</div><div class="prov-desc">${escHtml(info.description)}</div></div>`;
    card.addEventListener('click', () => selectProvider(id));
    container.appendChild(card);
  });
}

function selectProvider(id) {
  state.currentProvider = id;
  document.querySelectorAll('.prov-card').forEach((c, i) => { c.classList.toggle('active', Object.keys(state.providers)[i] === id); });
  const info = state.providers[id] || {}; const saved = (state.config.providers || {})[id] || {};
  const hasSavedKey = saved.has_saved_key;
  const keyInput = $('cfg-api-key');
  keyInput.value = ''; keyInput.placeholder = hasSavedKey ? '已保存 (输入新密钥可覆盖)' : (info.api_key_placeholder || '输入 API 密钥...');
  $('cfg-base-url').value = saved.base_url || info.default_base_url || '';
  const savedModel = saved.model || info.default_model;
  if (savedModel && !state.selectedModel) state.selectedModel = savedModel;
  renderModelList(info.models || [], savedModel);
  $('btn-fetch-models').disabled = !info.supports_model_fetch;
  const isDefault = (state.config.active_provider === id);
  $('btn-set-default').textContent = isDefault ? '⭐ 已是默认' : '⭐ 设为默认';
  $('btn-set-default').disabled = isDefault;
}

function renderModelList(models, selectedModel) {
  const container = $('model-list'); const search = $('model-search').value.trim().toLowerCase();
  container.innerHTML = '';
  const filtered = search ? models.filter(m => m.toLowerCase().includes(search)) : models;
  if (!filtered.length) { container.innerHTML = '<div style="padding:10px;color:#554433;font-size:12px;text-align:center">无匹配模型</div>'; return; }
  const currentSelected = state.selectedModel || selectedModel;
  filtered.forEach((m, idx) => {
    const isSelected = (m === currentSelected); const isRec = (idx === 0 && !search);
    const item = document.createElement('div');
    item.className = 'model-item' + (isSelected ? ' selected' : '');
    item.innerHTML = `<span class="model-radio">${isSelected ? '✅' : '⚪'}</span><span class="model-name">${escHtml(m)}</span>${isRec ? '<span class="model-tag">推荐</span>' : ''}${isSelected ? '<span class="model-check">已选</span>' : ''}`;
    item.addEventListener('click', () => { state.selectedModel = m; const hint = $('model-selected-hint'); hint.textContent = '✅ 已选择: ' + m; hint.classList.add('model-hint-flash'); setTimeout(() => hint.classList.remove('model-hint-flash'), 600); renderModelList(models, m); });
    container.appendChild(item);
  });
  $('model-selected-hint').textContent = currentSelected ? '✅ 当前选择: ' + currentSelected : '请点击选择模型';
}

function loadConfig() {
  fetch('/api/config').then(r => r.json()).then(data => { state.config = data; renderProviderCards(); renderProviderOverview(); if (data.active_provider && state.providers[data.active_provider]) selectProvider(data.active_provider); else selectProvider(state.currentProvider); }).catch(e => console.error('loadConfig:', e));
}

function saveConfig() {
  const provider = state.currentProvider;
  const apiKey = $('cfg-api-key').value.trim();
  const baseUrl = $('cfg-base-url').value.trim();
  const model = state.selectedModel || $('model-search').value.trim();
  const savedProvider = (state.config.providers || {})[provider] || {};
  if (!apiKey && !savedProvider.has_saved_key) { showMsg('config-msg', '❌ API 密钥不能为空', 'error'); return; }
  if (!model && !savedProvider.model) { showMsg('config-msg', '❌ 请选择模型', 'error'); return; }
  const btn = $('btn-save-config'); btn.disabled = true; btn.textContent = '保存中...';
  const payload = { provider, base_url: baseUrl, model: model || savedProvider.model };
  if (apiKey && !apiKey.includes('****')) payload.api_key = apiKey;
  fetch('/api/config/provider', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) })
    .then(r => r.json()).then(data => {
      if (data.success) { showMsg('config-msg', `✅ ${data.message}`, 'success'); btn.textContent = '✅ 已保存'; loadConfig(); loadStatus(); if (apiKey) { $('cfg-api-key').value = ''; $('cfg-api-key').placeholder = '已保存'; } }
      else { showMsg('config-msg', '❌ ' + (data.error || '保存失败'), 'error'); btn.textContent = '💾 保存配置'; }
    }).catch(e => showMsg('config-msg', '❌ ' + e.message, 'error'))
    .finally(() => { btn.disabled = false; setTimeout(() => btn.textContent = '💾 保存配置', 2000); });
}

function testConnection() {
  const provider = state.currentProvider;
  let apiKey = $('cfg-api-key').value.trim();
  const baseUrl = $('cfg-base-url').value.trim();
  const model = state.selectedModel || $('model-search').value.trim() || (state.providers[provider]||{}).default_model;
  if (!apiKey || apiKey.includes('****')) { const sp = (state.config.providers||{})[provider]||{}; if (sp.has_saved_key) apiKey = ''; }
  if (!apiKey) { const sp = (state.config.providers||{})[provider]||{}; if (!sp.has_saved_key) { showMsg('config-msg','❌ 请输入密钥','error'); return; } }
  const btn = $('btn-test-conn'); btn.disabled = true; btn.textContent = '⏳ 测试中...';
  fetch('/api/config/test', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ provider, api_key: apiKey, base_url: baseUrl, model }) })
    .then(r => r.json()).then(data => {
      if (data.success) { showMsg('config-msg', `✅ ${data.message}`, 'success'); btn.textContent = '✅ 正常'; }
      else { showMsg('config-msg', data.message || '❌ 连接失败', 'error'); btn.textContent = '🔗 测试连接'; }
    }).catch(e => showMsg('config-msg','❌ '+e.message,'error'))
    .finally(() => { btn.disabled = false; setTimeout(() => btn.textContent = '🔗 测试连接', 3000); });
}

function setDefault() {
  fetch('/api/config/default', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ provider: state.currentProvider }) })
    .then(r => r.json()).then(data => { if (data.success) { showMsg('config-msg','⭐ 已设为默认','info'); loadConfig(); loadStatus(); } })
    .catch(e => showMsg('config-msg','❌ '+e.message,'error'));
}

function fetchModels() {
  const provider = state.currentProvider;
  const apiKey = $('cfg-api-key').value.trim();
  const baseUrl = $('cfg-base-url').value.trim() || (state.providers[provider]||{}).default_base_url;
  if (!apiKey) { showMsg('config-msg','API 密钥不能为空','error'); return; }
  const btn = $('btn-fetch-models'); btn.disabled = true; btn.textContent = '⏳';
  fetch(`/api/config/models/${provider}?api_key=${encodeURIComponent(apiKey)}&base_url=${encodeURIComponent(baseUrl)}`)
    .then(r => r.json()).then(data => {
      if (data.success && data.models && data.models.length) { renderModelList(data.models, state.selectedModel); showMsg('config-msg', `✅ 获取到 ${data.models.length} 个模型`, 'success'); }
      else showMsg('config-msg', `⚠ ${data.message||'获取失败'}`, 'info');
    }).catch(e => showMsg('config-msg','❌ '+e.message,'error'))
    .finally(() => { btn.disabled = false; btn.textContent = '🔄'; });
}

function resetUrl() { $('cfg-base-url').value = (state.providers[state.currentProvider]||{}).default_base_url || ''; }
function toggleKey() { const i = $('cfg-api-key'); i.type = i.type === 'password' ? 'text' : 'password'; }

function renderProviderOverview() {
  const grid = $('provider-overview'); grid.innerHTML = '';
  const active = state.config.active_provider; const provs = state.config.providers || {};
  Object.entries(state.providers).forEach(([id, info]) => {
    const pdata = provs[id]||{}; const isDef = (id===active); const isCfg = pdata.is_configured;
    let stxt, scls; if (isDef&&isCfg) { stxt='⭐ 默认'; scls='default'; } else if (isCfg) { stxt='✅ 已配置'; scls='configured'; } else { stxt='⚠ 未配置'; scls='unconfigured'; }
    const mname = pdata.model||''; const mhint = mname ? `<div class="overview-model">🧠 ${escHtml(mname)}</div>` : '';
    const card = document.createElement('div');
    card.className = 'overview-card'+(isCfg?' configured':'');
    card.innerHTML = `<span class="overview-icon">${info.icon}</span><div class="overview-info"><div class="overview-name">${escHtml(info.name)}</div><div class="overview-status ${scls}">${stxt}</div>${mhint}</div>`;
    card.style.cursor = 'pointer'; card.addEventListener('click', () => selectProvider(id));
    grid.appendChild(card);
  });
}

function loadStatus() {
  fetch('/api/status').then(r => r.json()).then(data => {
    const badge = $('header-ai-badge'), label = $('ai-status-label');
    if (data.ai_configured) { badge.textContent = `AI: ${data.provider_name||data.active_provider}`; badge.className = 'ai-badge configured'; label.textContent = `✅ 已配置: ${data.provider_name||data.active_provider}`; label.className = 'ai-status-text configured'; }
    else { badge.textContent = 'AI: 未配置'; badge.className = 'ai-badge unconfigured'; label.textContent = '❌ 未配置'; label.className = 'ai-status-text unconfigured'; }
  }).catch(() => {});
}

// ═══ AI 对话交互 — 始终可用，SSE实时展示进度 ═══
function sendChat() {
  const input = $('chat-input');
  const msg = input.value.trim();
  if (!msg) return;
  
  const sid = state.activeSession;
  const sess = sid ? state.sessions[sid] : null;
  const isScanning = sess && sess.scanId && sess.status === 'running';
  
  // 在思考面板显示用户消息
  appendThinking('info', '💬 用户: ' + msg, '👤 用户');
  input.value = '';
  
  if (isScanning) {
    // 模式1: 扫描运行中 — 发送消息到扫描对话（影响AI决策）
    fetch(`/api/scan/${sess.scanId}/chat`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ message: msg })
    }).catch(e => appendThinking('error', '发送失败: ' + e.message, '❌ 系统'));
  } else {
    // 模式2: 无扫描运行 — 使用SSE流式对话（实时展示工具调用+解码+AI回复）
    const sendBtn = $('btn-chat-send');
    sendBtn.disabled = true; sendBtn.textContent = '⏳';
    
    // 尝试SSE流式接口
    _chatSSE(msg, sendBtn);
  }
}

function _chatSSE(msg, sendBtn) {
  // 先尝试SSE流式请求（实时展示进度）
  fetch('/api/chat/stream', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ message: msg })
  }).then(response => {
    if (!response.ok) {
      // SSE不可用，降级到普通JSON请求
      return _chatFallback(msg, sendBtn);
    }
    
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let done = false;
    
    function processChunk() {
      return reader.read().then(({ done: readDone, value }) => {
        if (readDone) { 
          if (!done) { done = true; sendBtn.disabled = false; sendBtn.textContent = '📤'; }
          return; 
        }
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        
        for (const line of lines) {
          if (line.startsWith('event: ')) {
            const eventType = line.slice(7).trim();
            continue;
          }
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.thinking_type) {
                // 实时展示思考事件
                appendThinking(data.thinking_type, data.content || '', data.agent || '🤖 AI');
              }
            } catch(e) {}
          }
        }
        
        return processChunk();
      });
    }
    
    return processChunk().catch(e => {
      if (!done) { done = true; sendBtn.disabled = false; sendBtn.textContent = '📤'; }
      appendThinking('error', 'SSE流中断: ' + e.message, '❌ 系统');
    });
  }).catch(e => {
    _chatFallback(msg, sendBtn);
  });
}

function _chatFallback(msg, sendBtn) {
  // 降级到普通JSON请求
  fetch('/api/chat', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ message: msg })
  })
  .then(r => {
    if (!r.ok) {
      return r.text().then(text => {
        try { 
          const errData = JSON.parse(text);
          throw new Error(errData.error || `HTTP ${r.status}`);
        } catch(parseErr) {
          if (parseErr.message.startsWith('HTTP') || parseErr.message.includes('非JSON')) throw parseErr;
          throw new Error(`服务器返回非JSON响应(HTTP ${r.status})，请同步代码到Kali并重启`);
        }
      });
    }
    return r.json();
  })
  .then(data => {
    if (data.error) { appendThinking('error', data.error, '❌ AI'); return; }
    
    // 显示解码结果
    if (data.decode) {
      appendThinking('tool', `🔓 解码工具 | 方式: ${data.decode.method}\n原始: ${data.decode.original}`, '🔓 解码器');
      appendThinking('result', `✅ 解码成功\n方法: ${data.decode.method}\n结果: ${data.decode.decoded}`, '🔓 解码器');
    }
    
    // 显示工具执行事件
    if (data.events && data.events.length) {
      data.events.forEach(ev => {
        appendThinking(ev.type || 'info', ev.content || '', ev.agent || '🔧 工具');
      });
    } else if (data.tool_executed && data.tool_result) {
      appendThinking('command', '🔧 工具命令已执行', '📌 系统');
      appendThinking('result', data.tool_result, '🔧 工具输出');
    }
    
    // 显示AI回复
    if (data.reply) {
      appendThinking('analyze', '🤖 ' + data.reply, '🤖 AI助手');
    }
  })
  .catch(e => {
    appendThinking('error', '对话失败: ' + e.message, '❌ 系统');
    if (e.message.includes('非JSON响应')) {
      appendThinking('info', '💡 请同步最新代码到Kali后重启', '📌 系统');
    }
  })
  .finally(() => { sendBtn.disabled = false; sendBtn.textContent = '📤'; });
}

function pauseScan() {
  const sid = state.activeSession;
  const sess = sid ? state.sessions[sid] : null;
  if (!sess || !sess.scanId) return;
  fetch(`/api/scan/${sess.scanId}/pause`, { method: 'POST' })
    .then(r => r.json()).then(d => {
      if (d.success) { $('btn-pause').disabled = true; $('btn-resume').disabled = false; appendThinking('info', '⏸️ 已暂停，等待您的指令...', '📌 系统'); }
    }).catch(e => appendThinking('error', '暂停失败: ' + e.message, '❌ 系统'));
}

function resumeScan() {
  const sid = state.activeSession;
  const sess = sid ? state.sessions[sid] : null;
  if (!sess || !sess.scanId) return;
  fetch(`/api/scan/${sess.scanId}/resume`, { method: 'POST' })
    .then(r => r.json()).then(d => {
      if (d.success) { $('btn-pause').disabled = false; $('btn-resume').disabled = true; appendThinking('info', '▶️ AI 已恢复执行', '📌 系统'); }
    }).catch(e => appendThinking('error', '恢复失败: ' + e.message, '❌ 系统'));
}

// ═══ 报告生成与下载 ═══
function generateReport(level) {
  const sid = state.activeSession;
  const sess = sid ? state.sessions[sid] : null;

  // 无会话或无扫描ID — 直接提示
  if (!sess || !sess.scanId) {
    $('report-summary').innerHTML = '<div style="color:var(--orange)">⚠️ 无报告 — 尚未进行扫描。请先在控制面板输入目标并开始渗透测试。</div>';
    return;
  }

  // 扫描未完成 — 提示
  if (sess.status === 'running') {
    $('report-summary').innerHTML = '<div style="color:var(--orange)">⏳ 扫描进行中，请等待完成后再生成报告。</div>';
    return;
  }
  if (sess.status === 'idle' || !sess.scanFinished) {
    $('report-summary').innerHTML = '<div style="color:var(--text-dim)">⚠️ 无报告 — 当前会话尚未完成扫描。</div>';
    return;
  }

  const btn = level === 'summary' ? $('btn-report-summary') : $('btn-report-detailed');
  btn.disabled = true; btn.textContent = '⏳ 生成中...';
  fetch('/api/report/generate', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ scan_id: sess.scanId, detail_level: level })
  })
  .then(r => r.json())
  .then(data => {
    if (data.error) { $('report-summary').innerHTML = '<div style="color:var(--orange)">⚠️ ' + escHtml(data.error) + '</div>'; btn.disabled = false; btn.textContent = level === 'summary' ? '📄 简报' : '📑 详细报告'; return; }
    const report = data.report || {};
    if (report.summary) {
      const s = report.summary;
      const stats = s.vuln_stats || {};
      const totalVulns = s.total_vulnerabilities || 0;
      let html = `<div class="report-risk">${s.risk_level || '✅ 安全'}</div>`;
      html += `<div style="font-size:11px;color:var(--text-dim);margin:4px 0 8px">漏洞 ${totalVulns} | 服务 ${s.total_services||0} | 发现 ${s.total_findings||0}</div>`;
      html += '<div class="report-stats-row">';
      html += `<span class="rs-item rs-critical" title="严重">🔴 ${stats.critical||0}</span>`;
      html += `<span class="rs-item rs-high" title="高危">🟠 ${stats.high||0}</span>`;
      html += `<span class="rs-item rs-medium" title="中危">🟡 ${stats.medium||0}</span>`;
      html += `<span class="rs-item rs-low" title="低危">🔵 ${stats.low||0}</span></div>`;

      // 漏洞类型列表
      if (s.top_vulns && s.top_vulns.length) {
        html += '<div style="margin-top:8px;font-size:12px;font-weight:600;color:var(--text-dim)">🐛 发现的漏洞</div>';
        html += '<div class="report-top-vulns">';
        s.top_vulns.forEach(v => {
          const sevColors = { critical:'#ff4444', high:'#ff9900', medium:'#ffcc00', low:'#58a6ff' };
          const sevLabels = { critical:'严重', high:'高危', medium:'中危', low:'低危', info:'信息' };
          const sevColor = sevColors[v.severity] || '#999';
          const sevLabel = sevLabels[v.severity] || v.severity;
          const typeLabel = v.type ? `<span style="font-size:10px;background:#333;color:#aaa;padding:1px 4px;border-radius:2px;margin-left:4px">${escHtml(v.type)}</span>` : '';
          html += `<div style="padding:5px 8px;margin:3px 0;border-left:3px solid ${sevColor};background:rgba(255,255,255,0.03);border-radius:0 4px 4px 0">`;
          html += `<strong style="font-size:12px">${escHtml(v.name)}</strong>${typeLabel}`;
          html += ` <span style="font-size:10px;color:${sevColor};font-weight:600">[${sevLabel}]</span>`;
          if (v.url) html += `<br><code style="font-size:10px;color:var(--text-dim)">${escHtml(v.url)}</code>`;
          if (v.description) html += `<br><span style="font-size:10px;color:var(--text-dim)">${escHtml(v.description)}</span>`;
          html += '</div>';
        });
        html += '</div>';
      } else if (totalVulns === 0) {
        html += '<div style="margin-top:8px;padding:8px;text-align:center;color:var(--text-dim);font-size:12px">未发现安全漏洞 ✅</div>';
      }

      // 技术栈
      if (s.technologies && s.technologies.length) {
        html += '<div style="margin-top:8px;font-size:12px;font-weight:600;color:var(--text-dim)">💻 技术栈</div>';
        html += '<div style="margin:4px 0">';
        s.technologies.forEach(t => {
          html += `<span style="display:inline-block;font-size:10px;background:#1a1a2e;color:#58a6ff;padding:2px 6px;margin:2px;border-radius:3px">${escHtml(t)}</span>`;
        });
        html += '</div>';
      }

      $('report-summary').innerHTML = html;
    }
    if (report.files) {
      let fhtml = '<div style="margin-top:8px">';
      const files = report.files;
      const fmtMap = {md: {label: 'Markdown', ext: 'md'}, txt: {label: 'TXT', ext: 'txt'}, pdf: {label: 'PDF', ext: 'pdf'}, html: {label: 'HTML', ext: 'html'}};
      Object.entries(fmtMap).forEach(([key, info]) => {
        if (files[key]) {
          fhtml += `<button class="report-dl" data-path="${escHtml(files[key])}" data-ext="${info.ext}" onclick="downloadReport(this)">📥 ${info.label}</button> `;
        }
      });
      fhtml += '</div>';
      $('report-files').innerHTML = fhtml;
    }
    btn.disabled = false;
    btn.textContent = level === 'summary' ? '📄 简报' : '📑 详细报告';
  })
  .catch(e => { $('report-summary').innerHTML = '<div style="color:var(--red)">❌ ' + escHtml(e.message) + '</div>'; btn.disabled = false; btn.textContent = level === 'summary' ? '📄 简报' : '📑 详细报告'; });
}

function downloadReport(btn) {
  const path = btn.getAttribute('data-path');
  const ext = btn.getAttribute('data-ext');
  if (!path) return;
  btn.disabled = true;
  const origText = btn.textContent;
  btn.textContent = '⏳ 下载中...';

  fetch('/api/report/download/' + path.split(/[/\\]/).map(encodeURIComponent).join('/'))
    .then(r => {
      if (!r.ok) {
        // 服务器返回错误（可能是JSON错误响应）
        return r.json().then(d => { throw new Error(d.error || '下载失败'); }).catch(e2 => {
          throw new Error(r.status === 404 ? '文件不存在，请重新生成报告' : '下载失败');
        });
      }
      const ct = r.headers.get('content-type') || '';
      if (ct.includes('application/json')) {
        // 服务器返回了JSON而非文件
        return r.json().then(d => { throw new Error(d.error || '文件不存在'); });
      }
      return r.blob();
    })
    .then(blob => {
      // 用Blob触发浏览器下载
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      // 从路径中提取文件名
      const filename = path.split('/').pop() || ('report.' + ext);
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      btn.textContent = '✅ 已下载';
      setTimeout(() => { btn.textContent = origText; btn.disabled = false; }, 2000);
    })
    .catch(e => {
      btn.textContent = '❌ ' + e.message;
      setTimeout(() => { btn.textContent = origText; btn.disabled = false; }, 3000);
    });
}

function updateClock() { $('header-clock').textContent = new Date().toLocaleTimeString('zh-CN', { hour12: false }); }

// ═══ 事件绑定 ═══
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.tab-btn').forEach(btn => btn.addEventListener('click', () => switchTab(btn.dataset.tab)));
  $('btn-start').addEventListener('click', startScan);
  $('btn-stop').addEventListener('click', stopScan);
  $('btn-clear').addEventListener('click', clearResults);
  $('btn-clear-thinking').addEventListener('click', () => { $('thinking-stream').innerHTML = ''; $('tool-calls').innerHTML = ''; });
  $('goto-settings-link').addEventListener('click', e => { e.preventDefault(); switchTab('settings'); });
  $('btn-save-config').addEventListener('click', saveConfig);
  $('btn-test-conn').addEventListener('click', testConnection);
  $('btn-set-default').addEventListener('click', setDefault);
  $('btn-fetch-models').addEventListener('click', fetchModels);
  $('btn-reset-url').addEventListener('click', resetUrl);
  $('btn-toggle-key').addEventListener('click', toggleKey);
  $('btn-refresh-tools').addEventListener('click', loadTools);
  $('btn-install-tools').addEventListener('click', () => installTools('all'));
  $('btn-install-apt').addEventListener('click', () => installTools('apt'));
  $('btn-install-pip').addEventListener('click', () => installTools('pip'));
  $('btn-install-github').addEventListener('click', () => installTools('github'));
  $('model-search').addEventListener('input', () => { const info = state.providers[state.currentProvider]||{}; renderModelList(info.models||[], state.selectedModel); });
  $('target-input').addEventListener('keydown', e => { if (e.key === 'Enter' && !state.scanning) startScan(); });

  // 多会话
  $('btn-new-session').addEventListener('click', () => {
    // 如果正在扫描，先保存
    if (state.scanning) { alert('请先等待当前扫描完成或停止'); return; }
    const sid = createSession('新对话');
    clearThinkingUI();
    appendThinking('info', '💡 新建对话已创建，请前往控制面板设置目标并开始测试', '📌 系统');
    switchTab('control');
    $('target-input').focus();
    updateSessionUI();
  });

  // AI 对话交互
  $('btn-chat-send').addEventListener('click', sendChat);
  $('chat-input').addEventListener('keydown', e => { if (e.key === 'Enter') sendChat(); });
  $('btn-pause').addEventListener('click', pauseScan);
  $('btn-resume').addEventListener('click', resumeScan);

  // 报告生成
  $('btn-report-summary').addEventListener('click', () => generateReport('summary'));
  $('btn-report-detailed').addEventListener('click', () => generateReport('detailed'));

  // 字体大小切换
  $('font-size-select').addEventListener('change', e => {
    const cls = e.target.value;
    document.body.className = cls;
    try { localStorage.setItem('neuralstrike-font-size', cls); } catch(_){}
  });
  try { const saved = localStorage.getItem('neuralstrike-font-size'); if (saved) { document.body.className = saved; $('font-size-select').value = saved; } } catch(_){}

  // 初始化
  loadProviders();
  setTimeout(() => { loadConfig(); loadStatus(); loadTools(); }, 200);
  updateClock(); setInterval(updateClock, 1000);

  // 创建默认会话
  createSession('新对话');
  appendThinking('info', '👋 欢迎使用 NeuralStrike AI 智能渗透测试平台！\n\n💡 你可以直接在下方输入命令与AI对话，无需开始扫描：\n  • 输入 arp-scan -l → 扫描局域网存活主机\n  • 输入 nmap -sV 192.168.1.1 → 端口扫描\n  • 输入 "扫描局域网" → AI自动识别并执行\n  • 输入 base64: SGVsbG8= → 自动解码\n  • 输入任何安全问题 → AI专业解答\n\n🔓 解码支持: Base64/Base32/Hex/URL/ROT13/HTML实体/MD5/SHA256\n🔧 工具支持: nmap/nuclei/sqlmap/dalfox/hydra/枚举/提权等50+工具\n\n或前往控制面板输入目标地址开始完整渗透测试', '📌 系统');
});
